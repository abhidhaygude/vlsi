--------------------------------------------------------------------------------
-- Copyright (c) 1995-2013 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____
--  /   /\/   /
-- /___/  \  /    Vendor: Xilinx
-- \   \   \/     Version: P.20131013
--  \   \         Application: netgen
--  /   /         Filename: mod25_synthesis.vhd
-- /___/   /\     Timestamp: Fri Aug 14 06:53:54 2026
-- \   \  /  \ 
--  \___\/\___\
--             
-- Command	: -intstyle ise -ar Structure -tm mod25 -w -dir netgen/synthesis -ofmt vhdl -sim mod25.ngc mod25_synthesis.vhd 
-- Device	: xc3s250e-5-pq208
-- Input file	: mod25.ngc
-- Output file	: D:\42226_Asmita\Experiment 3\mod_n_ctr\netgen\synthesis\mod25_synthesis.vhd
-- # of Entities	: 1
-- Design Name	: mod25
-- Xilinx	: C:\Xilinx\14.7\ISE_DS\ISE\
--             
-- Purpose:    
--     This VHDL netlist is a verification model and uses simulation 
--     primitives which may not represent the true implementation of the 
--     device, however the netlist is functionally correct and should not 
--     be modified. This file cannot be synthesized and should only be used 
--     with supported simulation tools.
--             
-- Reference:  
--     Command Line Tools User Guide, Chapter 23
--     Synthesis and Simulation Design Guide, Chapter 6
--             
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
use UNISIM.VPKG.ALL;

entity mod25 is
  port (
    clk : in STD_LOGIC := 'X'; 
    dir : in STD_LOGIC := 'X'; 
    rst : in STD_LOGIC := 'X'; 
    pr : in STD_LOGIC := 'X'; 
    Q : out STD_LOGIC_VECTOR ( 4 downto 0 ) 
  );
end mod25;

architecture Structure of mod25 is
  signal N10 : STD_LOGIC; 
  signal N11 : STD_LOGIC; 
  signal N6 : STD_LOGIC; 
  signal N8 : STD_LOGIC; 
  signal N9 : STD_LOGIC; 
  signal Qtemp_mux0003_0_bdd0 : STD_LOGIC; 
  signal Qtemp_mux0003_0_bdd1 : STD_LOGIC; 
  signal Qtemp_mux0003_2_126_20 : STD_LOGIC; 
  signal Qtemp_mux0003_2_164_21 : STD_LOGIC; 
  signal Qtemp_mux0003_2_199_22 : STD_LOGIC; 
  signal Qtemp_mux0003_2_bdd0 : STD_LOGIC; 
  signal Qtemp_mux0003_3_11 : STD_LOGIC; 
  signal Qtemp_mux0003_3_111_26 : STD_LOGIC; 
  signal clk_BUFGP_29 : STD_LOGIC; 
  signal dir_IBUF_31 : STD_LOGIC; 
  signal pr_IBUF_33 : STD_LOGIC; 
  signal rst_IBUF_35 : STD_LOGIC; 
  signal Qtemp : STD_LOGIC_VECTOR ( 4 downto 0 ); 
  signal Qtemp_mux0003 : STD_LOGIC_VECTOR ( 4 downto 0 ); 
begin
  Qtemp_0 : FDCP_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_29,
      CLR => rst_IBUF_35,
      D => Qtemp_mux0003(4),
      PRE => pr_IBUF_33,
      Q => Qtemp(0)
    );
  Qtemp_1 : FDCP_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_29,
      CLR => rst_IBUF_35,
      D => Qtemp_mux0003(3),
      PRE => pr_IBUF_33,
      Q => Qtemp(1)
    );
  Qtemp_2 : FDCP_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_29,
      CLR => rst_IBUF_35,
      D => Qtemp_mux0003(2),
      PRE => pr_IBUF_33,
      Q => Qtemp(2)
    );
  Qtemp_3 : FDCP_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_29,
      CLR => rst_IBUF_35,
      D => Qtemp_mux0003(1),
      PRE => pr_IBUF_33,
      Q => Qtemp(3)
    );
  Qtemp_4 : FDCP_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_29,
      CLR => rst_IBUF_35,
      D => Qtemp_mux0003(0),
      PRE => pr_IBUF_33,
      Q => Qtemp(4)
    );
  Qtemp_mux0003_4_21 : LUT4
    generic map(
      INIT => X"017F"
    )
    port map (
      I0 => dir_IBUF_31,
      I1 => Qtemp(3),
      I2 => Qtemp(4),
      I3 => Qtemp(0),
      O => Qtemp_mux0003(4)
    );
  Qtemp_mux0003_0_41 : LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      I0 => Qtemp(2),
      I1 => Qtemp(1),
      I2 => Qtemp(0),
      O => Qtemp_mux0003_0_bdd1
    );
  Qtemp_mux0003_0_31 : LUT3
    generic map(
      INIT => X"7F"
    )
    port map (
      I0 => Qtemp(2),
      I1 => Qtemp(1),
      I2 => Qtemp(0),
      O => Qtemp_mux0003_0_bdd0
    );
  Qtemp_mux0003_2_164 : LUT4
    generic map(
      INIT => X"A900"
    )
    port map (
      I0 => Qtemp(2),
      I1 => Qtemp(1),
      I2 => Qtemp(0),
      I3 => Qtemp(3),
      O => Qtemp_mux0003_2_164_21
    );
  Qtemp_mux0003_2_199 : LUT3
    generic map(
      INIT => X"07"
    )
    port map (
      I0 => Qtemp(4),
      I1 => Qtemp(3),
      I2 => Qtemp_mux0003_2_bdd0,
      O => Qtemp_mux0003_2_199_22
    );
  Qtemp_mux0003_2_1114 : LUT4
    generic map(
      INIT => X"F5E4"
    )
    port map (
      I0 => dir_IBUF_31,
      I1 => Qtemp_mux0003_2_164_21,
      I2 => Qtemp_mux0003_2_199_22,
      I3 => Qtemp_mux0003_2_126_20,
      O => Qtemp_mux0003(2)
    );
  dir_IBUF : IBUF
    port map (
      I => dir,
      O => dir_IBUF_31
    );
  rst_IBUF : IBUF
    port map (
      I => rst,
      O => rst_IBUF_35
    );
  pr_IBUF : IBUF
    port map (
      I => pr,
      O => pr_IBUF_33
    );
  Q_4_OBUF : OBUF
    port map (
      I => Qtemp(4),
      O => Q(4)
    );
  Q_3_OBUF : OBUF
    port map (
      I => Qtemp(3),
      O => Q(3)
    );
  Q_2_OBUF : OBUF
    port map (
      I => Qtemp(2),
      O => Q(2)
    );
  Q_1_OBUF : OBUF
    port map (
      I => Qtemp(1),
      O => Q(1)
    );
  Q_0_OBUF : OBUF
    port map (
      I => Qtemp(0),
      O => Q(0)
    );
  Qtemp_mux0003_2_126_SW0 : LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      I0 => Qtemp(1),
      I1 => Qtemp(0),
      O => N6
    );
  clk_BUFGP : BUFGP
    port map (
      I => clk,
      O => clk_BUFGP_29
    );
  Qtemp_mux0003_1_1 : MUXF5
    port map (
      I0 => N8,
      I1 => N9,
      S => Qtemp_mux0003_0_bdd0,
      O => Qtemp_mux0003(1)
    );
  Qtemp_mux0003_1_1_F : LUT4
    generic map(
      INIT => X"393B"
    )
    port map (
      I0 => Qtemp_mux0003_0_bdd1,
      I1 => Qtemp(3),
      I2 => dir_IBUF_31,
      I3 => Qtemp(4),
      O => N8
    );
  Qtemp_mux0003_1_1_G : LUT4
    generic map(
      INIT => X"3A07"
    )
    port map (
      I0 => Qtemp_mux0003_0_bdd1,
      I1 => Qtemp(4),
      I2 => dir_IBUF_31,
      I3 => Qtemp(3),
      O => N9
    );
  Qtemp_mux0003_0_2 : MUXF5
    port map (
      I0 => N10,
      I1 => N11,
      S => Qtemp_mux0003_0_bdd0,
      O => Qtemp_mux0003(0)
    );
  Qtemp_mux0003_0_2_F : LUT4
    generic map(
      INIT => X"6B69"
    )
    port map (
      I0 => Qtemp(4),
      I1 => Qtemp(3),
      I2 => dir_IBUF_31,
      I3 => Qtemp_mux0003_0_bdd1,
      O => N10
    );
  Qtemp_mux0003_0_2_G : LUT4
    generic map(
      INIT => X"3E03"
    )
    port map (
      I0 => Qtemp_mux0003_0_bdd1,
      I1 => Qtemp(3),
      I2 => dir_IBUF_31,
      I3 => Qtemp(4),
      O => N11
    );
  Qtemp_mux0003_3_111 : LUT4
    generic map(
      INIT => X"4169"
    )
    port map (
      I0 => dir_IBUF_31,
      I1 => Qtemp(0),
      I2 => Qtemp(1),
      I3 => Qtemp(3),
      O => Qtemp_mux0003_3_11
    );
  Qtemp_mux0003_3_112 : LUT4
    generic map(
      INIT => X"697D"
    )
    port map (
      I0 => dir_IBUF_31,
      I1 => Qtemp(0),
      I2 => Qtemp(1),
      I3 => Qtemp(3),
      O => Qtemp_mux0003_3_111_26
    );
  Qtemp_mux0003_3_11_f5 : MUXF5
    port map (
      I0 => Qtemp_mux0003_3_111_26,
      I1 => Qtemp_mux0003_3_11,
      S => Qtemp(4),
      O => Qtemp_mux0003(3)
    );
  Qtemp_mux0003_2_21 : LUT3_L
    generic map(
      INIT => X"95"
    )
    port map (
      I0 => Qtemp(2),
      I1 => Qtemp(1),
      I2 => Qtemp(0),
      LO => Qtemp_mux0003_2_bdd0
    );
  Qtemp_mux0003_2_126 : LUT4_L
    generic map(
      INIT => X"0B07"
    )
    port map (
      I0 => Qtemp(2),
      I1 => Qtemp(4),
      I2 => Qtemp(3),
      I3 => N6,
      LO => Qtemp_mux0003_2_126_20
    );

end Structure;

