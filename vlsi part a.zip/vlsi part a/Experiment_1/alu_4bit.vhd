----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    06:26:44 07/17/2026 
-- Design Name: 
-- Module Name:    alu_4bit - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity alu_4bit is
    Port (
        A   : in  STD_LOGIC_VECTOR(3 downto 0);
        B   : in  STD_LOGIC_VECTOR(3 downto 0);
        F   : in  STD_LOGIC_VECTOR(2 downto 0);
        Y   : out STD_LOGIC_VECTOR(3 downto 0);
        C_B : out STD_LOGIC
    );
end alu_4bit;

architecture Behavioral of alu_4bit is
    signal result : unsigned(4 downto 0);
begin

process(A, B, F)
begin

    C_B <= '0';

    case F is

        -- AND
        when "000" =>
            result <= unsigned('0' & (A and B));

        -- NAND
        when "001" =>
            result <= unsigned('0' & (A nand B));

        -- OR
        when "010" =>
            result <= unsigned('0' & (A or B));

        -- XOR
        when "011" =>
            result <= unsigned('0' & (A xor B));

        -- XNOR
        when "100" =>
            result <= unsigned('0' & (A xnor B));

        -- NOT A
        when "101" =>
            result <= unsigned('0' & (not A));

        -- ADD
        when "110" =>
            result <= unsigned('0' & A) + unsigned('0' & B);

        -- SUBTRACT
        when "111" =>
            result <= unsigned('0' & A) - unsigned('0' & B);

            if unsigned(A) < unsigned(B) then
                C_B <= '1';      -- Borrow
            else
                C_B <= '0';
            end if;

        when others =>
            result <= (others => '0');
            C_B <= '0';

    end case;

end process;

Y <= std_logic_vector(result(3 downto 0));

end Behavioral;

