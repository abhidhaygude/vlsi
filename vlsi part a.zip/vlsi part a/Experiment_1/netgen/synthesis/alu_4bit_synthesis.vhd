--------------------------------------------------------------------------------
-- Copyright (c) 1995-2013 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____
--  /   /\/   /
-- /___/  \  /    Vendor: Xilinx
-- \   \   \/     Version: P.20131013
--  \   \         Application: netgen
--  /   /         Filename: alu_4bit_synthesis.vhd
-- /___/   /\     Timestamp: Fri Aug 14 07:33:27 2026
-- \   \  /  \ 
--  \___\/\___\
--             
-- Command	: -intstyle ise -ar Structure -tm alu_4bit -w -dir netgen/synthesis -ofmt vhdl -sim alu_4bit.ngc alu_4bit_synthesis.vhd 
-- Device	: xc3s250e-5-pq208
-- Input file	: alu_4bit.ngc
-- Output file	: D:\42226_Asmita\Experiment_1\netgen\synthesis\alu_4bit_synthesis.vhd
-- # of Entities	: 1
-- Design Name	: alu_4bit
-- Xilinx	: C:\Xilinx\14.7\ISE_DS\ISE\
--             
-- Purpose:    
--     This VHDL netlist is a verification model and uses simulation 
--     primitives which may not represent the true implementation of the 
--     device, however the netlist is functionally correct and should not 
--     be modified. This file cannot be synthesized and should only be used 
--     with supported simulation tools.
--             
-- Reference:  
--     Command Line Tools User Guide, Chapter 23
--     Synthesis and Simulation Design Guide, Chapter 6
--             
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
use UNISIM.VPKG.ALL;

entity alu_4bit is
  port (
    C_B : out STD_LOGIC; 
    Y : out STD_LOGIC_VECTOR ( 3 downto 0 ); 
    A : in STD_LOGIC_VECTOR ( 3 downto 0 ); 
    B : in STD_LOGIC_VECTOR ( 3 downto 0 ); 
    F : in STD_LOGIC_VECTOR ( 2 downto 0 ) 
  );
end alu_4bit;

architecture Structure of alu_4bit is
  signal A_0_IBUF_4 : STD_LOGIC; 
  signal A_1_IBUF_5 : STD_LOGIC; 
  signal A_2_IBUF_6 : STD_LOGIC; 
  signal A_3_IBUF_7 : STD_LOGIC; 
  signal B_0_IBUF_12 : STD_LOGIC; 
  signal B_1_IBUF_13 : STD_LOGIC; 
  signal B_2_IBUF_14 : STD_LOGIC; 
  signal B_3_IBUF_15 : STD_LOGIC; 
  signal C_B_OBUF_17 : STD_LOGIC; 
  signal C_B_cmp_lt00001_18 : STD_LOGIC; 
  signal F_0_IBUF_22 : STD_LOGIC; 
  signal F_1_IBUF_23 : STD_LOGIC; 
  signal F_2_IBUF_24 : STD_LOGIC; 
  signal Maddsub_result_addsub0000_cy_1_1 : STD_LOGIC; 
  signal Maddsub_result_addsub0000_cy_1_11_27 : STD_LOGIC; 
  signal Mmux_C_B122_28 : STD_LOGIC; 
  signal Mmux_C_B15_29 : STD_LOGIC; 
  signal Mmux_result_3_f5_30 : STD_LOGIC; 
  signal Mmux_result_3_f51 : STD_LOGIC; 
  signal Mmux_result_3_f52 : STD_LOGIC; 
  signal Mmux_result_3_f53 : STD_LOGIC; 
  signal Mmux_result_4_f5_34 : STD_LOGIC; 
  signal Mmux_result_4_f51 : STD_LOGIC; 
  signal Mmux_result_4_f52 : STD_LOGIC; 
  signal Mmux_result_4_f53 : STD_LOGIC; 
  signal Mmux_result_5_38 : STD_LOGIC; 
  signal Mmux_result_51_39 : STD_LOGIC; 
  signal Mmux_result_52_40 : STD_LOGIC; 
  signal Mmux_result_53_41 : STD_LOGIC; 
  signal Mmux_result_54_42 : STD_LOGIC; 
  signal Mmux_result_55_43 : STD_LOGIC; 
  signal Mmux_result_56_44 : STD_LOGIC; 
  signal Mmux_result_57_45 : STD_LOGIC; 
  signal Mmux_result_6_46 : STD_LOGIC; 
  signal Mmux_result_61_47 : STD_LOGIC; 
  signal Mmux_result_62_48 : STD_LOGIC; 
  signal Mmux_result_63_49 : STD_LOGIC; 
  signal N10 : STD_LOGIC; 
  signal N6 : STD_LOGIC; 
  signal N8 : STD_LOGIC; 
  signal Y_0_OBUF_57 : STD_LOGIC; 
  signal Y_1_OBUF_58 : STD_LOGIC; 
  signal Y_2_OBUF_59 : STD_LOGIC; 
  signal Y_3_OBUF_60 : STD_LOGIC; 
  signal result_mux00001_65 : STD_LOGIC; 
  signal Maddsub_result_addsub0000_cy : STD_LOGIC_VECTOR ( 1 downto 1 ); 
  signal result_addsub0000 : STD_LOGIC_VECTOR ( 3 downto 0 ); 
begin
  Mmux_result_2_f6_2 : MUXF6
    port map (
      I0 => Mmux_result_4_f53,
      I1 => Mmux_result_3_f53,
      S => F_2_IBUF_24,
      O => Y_3_OBUF_60
    );
  Mmux_result_4_f5_2 : MUXF5
    port map (
      I0 => Mmux_result_63_49,
      I1 => Mmux_result_57_45,
      S => F_1_IBUF_23,
      O => Mmux_result_4_f53
    );
  Mmux_result_3_f5_2 : MUXF5
    port map (
      I0 => Mmux_result_56_44,
      I1 => result_addsub0000(3),
      S => F_1_IBUF_23,
      O => Mmux_result_3_f53
    );
  Mmux_result_2_f6_1 : MUXF6
    port map (
      I0 => Mmux_result_4_f52,
      I1 => Mmux_result_3_f52,
      S => F_2_IBUF_24,
      O => Y_2_OBUF_59
    );
  Mmux_result_4_f5_1 : MUXF5
    port map (
      I0 => Mmux_result_62_48,
      I1 => Mmux_result_55_43,
      S => F_1_IBUF_23,
      O => Mmux_result_4_f52
    );
  Mmux_result_3_f5_1 : MUXF5
    port map (
      I0 => Mmux_result_54_42,
      I1 => result_addsub0000(2),
      S => F_1_IBUF_23,
      O => Mmux_result_3_f52
    );
  Mmux_result_2_f6_0 : MUXF6
    port map (
      I0 => Mmux_result_4_f51,
      I1 => Mmux_result_3_f51,
      S => F_2_IBUF_24,
      O => Y_1_OBUF_58
    );
  Mmux_result_4_f5_0 : MUXF5
    port map (
      I0 => Mmux_result_61_47,
      I1 => Mmux_result_53_41,
      S => F_1_IBUF_23,
      O => Mmux_result_4_f51
    );
  Mmux_result_3_f5_0 : MUXF5
    port map (
      I0 => Mmux_result_52_40,
      I1 => result_addsub0000(1),
      S => F_1_IBUF_23,
      O => Mmux_result_3_f51
    );
  Mmux_result_2_f6 : MUXF6
    port map (
      I0 => Mmux_result_4_f5_34,
      I1 => Mmux_result_3_f5_30,
      S => F_2_IBUF_24,
      O => Y_0_OBUF_57
    );
  Mmux_result_4_f5 : MUXF5
    port map (
      I0 => Mmux_result_6_46,
      I1 => Mmux_result_51_39,
      S => F_1_IBUF_23,
      O => Mmux_result_4_f5_34
    );
  Mmux_result_3_f5 : MUXF5
    port map (
      I0 => Mmux_result_5_38,
      I1 => result_addsub0000(0),
      S => F_1_IBUF_23,
      O => Mmux_result_3_f5_30
    );
  C_B_cmp_lt00001 : LUT4
    generic map(
      INIT => X"20BA"
    )
    port map (
      I0 => B_1_IBUF_13,
      I1 => A_0_IBUF_4,
      I2 => B_0_IBUF_12,
      I3 => A_1_IBUF_5,
      O => C_B_cmp_lt00001_18
    );
  Mmux_C_B15 : LUT2
    generic map(
      INIT => X"D"
    )
    port map (
      I0 => A_3_IBUF_7,
      I1 => B_3_IBUF_15,
      O => Mmux_C_B15_29
    );
  Mmux_C_B122 : LUT4
    generic map(
      INIT => X"80A8"
    )
    port map (
      I0 => Mmux_C_B15_29,
      I1 => B_2_IBUF_14,
      I2 => C_B_cmp_lt00001_18,
      I3 => A_2_IBUF_6,
      O => Mmux_C_B122_28
    );
  result_mux00001 : LUT3
    generic map(
      INIT => X"BF"
    )
    port map (
      I0 => F_0_IBUF_22,
      I1 => F_2_IBUF_24,
      I2 => F_1_IBUF_23,
      O => result_mux00001_65
    );
  A_3_IBUF : IBUF
    port map (
      I => A(3),
      O => A_3_IBUF_7
    );
  A_2_IBUF : IBUF
    port map (
      I => A(2),
      O => A_2_IBUF_6
    );
  A_1_IBUF : IBUF
    port map (
      I => A(1),
      O => A_1_IBUF_5
    );
  A_0_IBUF : IBUF
    port map (
      I => A(0),
      O => A_0_IBUF_4
    );
  B_3_IBUF : IBUF
    port map (
      I => B(3),
      O => B_3_IBUF_15
    );
  B_2_IBUF : IBUF
    port map (
      I => B(2),
      O => B_2_IBUF_14
    );
  B_1_IBUF : IBUF
    port map (
      I => B(1),
      O => B_1_IBUF_13
    );
  B_0_IBUF : IBUF
    port map (
      I => B(0),
      O => B_0_IBUF_12
    );
  F_2_IBUF : IBUF
    port map (
      I => F(2),
      O => F_2_IBUF_24
    );
  F_1_IBUF : IBUF
    port map (
      I => F(1),
      O => F_1_IBUF_23
    );
  F_0_IBUF : IBUF
    port map (
      I => F(0),
      O => F_0_IBUF_22
    );
  C_B_OBUF : OBUF
    port map (
      I => C_B_OBUF_17,
      O => C_B
    );
  Y_3_OBUF : OBUF
    port map (
      I => Y_3_OBUF_60,
      O => Y(3)
    );
  Y_2_OBUF : OBUF
    port map (
      I => Y_2_OBUF_59,
      O => Y(2)
    );
  Y_1_OBUF : OBUF
    port map (
      I => Y_1_OBUF_58,
      O => Y(1)
    );
  Y_0_OBUF : OBUF
    port map (
      I => Y_0_OBUF_57,
      O => Y(0)
    );
  Mmux_result_57 : LUT3
    generic map(
      INIT => X"6E"
    )
    port map (
      I0 => A_3_IBUF_7,
      I1 => B_3_IBUF_15,
      I2 => F_0_IBUF_22,
      O => Mmux_result_57_45
    );
  Mmux_result_55 : LUT3
    generic map(
      INIT => X"6E"
    )
    port map (
      I0 => A_2_IBUF_6,
      I1 => B_2_IBUF_14,
      I2 => F_0_IBUF_22,
      O => Mmux_result_55_43
    );
  Mmux_result_53 : LUT3
    generic map(
      INIT => X"6E"
    )
    port map (
      I0 => A_1_IBUF_5,
      I1 => B_1_IBUF_13,
      I2 => F_0_IBUF_22,
      O => Mmux_result_53_41
    );
  Mmux_result_51 : LUT3
    generic map(
      INIT => X"6E"
    )
    port map (
      I0 => A_0_IBUF_4,
      I1 => B_0_IBUF_12,
      I2 => F_0_IBUF_22,
      O => Mmux_result_51_39
    );
  Mmux_C_B140_SW0 : LUT3
    generic map(
      INIT => X"BA"
    )
    port map (
      I0 => Mmux_C_B122_28,
      I1 => A_3_IBUF_7,
      I2 => B_3_IBUF_15,
      O => N6
    );
  Mmux_C_B140 : LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      I0 => F_0_IBUF_22,
      I1 => F_1_IBUF_23,
      I2 => F_2_IBUF_24,
      I3 => N6,
      O => C_B_OBUF_17
    );
  Maddsub_result_addsub0000_xor_0_11 : LUT2
    generic map(
      INIT => X"6"
    )
    port map (
      I0 => A_0_IBUF_4,
      I1 => B_0_IBUF_12,
      O => result_addsub0000(0)
    );
  Maddsub_result_addsub0000_xor_3_11_SW0 : LUT4
    generic map(
      INIT => X"4DE8"
    )
    port map (
      I0 => Maddsub_result_addsub0000_cy(1),
      I1 => B_2_IBUF_14,
      I2 => A_2_IBUF_6,
      I3 => result_mux00001_65,
      O => N8
    );
  Maddsub_result_addsub0000_xor_3_11 : LUT3
    generic map(
      INIT => X"96"
    )
    port map (
      I0 => A_3_IBUF_7,
      I1 => B_3_IBUF_15,
      I2 => N8,
      O => result_addsub0000(3)
    );
  Maddsub_result_addsub0000_xor_2_11 : LUT4
    generic map(
      INIT => X"6996"
    )
    port map (
      I0 => A_2_IBUF_6,
      I1 => B_2_IBUF_14,
      I2 => result_mux00001_65,
      I3 => Maddsub_result_addsub0000_cy(1),
      O => result_addsub0000(2)
    );
  Mmux_result_56 : LUT3
    generic map(
      INIT => X"59"
    )
    port map (
      I0 => A_3_IBUF_7,
      I1 => B_3_IBUF_15,
      I2 => F_0_IBUF_22,
      O => Mmux_result_56_44
    );
  Mmux_result_54 : LUT3
    generic map(
      INIT => X"59"
    )
    port map (
      I0 => A_2_IBUF_6,
      I1 => B_2_IBUF_14,
      I2 => F_0_IBUF_22,
      O => Mmux_result_54_42
    );
  Mmux_result_52 : LUT3
    generic map(
      INIT => X"59"
    )
    port map (
      I0 => A_1_IBUF_5,
      I1 => B_1_IBUF_13,
      I2 => F_0_IBUF_22,
      O => Mmux_result_52_40
    );
  Mmux_result_5 : LUT3
    generic map(
      INIT => X"59"
    )
    port map (
      I0 => A_0_IBUF_4,
      I1 => B_0_IBUF_12,
      I2 => F_0_IBUF_22,
      O => Mmux_result_5_38
    );
  Mmux_result_63 : LUT3
    generic map(
      INIT => X"6A"
    )
    port map (
      I0 => F_0_IBUF_22,
      I1 => A_3_IBUF_7,
      I2 => B_3_IBUF_15,
      O => Mmux_result_63_49
    );
  Mmux_result_62 : LUT3
    generic map(
      INIT => X"6A"
    )
    port map (
      I0 => F_0_IBUF_22,
      I1 => A_2_IBUF_6,
      I2 => B_2_IBUF_14,
      O => Mmux_result_62_48
    );
  Mmux_result_61 : LUT3
    generic map(
      INIT => X"6A"
    )
    port map (
      I0 => F_0_IBUF_22,
      I1 => A_1_IBUF_5,
      I2 => B_1_IBUF_13,
      O => Mmux_result_61_47
    );
  Mmux_result_6 : LUT3
    generic map(
      INIT => X"6A"
    )
    port map (
      I0 => F_0_IBUF_22,
      I1 => A_0_IBUF_4,
      I2 => B_0_IBUF_12,
      O => Mmux_result_6_46
    );
  Maddsub_result_addsub0000_xor_1_11_SW0 : LUT4
    generic map(
      INIT => X"AA6A"
    )
    port map (
      I0 => A_0_IBUF_4,
      I1 => F_2_IBUF_24,
      I2 => F_1_IBUF_23,
      I3 => F_0_IBUF_22,
      O => N10
    );
  Maddsub_result_addsub0000_xor_1_11 : LUT4
    generic map(
      INIT => X"6966"
    )
    port map (
      I0 => A_1_IBUF_5,
      I1 => B_1_IBUF_13,
      I2 => N10,
      I3 => B_0_IBUF_12,
      O => result_addsub0000(1)
    );
  Maddsub_result_addsub0000_cy_1_11 : LUT4
    generic map(
      INIT => X"F751"
    )
    port map (
      I0 => B_1_IBUF_13,
      I1 => B_0_IBUF_12,
      I2 => A_0_IBUF_4,
      I3 => A_1_IBUF_5,
      O => Maddsub_result_addsub0000_cy_1_1
    );
  Maddsub_result_addsub0000_cy_1_12 : LUT4
    generic map(
      INIT => X"F880"
    )
    port map (
      I0 => A_0_IBUF_4,
      I1 => B_0_IBUF_12,
      I2 => B_1_IBUF_13,
      I3 => A_1_IBUF_5,
      O => Maddsub_result_addsub0000_cy_1_11_27
    );
  Maddsub_result_addsub0000_cy_1_1_f5 : MUXF5
    port map (
      I0 => Maddsub_result_addsub0000_cy_1_11_27,
      I1 => Maddsub_result_addsub0000_cy_1_1,
      S => result_mux00001_65,
      O => Maddsub_result_addsub0000_cy(1)
    );

end Structure;

