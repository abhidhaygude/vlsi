/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/42179/Experiment_1/alu_4bit.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1547198987_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_1547270861_1035706684(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_1242562249_sub_2110339434_1035706684(char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1697423399_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);
char *ieee_p_2592010699_sub_3798478767_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_43738421_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);


static void work_a_1542279369_3212880686_p_0(char *t0)
{
    char t26[16];
    char t33[16];
    char t40[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    int t25;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t41;
    unsigned int t42;
    unsigned char t43;

LAB0:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 2104);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(44, ng0);
    t1 = (t0 + 776U);
    t2 = *((char **)t1);
    t1 = (t0 + 3524);
    t6 = xsi_mem_cmp(t1, t2, 3U);
    if (t6 == 1)
        goto LAB3;

LAB12:    t4 = (t0 + 3527);
    t7 = xsi_mem_cmp(t4, t2, 3U);
    if (t7 == 1)
        goto LAB4;

LAB13:    t8 = (t0 + 3530);
    t10 = xsi_mem_cmp(t8, t2, 3U);
    if (t10 == 1)
        goto LAB5;

LAB14:    t11 = (t0 + 3533);
    t13 = xsi_mem_cmp(t11, t2, 3U);
    if (t13 == 1)
        goto LAB6;

LAB15:    t14 = (t0 + 3536);
    t16 = xsi_mem_cmp(t14, t2, 3U);
    if (t16 == 1)
        goto LAB7;

LAB16:    t17 = (t0 + 3539);
    t19 = xsi_mem_cmp(t17, t2, 3U);
    if (t19 == 1)
        goto LAB8;

LAB17:    t20 = (t0 + 3542);
    t22 = xsi_mem_cmp(t20, t2, 3U);
    if (t22 == 1)
        goto LAB9;

LAB18:    t23 = (t0 + 3545);
    t25 = xsi_mem_cmp(t23, t2, 3U);
    if (t25 == 1)
        goto LAB10;

LAB19:
LAB11:    xsi_set_current_line(85, ng0);
    t1 = xsi_get_transient_memory(5U);
    memset(t1, 0, 5U);
    t2 = t1;
    memset(t2, (unsigned char)2, 5U);
    t3 = (t0 + 2140);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t8 = (t5 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 5U);
    xsi_driver_first_trans_fast(t3);
    xsi_set_current_line(86, ng0);
    t1 = (t0 + 2104);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t1 = (t0 + 2052);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(48, ng0);
    t27 = (t0 + 592U);
    t28 = *((char **)t27);
    t27 = (t0 + 3420U);
    t29 = (t0 + 684U);
    t30 = *((char **)t29);
    t29 = (t0 + 3436U);
    t31 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t26, t28, t27, t30, t29);
    t34 = ((IEEE_P_2592010699) + 2332);
    t32 = xsi_base_array_concat(t32, t33, t34, (char)99, (unsigned char)2, (char)97, t31, t26, (char)101);
    t35 = (t0 + 2140);
    t36 = (t35 + 32U);
    t37 = *((char **)t36);
    t38 = (t37 + 40U);
    t39 = *((char **)t38);
    memcpy(t39, t32, 5U);
    xsi_driver_first_trans_fast(t35);
    goto LAB2;

LAB4:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3420U);
    t3 = (t0 + 684U);
    t4 = *((char **)t3);
    t3 = (t0 + 3436U);
    t5 = ieee_p_2592010699_sub_3798478767_503743352(IEEE_P_2592010699, t26, t2, t1, t4, t3);
    t9 = ((IEEE_P_2592010699) + 2332);
    t8 = xsi_base_array_concat(t8, t33, t9, (char)99, (unsigned char)2, (char)97, t5, t26, (char)101);
    t11 = (t0 + 2140);
    t12 = (t11 + 32U);
    t14 = *((char **)t12);
    t15 = (t14 + 40U);
    t17 = *((char **)t15);
    memcpy(t17, t8, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB2;

LAB5:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3420U);
    t3 = (t0 + 684U);
    t4 = *((char **)t3);
    t3 = (t0 + 3436U);
    t5 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t26, t2, t1, t4, t3);
    t9 = ((IEEE_P_2592010699) + 2332);
    t8 = xsi_base_array_concat(t8, t33, t9, (char)99, (unsigned char)2, (char)97, t5, t26, (char)101);
    t11 = (t0 + 2140);
    t12 = (t11 + 32U);
    t14 = *((char **)t12);
    t15 = (t14 + 40U);
    t17 = *((char **)t15);
    memcpy(t17, t8, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB2;

LAB6:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3420U);
    t3 = (t0 + 684U);
    t4 = *((char **)t3);
    t3 = (t0 + 3436U);
    t5 = ieee_p_2592010699_sub_1697423399_503743352(IEEE_P_2592010699, t26, t2, t1, t4, t3);
    t9 = ((IEEE_P_2592010699) + 2332);
    t8 = xsi_base_array_concat(t8, t33, t9, (char)99, (unsigned char)2, (char)97, t5, t26, (char)101);
    t11 = (t0 + 2140);
    t12 = (t11 + 32U);
    t14 = *((char **)t12);
    t15 = (t14 + 40U);
    t17 = *((char **)t15);
    memcpy(t17, t8, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB2;

LAB7:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3420U);
    t3 = (t0 + 684U);
    t4 = *((char **)t3);
    t3 = (t0 + 3436U);
    t5 = ieee_p_2592010699_sub_43738421_503743352(IEEE_P_2592010699, t26, t2, t1, t4, t3);
    t9 = ((IEEE_P_2592010699) + 2332);
    t8 = xsi_base_array_concat(t8, t33, t9, (char)99, (unsigned char)2, (char)97, t5, t26, (char)101);
    t11 = (t0 + 2140);
    t12 = (t11 + 32U);
    t14 = *((char **)t12);
    t15 = (t14 + 40U);
    t17 = *((char **)t15);
    memcpy(t17, t8, 5U);
    xsi_driver_first_trans_fast(t11);
    goto LAB2;

LAB8:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3420U);
    t3 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t26, t2, t1);
    t5 = ((IEEE_P_2592010699) + 2332);
    t4 = xsi_base_array_concat(t4, t33, t5, (char)99, (unsigned char)2, (char)97, t3, t26, (char)101);
    t8 = (t0 + 2140);
    t9 = (t8 + 32U);
    t11 = *((char **)t9);
    t12 = (t11 + 40U);
    t14 = *((char **)t12);
    memcpy(t14, t4, 5U);
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB9:    xsi_set_current_line(72, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_2592010699) + 2332);
    t4 = (t0 + 3420U);
    t1 = xsi_base_array_concat(t1, t33, t3, (char)99, (unsigned char)2, (char)97, t2, t4, (char)101);
    t5 = (t0 + 684U);
    t8 = *((char **)t5);
    t9 = ((IEEE_P_2592010699) + 2332);
    t11 = (t0 + 3436U);
    t5 = xsi_base_array_concat(t5, t40, t9, (char)99, (unsigned char)2, (char)97, t8, t11, (char)101);
    t12 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t26, t1, t33, t5, t40);
    t14 = (t26 + 12U);
    t41 = *((unsigned int *)t14);
    t42 = (1U * t41);
    t43 = (5U != t42);
    if (t43 == 1)
        goto LAB21;

LAB22:    t15 = (t0 + 2140);
    t17 = (t15 + 32U);
    t18 = *((char **)t17);
    t20 = (t18 + 40U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 5U);
    xsi_driver_first_trans_fast(t15);
    goto LAB2;

LAB10:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_2592010699) + 2332);
    t4 = (t0 + 3420U);
    t1 = xsi_base_array_concat(t1, t33, t3, (char)99, (unsigned char)2, (char)97, t2, t4, (char)101);
    t5 = (t0 + 684U);
    t8 = *((char **)t5);
    t9 = ((IEEE_P_2592010699) + 2332);
    t11 = (t0 + 3436U);
    t5 = xsi_base_array_concat(t5, t40, t9, (char)99, (unsigned char)2, (char)97, t8, t11, (char)101);
    t12 = ieee_p_1242562249_sub_1547270861_1035706684(IEEE_P_1242562249, t26, t1, t33, t5, t40);
    t14 = (t26 + 12U);
    t41 = *((unsigned int *)t14);
    t42 = (1U * t41);
    t43 = (5U != t42);
    if (t43 == 1)
        goto LAB23;

LAB24:    t15 = (t0 + 2140);
    t17 = (t15 + 32U);
    t18 = *((char **)t17);
    t20 = (t18 + 40U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 5U);
    xsi_driver_first_trans_fast(t15);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 3420U);
    t3 = (t0 + 684U);
    t4 = *((char **)t3);
    t3 = (t0 + 3436U);
    t43 = ieee_p_1242562249_sub_2110339434_1035706684(IEEE_P_1242562249, t2, t1, t4, t3);
    if (t43 != 0)
        goto LAB25;

LAB27:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 2104);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t4 = (t3 + 40U);
    t5 = *((char **)t4);
    *((unsigned char *)t5) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB26:    goto LAB2;

LAB20:;
LAB21:    xsi_size_not_matching(5U, t42, 0);
    goto LAB22;

LAB23:    xsi_size_not_matching(5U, t42, 0);
    goto LAB24;

LAB25:    xsi_set_current_line(79, ng0);
    t5 = (t0 + 2104);
    t8 = (t5 + 32U);
    t9 = *((char **)t8);
    t11 = (t9 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t5);
    goto LAB26;

}

static void work_a_1542279369_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(92, ng0);

LAB3:    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t3 = (4 - 3);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 2176);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);

LAB2:    t11 = (t0 + 2060);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_1542279369_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1542279369_3212880686_p_0,(void *)work_a_1542279369_3212880686_p_1};
	xsi_register_didat("work_a_1542279369_3212880686", "isim/alu_4bit_tb_isim_beh.exe.sim/work/a_1542279369_3212880686.didat");
	xsi_register_executes(pe);
}
