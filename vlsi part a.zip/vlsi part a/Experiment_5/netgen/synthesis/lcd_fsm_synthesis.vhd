--------------------------------------------------------------------------------
-- Copyright (c) 1995-2013 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____
--  /   /\/   /
-- /___/  \  /    Vendor: Xilinx
-- \   \   \/     Version: P.20131013
--  \   \         Application: netgen
--  /   /         Filename: lcd_fsm_synthesis.vhd
-- /___/   /\     Timestamp: Fri Sep 04 06:31:17 2026
-- \   \  /  \ 
--  \___\/\___\
--             
-- Command	: -intstyle ise -ar Structure -tm lcd_fsm -w -dir netgen/synthesis -ofmt vhdl -sim lcd_fsm.ngc lcd_fsm_synthesis.vhd 
-- Device	: xc3s250e-5-pq208
-- Input file	: lcd_fsm.ngc
-- Output file	: D:\42226_Asmita\Experiment_5\netgen\synthesis\lcd_fsm_synthesis.vhd
-- # of Entities	: 1
-- Design Name	: lcd_fsm
-- Xilinx	: C:\Xilinx\14.7\ISE_DS\ISE\
--             
-- Purpose:    
--     This VHDL netlist is a verification model and uses simulation 
--     primitives which may not represent the true implementation of the 
--     device, however the netlist is functionally correct and should not 
--     be modified. This file cannot be synthesized and should only be used 
--     with supported simulation tools.
--             
-- Reference:  
--     Command Line Tools User Guide, Chapter 23
--     Synthesis and Simulation Design Guide, Chapter 6
--             
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
use UNISIM.VPKG.ALL;

entity lcd_fsm is
  port (
    clk : in STD_LOGIC := 'X'; 
    lcd_en : out STD_LOGIC; 
    rst : in STD_LOGIC := 'X'; 
    lcd_rs : out STD_LOGIC; 
    lcd_data : out STD_LOGIC_VECTOR ( 7 downto 0 ) 
  );
end lcd_fsm;

architecture Structure of lcd_fsm is
  signal Mcount_div_cy_10_rt_2 : STD_LOGIC; 
  signal Mcount_div_cy_11_rt_4 : STD_LOGIC; 
  signal Mcount_div_cy_12_rt_6 : STD_LOGIC; 
  signal Mcount_div_cy_13_rt_8 : STD_LOGIC; 
  signal Mcount_div_cy_14_rt_10 : STD_LOGIC; 
  signal Mcount_div_cy_1_rt_12 : STD_LOGIC; 
  signal Mcount_div_cy_2_rt_14 : STD_LOGIC; 
  signal Mcount_div_cy_3_rt_16 : STD_LOGIC; 
  signal Mcount_div_cy_4_rt_18 : STD_LOGIC; 
  signal Mcount_div_cy_5_rt_20 : STD_LOGIC; 
  signal Mcount_div_cy_6_rt_22 : STD_LOGIC; 
  signal Mcount_div_cy_7_rt_24 : STD_LOGIC; 
  signal Mcount_div_cy_8_rt_26 : STD_LOGIC; 
  signal Mcount_div_cy_9_rt_28 : STD_LOGIC; 
  signal Mcount_div_xor_15_rt_30 : STD_LOGIC; 
  signal N0 : STD_LOGIC; 
  signal N1 : STD_LOGIC; 
  signal clk_BUFGP_50 : STD_LOGIC; 
  signal lcd_data_0_OBUF_75 : STD_LOGIC; 
  signal lcd_data_1_OBUF_76 : STD_LOGIC; 
  signal lcd_data_2_OBUF_77 : STD_LOGIC; 
  signal lcd_data_3_OBUF_78 : STD_LOGIC; 
  signal lcd_data_4_OBUF_79 : STD_LOGIC; 
  signal lcd_data_5_OBUF_80 : STD_LOGIC; 
  signal lcd_data_6_OBUF_81 : STD_LOGIC; 
  signal lcd_rs_OBUF_84 : STD_LOGIC; 
  signal ps1_FSM_FFd10_85 : STD_LOGIC; 
  signal ps1_FSM_FFd11_86 : STD_LOGIC; 
  signal ps1_FSM_FFd2_87 : STD_LOGIC; 
  signal ps1_FSM_FFd3_88 : STD_LOGIC; 
  signal ps1_FSM_FFd4_89 : STD_LOGIC; 
  signal ps1_FSM_FFd5_90 : STD_LOGIC; 
  signal ps1_FSM_FFd6_91 : STD_LOGIC; 
  signal ps1_FSM_FFd7_92 : STD_LOGIC; 
  signal ps1_FSM_FFd8_93 : STD_LOGIC; 
  signal ps1_FSM_FFd9_94 : STD_LOGIC; 
  signal ps1_FSM_Out8 : STD_LOGIC; 
  signal rst_IBUF_97 : STD_LOGIC; 
  signal Mcount_div_cy : STD_LOGIC_VECTOR ( 14 downto 0 ); 
  signal Mcount_div_lut : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal Result : STD_LOGIC_VECTOR ( 15 downto 0 ); 
  signal div : STD_LOGIC_VECTOR ( 15 downto 0 ); 
begin
  XST_GND : GND
    port map (
      G => N0
    );
  XST_VCC : VCC
    port map (
      P => N1
    );
  div_0 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(0),
      Q => div(0)
    );
  div_1 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(1),
      Q => div(1)
    );
  div_2 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(2),
      Q => div(2)
    );
  div_3 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(3),
      Q => div(3)
    );
  div_4 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(4),
      Q => div(4)
    );
  div_5 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(5),
      Q => div(5)
    );
  div_6 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(6),
      Q => div(6)
    );
  div_7 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(7),
      Q => div(7)
    );
  div_8 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(8),
      Q => div(8)
    );
  div_9 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(9),
      Q => div(9)
    );
  div_10 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(10),
      Q => div(10)
    );
  div_11 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(11),
      Q => div(11)
    );
  div_12 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(12),
      Q => div(12)
    );
  div_13 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(13),
      Q => div(13)
    );
  div_14 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(14),
      Q => div(14)
    );
  div_15 : FDC
    port map (
      C => clk_BUFGP_50,
      CLR => rst_IBUF_97,
      D => Result(15),
      Q => div(15)
    );
  Mcount_div_cy_0_Q : MUXCY
    port map (
      CI => N0,
      DI => N1,
      S => Mcount_div_lut(0),
      O => Mcount_div_cy(0)
    );
  Mcount_div_xor_0_Q : XORCY
    port map (
      CI => N0,
      LI => Mcount_div_lut(0),
      O => Result(0)
    );
  Mcount_div_cy_1_Q : MUXCY
    port map (
      CI => Mcount_div_cy(0),
      DI => N0,
      S => Mcount_div_cy_1_rt_12,
      O => Mcount_div_cy(1)
    );
  Mcount_div_xor_1_Q : XORCY
    port map (
      CI => Mcount_div_cy(0),
      LI => Mcount_div_cy_1_rt_12,
      O => Result(1)
    );
  Mcount_div_cy_2_Q : MUXCY
    port map (
      CI => Mcount_div_cy(1),
      DI => N0,
      S => Mcount_div_cy_2_rt_14,
      O => Mcount_div_cy(2)
    );
  Mcount_div_xor_2_Q : XORCY
    port map (
      CI => Mcount_div_cy(1),
      LI => Mcount_div_cy_2_rt_14,
      O => Result(2)
    );
  Mcount_div_cy_3_Q : MUXCY
    port map (
      CI => Mcount_div_cy(2),
      DI => N0,
      S => Mcount_div_cy_3_rt_16,
      O => Mcount_div_cy(3)
    );
  Mcount_div_xor_3_Q : XORCY
    port map (
      CI => Mcount_div_cy(2),
      LI => Mcount_div_cy_3_rt_16,
      O => Result(3)
    );
  Mcount_div_cy_4_Q : MUXCY
    port map (
      CI => Mcount_div_cy(3),
      DI => N0,
      S => Mcount_div_cy_4_rt_18,
      O => Mcount_div_cy(4)
    );
  Mcount_div_xor_4_Q : XORCY
    port map (
      CI => Mcount_div_cy(3),
      LI => Mcount_div_cy_4_rt_18,
      O => Result(4)
    );
  Mcount_div_cy_5_Q : MUXCY
    port map (
      CI => Mcount_div_cy(4),
      DI => N0,
      S => Mcount_div_cy_5_rt_20,
      O => Mcount_div_cy(5)
    );
  Mcount_div_xor_5_Q : XORCY
    port map (
      CI => Mcount_div_cy(4),
      LI => Mcount_div_cy_5_rt_20,
      O => Result(5)
    );
  Mcount_div_cy_6_Q : MUXCY
    port map (
      CI => Mcount_div_cy(5),
      DI => N0,
      S => Mcount_div_cy_6_rt_22,
      O => Mcount_div_cy(6)
    );
  Mcount_div_xor_6_Q : XORCY
    port map (
      CI => Mcount_div_cy(5),
      LI => Mcount_div_cy_6_rt_22,
      O => Result(6)
    );
  Mcount_div_cy_7_Q : MUXCY
    port map (
      CI => Mcount_div_cy(6),
      DI => N0,
      S => Mcount_div_cy_7_rt_24,
      O => Mcount_div_cy(7)
    );
  Mcount_div_xor_7_Q : XORCY
    port map (
      CI => Mcount_div_cy(6),
      LI => Mcount_div_cy_7_rt_24,
      O => Result(7)
    );
  Mcount_div_cy_8_Q : MUXCY
    port map (
      CI => Mcount_div_cy(7),
      DI => N0,
      S => Mcount_div_cy_8_rt_26,
      O => Mcount_div_cy(8)
    );
  Mcount_div_xor_8_Q : XORCY
    port map (
      CI => Mcount_div_cy(7),
      LI => Mcount_div_cy_8_rt_26,
      O => Result(8)
    );
  Mcount_div_cy_9_Q : MUXCY
    port map (
      CI => Mcount_div_cy(8),
      DI => N0,
      S => Mcount_div_cy_9_rt_28,
      O => Mcount_div_cy(9)
    );
  Mcount_div_xor_9_Q : XORCY
    port map (
      CI => Mcount_div_cy(8),
      LI => Mcount_div_cy_9_rt_28,
      O => Result(9)
    );
  Mcount_div_cy_10_Q : MUXCY
    port map (
      CI => Mcount_div_cy(9),
      DI => N0,
      S => Mcount_div_cy_10_rt_2,
      O => Mcount_div_cy(10)
    );
  Mcount_div_xor_10_Q : XORCY
    port map (
      CI => Mcount_div_cy(9),
      LI => Mcount_div_cy_10_rt_2,
      O => Result(10)
    );
  Mcount_div_cy_11_Q : MUXCY
    port map (
      CI => Mcount_div_cy(10),
      DI => N0,
      S => Mcount_div_cy_11_rt_4,
      O => Mcount_div_cy(11)
    );
  Mcount_div_xor_11_Q : XORCY
    port map (
      CI => Mcount_div_cy(10),
      LI => Mcount_div_cy_11_rt_4,
      O => Result(11)
    );
  Mcount_div_cy_12_Q : MUXCY
    port map (
      CI => Mcount_div_cy(11),
      DI => N0,
      S => Mcount_div_cy_12_rt_6,
      O => Mcount_div_cy(12)
    );
  Mcount_div_xor_12_Q : XORCY
    port map (
      CI => Mcount_div_cy(11),
      LI => Mcount_div_cy_12_rt_6,
      O => Result(12)
    );
  Mcount_div_cy_13_Q : MUXCY
    port map (
      CI => Mcount_div_cy(12),
      DI => N0,
      S => Mcount_div_cy_13_rt_8,
      O => Mcount_div_cy(13)
    );
  Mcount_div_xor_13_Q : XORCY
    port map (
      CI => Mcount_div_cy(12),
      LI => Mcount_div_cy_13_rt_8,
      O => Result(13)
    );
  Mcount_div_cy_14_Q : MUXCY
    port map (
      CI => Mcount_div_cy(13),
      DI => N0,
      S => Mcount_div_cy_14_rt_10,
      O => Mcount_div_cy(14)
    );
  Mcount_div_xor_14_Q : XORCY
    port map (
      CI => Mcount_div_cy(13),
      LI => Mcount_div_cy_14_rt_10,
      O => Result(14)
    );
  Mcount_div_xor_15_Q : XORCY
    port map (
      CI => Mcount_div_cy(14),
      LI => Mcount_div_xor_15_rt_30,
      O => Result(15)
    );
  ps1_FSM_FFd11 : FDP
    generic map(
      INIT => '1'
    )
    port map (
      C => div(15),
      D => N0,
      PRE => rst_IBUF_97,
      Q => ps1_FSM_FFd11_86
    );
  ps1_FSM_FFd10 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd11_86,
      Q => ps1_FSM_FFd10_85
    );
  ps1_FSM_FFd9 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd10_85,
      Q => ps1_FSM_FFd9_94
    );
  ps1_FSM_FFd8 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd9_94,
      Q => ps1_FSM_FFd8_93
    );
  ps1_FSM_FFd7 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd8_93,
      Q => ps1_FSM_FFd7_92
    );
  ps1_FSM_FFd6 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd7_92,
      Q => ps1_FSM_FFd6_91
    );
  ps1_FSM_FFd5 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd6_91,
      Q => ps1_FSM_FFd5_90
    );
  ps1_FSM_FFd4 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd5_90,
      Q => ps1_FSM_FFd4_89
    );
  ps1_FSM_FFd3 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd4_89,
      Q => ps1_FSM_FFd3_88
    );
  ps1_FSM_FFd2 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => div(15),
      CLR => rst_IBUF_97,
      D => ps1_FSM_FFd3_88,
      Q => ps1_FSM_FFd2_87
    );
  ps1_FSM_Out61 : LUT2
    generic map(
      INIT => X"E"
    )
    port map (
      I0 => ps1_FSM_FFd4_89,
      I1 => ps1_FSM_FFd9_94,
      O => lcd_data_1_OBUF_76
    );
  ps1_FSM_Out71 : LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      I0 => ps1_FSM_FFd5_90,
      I1 => ps1_FSM_FFd7_92,
      I2 => ps1_FSM_FFd4_89,
      O => lcd_data_0_OBUF_75
    );
  ps1_FSM_Out51 : LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      I0 => ps1_FSM_FFd9_94,
      I1 => ps1_FSM_FFd3_88,
      I2 => ps1_FSM_FFd8_93,
      O => lcd_data_2_OBUF_77
    );
  ps1_FSM_Out21 : LUT3
    generic map(
      INIT => X"FE"
    )
    port map (
      I0 => ps1_FSM_FFd11_86,
      I1 => ps1_FSM_FFd2_87,
      I2 => ps1_FSM_FFd10_85,
      O => lcd_data_5_OBUF_80
    );
  ps1_FSM_Out41 : LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      I0 => ps1_FSM_FFd5_90,
      I1 => ps1_FSM_FFd11_86,
      I2 => ps1_FSM_FFd10_85,
      I3 => ps1_FSM_FFd8_93,
      O => lcd_data_3_OBUF_78
    );
  ps1_FSM_Out31 : LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      I0 => ps1_FSM_FFd3_88,
      I1 => ps1_FSM_FFd11_86,
      I2 => ps1_FSM_FFd10_85,
      I3 => ps1_FSM_FFd6_91,
      O => lcd_data_4_OBUF_79
    );
  ps1_FSM_Out11 : LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      I0 => ps1_FSM_FFd3_88,
      I1 => ps1_FSM_FFd6_91,
      I2 => ps1_FSM_FFd5_90,
      I3 => ps1_FSM_FFd4_89,
      O => lcd_data_6_OBUF_81
    );
  rst_IBUF : IBUF
    port map (
      I => rst,
      O => rst_IBUF_97
    );
  lcd_en_OBUF : OBUF
    port map (
      I => div(15),
      O => lcd_en
    );
  lcd_rs_OBUF : OBUF
    port map (
      I => lcd_rs_OBUF_84,
      O => lcd_rs
    );
  lcd_data_7_OBUF : OBUF
    port map (
      I => N0,
      O => lcd_data(7)
    );
  lcd_data_6_OBUF : OBUF
    port map (
      I => lcd_data_6_OBUF_81,
      O => lcd_data(6)
    );
  lcd_data_5_OBUF : OBUF
    port map (
      I => lcd_data_5_OBUF_80,
      O => lcd_data(5)
    );
  lcd_data_4_OBUF : OBUF
    port map (
      I => lcd_data_4_OBUF_79,
      O => lcd_data(4)
    );
  lcd_data_3_OBUF : OBUF
    port map (
      I => lcd_data_3_OBUF_78,
      O => lcd_data(3)
    );
  lcd_data_2_OBUF : OBUF
    port map (
      I => lcd_data_2_OBUF_77,
      O => lcd_data(2)
    );
  lcd_data_1_OBUF : OBUF
    port map (
      I => lcd_data_1_OBUF_76,
      O => lcd_data(1)
    );
  lcd_data_0_OBUF : OBUF
    port map (
      I => lcd_data_0_OBUF_75,
      O => lcd_data(0)
    );
  Mcount_div_cy_1_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(1),
      O => Mcount_div_cy_1_rt_12
    );
  Mcount_div_cy_2_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(2),
      O => Mcount_div_cy_2_rt_14
    );
  Mcount_div_cy_3_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(3),
      O => Mcount_div_cy_3_rt_16
    );
  Mcount_div_cy_4_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(4),
      O => Mcount_div_cy_4_rt_18
    );
  Mcount_div_cy_5_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(5),
      O => Mcount_div_cy_5_rt_20
    );
  Mcount_div_cy_6_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(6),
      O => Mcount_div_cy_6_rt_22
    );
  Mcount_div_cy_7_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(7),
      O => Mcount_div_cy_7_rt_24
    );
  Mcount_div_cy_8_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(8),
      O => Mcount_div_cy_8_rt_26
    );
  Mcount_div_cy_9_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(9),
      O => Mcount_div_cy_9_rt_28
    );
  Mcount_div_cy_10_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(10),
      O => Mcount_div_cy_10_rt_2
    );
  Mcount_div_cy_11_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(11),
      O => Mcount_div_cy_11_rt_4
    );
  Mcount_div_cy_12_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(12),
      O => Mcount_div_cy_12_rt_6
    );
  Mcount_div_cy_13_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(13),
      O => Mcount_div_cy_13_rt_8
    );
  Mcount_div_cy_14_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(14),
      O => Mcount_div_cy_14_rt_10
    );
  Mcount_div_xor_15_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => div(15),
      O => Mcount_div_xor_15_rt_30
    );
  clk_BUFGP : BUFGP
    port map (
      I => clk,
      O => clk_BUFGP_50
    );
  Mcount_div_lut_0_INV_0 : INV
    port map (
      I => div(0),
      O => Mcount_div_lut(0)
    );
  ps1_FSM_Out81 : LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      I0 => ps1_FSM_FFd2_87,
      I1 => ps1_FSM_FFd5_90,
      I2 => ps1_FSM_FFd4_89,
      I3 => ps1_FSM_FFd3_88,
      O => ps1_FSM_Out8
    );
  ps1_FSM_Out8_f5 : MUXF5
    port map (
      I0 => ps1_FSM_Out8,
      I1 => N1,
      S => ps1_FSM_FFd6_91,
      O => lcd_rs_OBUF_84
    );

end Structure;

