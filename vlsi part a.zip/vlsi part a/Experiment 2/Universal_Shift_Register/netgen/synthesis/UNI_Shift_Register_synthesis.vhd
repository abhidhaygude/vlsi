--------------------------------------------------------------------------------
-- Copyright (c) 1995-2013 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____
--  /   /\/   /
-- /___/  \  /    Vendor: Xilinx
-- \   \   \/     Version: P.20131013
--  \   \         Application: netgen
--  /   /         Filename: UNI_Shift_Register_synthesis.vhd
-- /___/   /\     Timestamp: Fri Aug 14 06:56:13 2026
-- \   \  /  \ 
--  \___\/\___\
--             
-- Command	: -intstyle ise -ar Structure -tm UNI_Shift_Register -w -dir netgen/synthesis -ofmt vhdl -sim UNI_Shift_Register.ngc UNI_Shift_Register_synthesis.vhd 
-- Device	: xc3s250e-5-pq208
-- Input file	: UNI_Shift_Register.ngc
-- Output file	: D:\42226_Asmita\Experiment 2\Universal_Shift_Register\netgen\synthesis\UNI_Shift_Register_synthesis.vhd
-- # of Entities	: 1
-- Design Name	: UNI_Shift_Register
-- Xilinx	: C:\Xilinx\14.7\ISE_DS\ISE\
--             
-- Purpose:    
--     This VHDL netlist is a verification model and uses simulation 
--     primitives which may not represent the true implementation of the 
--     device, however the netlist is functionally correct and should not 
--     be modified. This file cannot be synthesized and should only be used 
--     with supported simulation tools.
--             
-- Reference:  
--     Command Line Tools User Guide, Chapter 23
--     Synthesis and Simulation Design Guide, Chapter 6
--             
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
use UNISIM.VPKG.ALL;

entity UNI_Shift_Register is
  port (
    clk : in STD_LOGIC := 'X'; 
    Sin : in STD_LOGIC := 'X'; 
    rst : in STD_LOGIC := 'X'; 
    Sout : out STD_LOGIC; 
    Pout : out STD_LOGIC_VECTOR ( 3 downto 0 ); 
    mode : in STD_LOGIC_VECTOR ( 1 downto 0 ); 
    Pin : in STD_LOGIC_VECTOR ( 3 downto 0 ) 
  );
end UNI_Shift_Register;

architecture Structure of UNI_Shift_Register is
  signal N2 : STD_LOGIC; 
  signal N3 : STD_LOGIC; 
  signal Pin_0_IBUF_6 : STD_LOGIC; 
  signal Pin_1_IBUF_7 : STD_LOGIC; 
  signal Pin_2_IBUF_8 : STD_LOGIC; 
  signal Pin_3_IBUF_9 : STD_LOGIC; 
  signal Pout_0_14 : STD_LOGIC; 
  signal Pout_1_15 : STD_LOGIC; 
  signal Pout_2_16 : STD_LOGIC; 
  signal Pout_3_17 : STD_LOGIC; 
  signal Sin_IBUF_23 : STD_LOGIC; 
  signal Sout_OBUF_25 : STD_LOGIC; 
  signal Sout_mux0001 : STD_LOGIC; 
  signal clk_BUFGP_28 : STD_LOGIC; 
  signal mode_0_IBUF_31 : STD_LOGIC; 
  signal mode_1_IBUF_32 : STD_LOGIC; 
  signal rst_IBUF_34 : STD_LOGIC; 
  signal rst_inv : STD_LOGIC; 
  signal temp_0_mux0000 : STD_LOGIC; 
  signal temp_1_mux0000 : STD_LOGIC; 
  signal temp_2_mux0000 : STD_LOGIC; 
  signal temp_3_mux0000 : STD_LOGIC; 
  signal Pout_mux0001 : STD_LOGIC_VECTOR ( 3 downto 0 ); 
  signal temp : STD_LOGIC_VECTOR ( 3 downto 0 ); 
begin
  Sout_1 : FDC_1
    port map (
      C => clk_BUFGP_28,
      CLR => rst_IBUF_34,
      D => Sout_mux0001,
      Q => Sout_OBUF_25
    );
  temp_0 : FDE_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_28,
      CE => rst_inv,
      D => temp_0_mux0000,
      Q => temp(0)
    );
  temp_1 : FDE_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_28,
      CE => rst_inv,
      D => temp_1_mux0000,
      Q => temp(1)
    );
  temp_2 : FDE_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_28,
      CE => rst_inv,
      D => temp_2_mux0000,
      Q => temp(2)
    );
  temp_3 : FDE_1
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_28,
      CE => rst_inv,
      D => temp_3_mux0000,
      Q => temp(3)
    );
  Pout_0 : FDC_1
    port map (
      C => clk_BUFGP_28,
      CLR => rst_IBUF_34,
      D => Pout_mux0001(3),
      Q => Pout_0_14
    );
  Pout_1 : FDC_1
    port map (
      C => clk_BUFGP_28,
      CLR => rst_IBUF_34,
      D => Pout_mux0001(2),
      Q => Pout_1_15
    );
  Pout_2 : FDC_1
    port map (
      C => clk_BUFGP_28,
      CLR => rst_IBUF_34,
      D => Pout_mux0001(1),
      Q => Pout_2_16
    );
  Pout_3 : FDC_1
    port map (
      C => clk_BUFGP_28,
      CLR => rst_IBUF_34,
      D => Pout_mux0001(0),
      Q => Pout_3_17
    );
  Sout_mux00011 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => mode_0_IBUF_31,
      I1 => temp(3),
      O => Sout_mux0001
    );
  Mmux_Pout_mux000141 : LUT4
    generic map(
      INIT => X"B080"
    )
    port map (
      I0 => Pin_0_IBUF_6,
      I1 => mode_1_IBUF_32,
      I2 => mode_0_IBUF_31,
      I3 => temp(0),
      O => Pout_mux0001(3)
    );
  Mmux_Pout_mux000131 : LUT4
    generic map(
      INIT => X"B080"
    )
    port map (
      I0 => Pin_1_IBUF_7,
      I1 => mode_1_IBUF_32,
      I2 => mode_0_IBUF_31,
      I3 => temp(1),
      O => Pout_mux0001(2)
    );
  Mmux_Pout_mux000121 : LUT4
    generic map(
      INIT => X"B080"
    )
    port map (
      I0 => Pin_2_IBUF_8,
      I1 => mode_1_IBUF_32,
      I2 => mode_0_IBUF_31,
      I3 => temp(2),
      O => Pout_mux0001(1)
    );
  Mmux_Pout_mux000111 : LUT4
    generic map(
      INIT => X"B080"
    )
    port map (
      I0 => Pin_3_IBUF_9,
      I1 => mode_1_IBUF_32,
      I2 => mode_0_IBUF_31,
      I3 => temp(3),
      O => Pout_mux0001(0)
    );
  Mmux_temp_3_mux000021 : LUT4
    generic map(
      INIT => X"F780"
    )
    port map (
      I0 => mode_1_IBUF_32,
      I1 => mode_0_IBUF_31,
      I2 => temp(3),
      I3 => temp(2),
      O => temp_3_mux0000
    );
  Mmux_temp_2_mux000021 : LUT4
    generic map(
      INIT => X"F780"
    )
    port map (
      I0 => mode_1_IBUF_32,
      I1 => mode_0_IBUF_31,
      I2 => temp(2),
      I3 => temp(1),
      O => temp_2_mux0000
    );
  Mmux_temp_1_mux000021 : LUT4
    generic map(
      INIT => X"F780"
    )
    port map (
      I0 => mode_1_IBUF_32,
      I1 => mode_0_IBUF_31,
      I2 => temp(1),
      I3 => temp(0),
      O => temp_1_mux0000
    );
  Mmux_temp_0_mux00002_SW0 : LUT4
    generic map(
      INIT => X"7520"
    )
    port map (
      I0 => mode_1_IBUF_32,
      I1 => mode_0_IBUF_31,
      I2 => Pin_0_IBUF_6,
      I3 => Sin_IBUF_23,
      O => N2
    );
  Mmux_temp_0_mux00002_SW1 : LUT4
    generic map(
      INIT => X"FAD8"
    )
    port map (
      I0 => mode_1_IBUF_32,
      I1 => mode_0_IBUF_31,
      I2 => Sin_IBUF_23,
      I3 => Pin_0_IBUF_6,
      O => N3
    );
  Mmux_temp_0_mux00002 : LUT3
    generic map(
      INIT => X"AC"
    )
    port map (
      I0 => N3,
      I1 => N2,
      I2 => temp(0),
      O => temp_0_mux0000
    );
  Sin_IBUF : IBUF
    port map (
      I => Sin,
      O => Sin_IBUF_23
    );
  rst_IBUF : IBUF
    port map (
      I => rst,
      O => rst_IBUF_34
    );
  mode_1_IBUF : IBUF
    port map (
      I => mode(1),
      O => mode_1_IBUF_32
    );
  mode_0_IBUF : IBUF
    port map (
      I => mode(0),
      O => mode_0_IBUF_31
    );
  Pin_3_IBUF : IBUF
    port map (
      I => Pin(3),
      O => Pin_3_IBUF_9
    );
  Pin_2_IBUF : IBUF
    port map (
      I => Pin(2),
      O => Pin_2_IBUF_8
    );
  Pin_1_IBUF : IBUF
    port map (
      I => Pin(1),
      O => Pin_1_IBUF_7
    );
  Pin_0_IBUF : IBUF
    port map (
      I => Pin(0),
      O => Pin_0_IBUF_6
    );
  Sout_OBUF : OBUF
    port map (
      I => Sout_OBUF_25,
      O => Sout
    );
  Pout_3_OBUF : OBUF
    port map (
      I => Pout_3_17,
      O => Pout(3)
    );
  Pout_2_OBUF : OBUF
    port map (
      I => Pout_2_16,
      O => Pout(2)
    );
  Pout_1_OBUF : OBUF
    port map (
      I => Pout_1_15,
      O => Pout(1)
    );
  Pout_0_OBUF : OBUF
    port map (
      I => Pout_0_14,
      O => Pout(0)
    );
  clk_BUFGP : BUFGP
    port map (
      I => clk,
      O => clk_BUFGP_28
    );
  rst_inv1_INV_0 : INV
    port map (
      I => rst_IBUF_34,
      O => rst_inv
    );

end Structure;

