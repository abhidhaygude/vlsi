/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/42226_Asmita/Experiment 4/FIFO/fifo.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_0948142031_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(53, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5280);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5168);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0948142031_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(54, ng0);

LAB3:    t1 = (t0 + 2952U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5344);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5184);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0948142031_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    int t5;
    char *t6;
    int t7;
    int t8;
    char *t9;
    char *t10;
    char *t11;
    int t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned char t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;

LAB0:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 992U);
    t3 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB12;

LAB13:
LAB3:    t1 = (t0 + 5200);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(62, ng0);
    t5 = (16 - 1);
    t1 = (t0 + 8700);
    *((int *)t1) = 0;
    t6 = (t0 + 8704);
    *((int *)t6) = t5;
    t7 = 0;
    t8 = t5;

LAB5:    if (t7 <= t8)
        goto LAB6;

LAB8:    xsi_set_current_line(65, ng0);
    t1 = xsi_get_transient_memory(128U);
    memset(t1, 0, 128U);
    t2 = t1;
    t14 = (8U * 1U);
    t6 = t2;
    memset(t6, (unsigned char)2, t14);
    t3 = (t14 != 0);
    if (t3 == 1)
        goto LAB10;

LAB11:    t9 = (t0 + 5408);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t17 = (t11 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t1, 128U);
    xsi_driver_first_trans_fast(t9);
    xsi_set_current_line(67, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t2 = t1;
    memset(t2, (unsigned char)2, 8U);
    t6 = (t0 + 5472);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t17 = *((char **)t11);
    memcpy(t17, t1, 8U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(68, ng0);
    t1 = (t0 + 5536);
    t2 = (t1 + 56U);
    t6 = *((char **)t2);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 5600);
    t2 = (t1 + 56U);
    t6 = *((char **)t2);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 5664);
    t2 = (t1 + 56U);
    t6 = *((char **)t2);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    *((int *)t10) = 0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(71, ng0);
    t1 = (t0 + 5728);
    t2 = (t1 + 56U);
    t6 = *((char **)t2);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    *((int *)t10) = 0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 3368U);
    t2 = *((char **)t1);
    t1 = (t2 + 0);
    *((int *)t1) = 0;
    goto LAB3;

LAB6:    xsi_set_current_line(63, ng0);
    t9 = xsi_get_transient_memory(8U);
    memset(t9, 0, 8U);
    t10 = t9;
    memset(t10, (unsigned char)2, 8U);
    t11 = (t0 + 8700);
    t12 = *((int *)t11);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (8U * t14);
    t16 = (0U + t15);
    t17 = (t0 + 5408);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t9, 8U);
    xsi_driver_first_trans_delta(t17, t16, 8U, 0LL);

LAB7:    t1 = (t0 + 8700);
    t7 = *((int *)t1);
    t2 = (t0 + 8704);
    t8 = *((int *)t2);
    if (t7 == t8)
        goto LAB8;

LAB9:    t5 = (t7 + 1);
    t7 = t5;
    t6 = (t0 + 8700);
    *((int *)t6) = t7;
    goto LAB5;

LAB10:    t15 = (128U / t14);
    xsi_mem_set_data(t2, t2, t14, t15);
    goto LAB11;

LAB12:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 1352U);
    t6 = *((char **)t2);
    t22 = *((unsigned char *)t6);
    t23 = (t22 == (unsigned char)3);
    if (t23 == 1)
        goto LAB17;

LAB18:    t4 = (unsigned char)0;

LAB19:    if (t4 != 0)
        goto LAB14;

LAB16:
LAB15:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t4 = *((unsigned char *)t2);
    t22 = (t4 == (unsigned char)3);
    if (t22 == 1)
        goto LAB23;

LAB24:    t3 = (unsigned char)0;

LAB25:    if (t3 != 0)
        goto LAB20;

LAB22:
LAB21:    xsi_set_current_line(88, ng0);
    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t7 = (16 - 1);
    t3 = (t5 == t7);
    if (t3 != 0)
        goto LAB26;

LAB28:
LAB27:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t7 = (16 - 1);
    t3 = (t5 == t7);
    if (t3 != 0)
        goto LAB29;

LAB31:
LAB30:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 3368U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t3 = (t5 == 0);
    if (t3 != 0)
        goto LAB32;

LAB34:    xsi_set_current_line(99, ng0);
    t1 = (t0 + 5536);
    t2 = (t1 + 56U);
    t6 = *((char **)t2);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB33:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 3368U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t3 = (t5 == 16);
    if (t3 != 0)
        goto LAB35;

LAB37:    xsi_set_current_line(105, ng0);
    t1 = (t0 + 5600);
    t2 = (t1 + 56U);
    t6 = *((char **)t2);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB36:    goto LAB3;

LAB14:    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2312U);
    t10 = *((char **)t2);
    t2 = (t0 + 2472U);
    t11 = *((char **)t2);
    t5 = *((int *)t11);
    t7 = (t5 - 0);
    t14 = (t7 * 1);
    xsi_vhdl_check_range_of_index(0, 15, 1, t5);
    t15 = (8U * t14);
    t16 = (0 + t15);
    t2 = (t10 + t16);
    t17 = (t0 + 5472);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t2, 8U);
    xsi_driver_first_trans_fast_port(t17);
    xsi_set_current_line(77, ng0);
    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t7 = (t5 + 1);
    t1 = (t0 + 5664);
    t6 = (t1 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((int *)t11) = t7;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 3368U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t7 = (t5 - 1);
    t1 = (t0 + 3368U);
    t6 = *((char **)t1);
    t1 = (t6 + 0);
    *((int *)t1) = t7;
    goto LAB15;

LAB17:    t2 = (t0 + 2792U);
    t9 = *((char **)t2);
    t24 = *((unsigned char *)t9);
    t25 = (t24 == (unsigned char)2);
    t4 = t25;
    goto LAB19;

LAB20:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1672U);
    t9 = *((char **)t1);
    t1 = (t0 + 2632U);
    t10 = *((char **)t1);
    t5 = *((int *)t10);
    t7 = (t5 - 0);
    t14 = (t7 * 1);
    t15 = (8U * t14);
    t16 = (0U + t15);
    t1 = (t0 + 5408);
    t11 = (t1 + 56U);
    t17 = *((char **)t11);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t9, 8U);
    xsi_driver_first_trans_delta(t1, t16, 8U, 0LL);
    xsi_set_current_line(83, ng0);
    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t7 = (t5 + 1);
    t1 = (t0 + 5728);
    t6 = (t1 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((int *)t11) = t7;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 3368U);
    t2 = *((char **)t1);
    t5 = *((int *)t2);
    t7 = (t5 + 1);
    t1 = (t0 + 3368U);
    t6 = *((char **)t1);
    t1 = (t6 + 0);
    *((int *)t1) = t7;
    goto LAB21;

LAB23:    t1 = (t0 + 2952U);
    t6 = *((char **)t1);
    t23 = *((unsigned char *)t6);
    t24 = (t23 == (unsigned char)2);
    t3 = t24;
    goto LAB25;

LAB26:    xsi_set_current_line(89, ng0);
    t1 = (t0 + 5728);
    t6 = (t1 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((int *)t11) = 0;
    xsi_driver_first_trans_fast(t1);
    goto LAB27;

LAB29:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 5664);
    t6 = (t1 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((int *)t11) = 0;
    xsi_driver_first_trans_fast(t1);
    goto LAB30;

LAB32:    xsi_set_current_line(97, ng0);
    t1 = (t0 + 5536);
    t6 = (t1 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB33;

LAB35:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 5600);
    t6 = (t1 + 56U);
    t9 = *((char **)t6);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB36;

}


extern void work_a_0948142031_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0948142031_3212880686_p_0,(void *)work_a_0948142031_3212880686_p_1,(void *)work_a_0948142031_3212880686_p_2};
	xsi_register_didat("work_a_0948142031_3212880686", "isim/fifo_isim_beh.exe.sim/work/a_0948142031_3212880686.didat");
	xsi_register_executes(pe);
}
