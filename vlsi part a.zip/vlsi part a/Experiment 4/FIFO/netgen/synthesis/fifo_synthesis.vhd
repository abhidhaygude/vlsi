--------------------------------------------------------------------------------
-- Copyright (c) 1995-2013 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____
--  /   /\/   /
-- /___/  \  /    Vendor: Xilinx
-- \   \   \/     Version: P.20131013
--  \   \         Application: netgen
--  /   /         Filename: fifo_synthesis.vhd
-- /___/   /\     Timestamp: Fri Sep 04 07:28:07 2026
-- \   \  /  \ 
--  \___\/\___\
--             
-- Command	: -intstyle ise -ar Structure -tm fifo -w -dir netgen/synthesis -ofmt vhdl -sim fifo.ngc fifo_synthesis.vhd 
-- Device	: xc3s250e-5-pq208
-- Input file	: fifo.ngc
-- Output file	: D:\42226_Asmita\Experiment 4\FIFO\netgen\synthesis\fifo_synthesis.vhd
-- # of Entities	: 1
-- Design Name	: fifo
-- Xilinx	: C:\Xilinx\14.7\ISE_DS\ISE\
--             
-- Purpose:    
--     This VHDL netlist is a verification model and uses simulation 
--     primitives which may not represent the true implementation of the 
--     device, however the netlist is functionally correct and should not 
--     be modified. This file cannot be synthesized and should only be used 
--     with supported simulation tools.
--             
-- Reference:  
--     Command Line Tools User Guide, Chapter 23
--     Synthesis and Simulation Design Guide, Chapter 6
--             
--------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
use UNISIM.VPKG.ALL;

entity fifo is
  port (
    clk : in STD_LOGIC := 'X'; 
    reset : in STD_LOGIC := 'X'; 
    enr : in STD_LOGIC := 'X'; 
    fifo_empty : out STD_LOGIC; 
    enw : in STD_LOGIC := 'X'; 
    fifo_full : out STD_LOGIC; 
    data_out : out STD_LOGIC_VECTOR ( 7 downto 0 ); 
    data_in : in STD_LOGIC_VECTOR ( 7 downto 0 ) 
  );
end fifo;

architecture Structure of fifo is
  signal Mcount_readptr_cy_10_rt_34 : STD_LOGIC; 
  signal Mcount_readptr_cy_11_rt_36 : STD_LOGIC; 
  signal Mcount_readptr_cy_12_rt_38 : STD_LOGIC; 
  signal Mcount_readptr_cy_13_rt_40 : STD_LOGIC; 
  signal Mcount_readptr_cy_14_rt_42 : STD_LOGIC; 
  signal Mcount_readptr_cy_15_rt_44 : STD_LOGIC; 
  signal Mcount_readptr_cy_16_rt_46 : STD_LOGIC; 
  signal Mcount_readptr_cy_17_rt_48 : STD_LOGIC; 
  signal Mcount_readptr_cy_18_rt_50 : STD_LOGIC; 
  signal Mcount_readptr_cy_19_rt_52 : STD_LOGIC; 
  signal Mcount_readptr_cy_1_rt_54 : STD_LOGIC; 
  signal Mcount_readptr_cy_20_rt_56 : STD_LOGIC; 
  signal Mcount_readptr_cy_21_rt_58 : STD_LOGIC; 
  signal Mcount_readptr_cy_22_rt_60 : STD_LOGIC; 
  signal Mcount_readptr_cy_23_rt_62 : STD_LOGIC; 
  signal Mcount_readptr_cy_24_rt_64 : STD_LOGIC; 
  signal Mcount_readptr_cy_25_rt_66 : STD_LOGIC; 
  signal Mcount_readptr_cy_26_rt_68 : STD_LOGIC; 
  signal Mcount_readptr_cy_27_rt_70 : STD_LOGIC; 
  signal Mcount_readptr_cy_28_rt_72 : STD_LOGIC; 
  signal Mcount_readptr_cy_29_rt_74 : STD_LOGIC; 
  signal Mcount_readptr_cy_2_rt_76 : STD_LOGIC; 
  signal Mcount_readptr_cy_30_rt_78 : STD_LOGIC; 
  signal Mcount_readptr_cy_3_rt_80 : STD_LOGIC; 
  signal Mcount_readptr_cy_4_rt_82 : STD_LOGIC; 
  signal Mcount_readptr_cy_5_rt_84 : STD_LOGIC; 
  signal Mcount_readptr_cy_6_rt_86 : STD_LOGIC; 
  signal Mcount_readptr_cy_7_rt_88 : STD_LOGIC; 
  signal Mcount_readptr_cy_8_rt_90 : STD_LOGIC; 
  signal Mcount_readptr_cy_9_rt_92 : STD_LOGIC; 
  signal Mcount_readptr_eqn_0 : STD_LOGIC; 
  signal Mcount_readptr_eqn_1 : STD_LOGIC; 
  signal Mcount_readptr_eqn_10 : STD_LOGIC; 
  signal Mcount_readptr_eqn_11 : STD_LOGIC; 
  signal Mcount_readptr_eqn_12 : STD_LOGIC; 
  signal Mcount_readptr_eqn_13 : STD_LOGIC; 
  signal Mcount_readptr_eqn_14 : STD_LOGIC; 
  signal Mcount_readptr_eqn_15 : STD_LOGIC; 
  signal Mcount_readptr_eqn_16 : STD_LOGIC; 
  signal Mcount_readptr_eqn_17 : STD_LOGIC; 
  signal Mcount_readptr_eqn_18 : STD_LOGIC; 
  signal Mcount_readptr_eqn_19 : STD_LOGIC; 
  signal Mcount_readptr_eqn_2 : STD_LOGIC; 
  signal Mcount_readptr_eqn_20 : STD_LOGIC; 
  signal Mcount_readptr_eqn_21 : STD_LOGIC; 
  signal Mcount_readptr_eqn_22 : STD_LOGIC; 
  signal Mcount_readptr_eqn_23 : STD_LOGIC; 
  signal Mcount_readptr_eqn_24 : STD_LOGIC; 
  signal Mcount_readptr_eqn_25 : STD_LOGIC; 
  signal Mcount_readptr_eqn_26 : STD_LOGIC; 
  signal Mcount_readptr_eqn_27 : STD_LOGIC; 
  signal Mcount_readptr_eqn_28 : STD_LOGIC; 
  signal Mcount_readptr_eqn_29 : STD_LOGIC; 
  signal Mcount_readptr_eqn_3 : STD_LOGIC; 
  signal Mcount_readptr_eqn_30 : STD_LOGIC; 
  signal Mcount_readptr_eqn_31 : STD_LOGIC; 
  signal Mcount_readptr_eqn_4 : STD_LOGIC; 
  signal Mcount_readptr_eqn_5 : STD_LOGIC; 
  signal Mcount_readptr_eqn_6 : STD_LOGIC; 
  signal Mcount_readptr_eqn_7 : STD_LOGIC; 
  signal Mcount_readptr_eqn_8 : STD_LOGIC; 
  signal Mcount_readptr_eqn_9 : STD_LOGIC; 
  signal Mcount_readptr_xor_31_rt_126 : STD_LOGIC; 
  signal Mcount_writeptr_cy_10_rt_129 : STD_LOGIC; 
  signal Mcount_writeptr_cy_11_rt_131 : STD_LOGIC; 
  signal Mcount_writeptr_cy_12_rt_133 : STD_LOGIC; 
  signal Mcount_writeptr_cy_13_rt_135 : STD_LOGIC; 
  signal Mcount_writeptr_cy_14_rt_137 : STD_LOGIC; 
  signal Mcount_writeptr_cy_15_rt_139 : STD_LOGIC; 
  signal Mcount_writeptr_cy_16_rt_141 : STD_LOGIC; 
  signal Mcount_writeptr_cy_17_rt_143 : STD_LOGIC; 
  signal Mcount_writeptr_cy_18_rt_145 : STD_LOGIC; 
  signal Mcount_writeptr_cy_19_rt_147 : STD_LOGIC; 
  signal Mcount_writeptr_cy_1_rt_149 : STD_LOGIC; 
  signal Mcount_writeptr_cy_20_rt_151 : STD_LOGIC; 
  signal Mcount_writeptr_cy_21_rt_153 : STD_LOGIC; 
  signal Mcount_writeptr_cy_22_rt_155 : STD_LOGIC; 
  signal Mcount_writeptr_cy_23_rt_157 : STD_LOGIC; 
  signal Mcount_writeptr_cy_24_rt_159 : STD_LOGIC; 
  signal Mcount_writeptr_cy_25_rt_161 : STD_LOGIC; 
  signal Mcount_writeptr_cy_26_rt_163 : STD_LOGIC; 
  signal Mcount_writeptr_cy_27_rt_165 : STD_LOGIC; 
  signal Mcount_writeptr_cy_28_rt_167 : STD_LOGIC; 
  signal Mcount_writeptr_cy_29_rt_169 : STD_LOGIC; 
  signal Mcount_writeptr_cy_2_rt_171 : STD_LOGIC; 
  signal Mcount_writeptr_cy_30_rt_173 : STD_LOGIC; 
  signal Mcount_writeptr_cy_3_rt_175 : STD_LOGIC; 
  signal Mcount_writeptr_cy_4_rt_177 : STD_LOGIC; 
  signal Mcount_writeptr_cy_5_rt_179 : STD_LOGIC; 
  signal Mcount_writeptr_cy_6_rt_181 : STD_LOGIC; 
  signal Mcount_writeptr_cy_7_rt_183 : STD_LOGIC; 
  signal Mcount_writeptr_cy_8_rt_185 : STD_LOGIC; 
  signal Mcount_writeptr_cy_9_rt_187 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_0 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_1 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_10 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_11_191 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_12 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_13 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_14 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_15 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_16 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_17 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_18 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_19 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_2 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_20 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_21 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_22 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_23 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_24 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_25 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_26 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_27 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_28 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_29 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_3 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_30 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_31 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_4 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_5 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_6 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_7 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_8 : STD_LOGIC; 
  signal Mcount_writeptr_eqn_9 : STD_LOGIC; 
  signal Mcount_writeptr_xor_31_rt_221 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f6_222 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f61 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f62 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f63 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f64 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f65 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f66 : STD_LOGIC; 
  signal Mmux_varindex0000_3_f67 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f5_230 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f51 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f52 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f53 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f54 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f55 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f56 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f57 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f6_238 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f61 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f62 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f63 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f64 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f65 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f66 : STD_LOGIC; 
  signal Mmux_varindex0000_4_f67 : STD_LOGIC; 
  signal Mmux_varindex0000_5_246 : STD_LOGIC; 
  signal Mmux_varindex0000_51_247 : STD_LOGIC; 
  signal Mmux_varindex0000_52_248 : STD_LOGIC; 
  signal Mmux_varindex0000_53_249 : STD_LOGIC; 
  signal Mmux_varindex0000_54_250 : STD_LOGIC; 
  signal Mmux_varindex0000_55_251 : STD_LOGIC; 
  signal Mmux_varindex0000_56_252 : STD_LOGIC; 
  signal Mmux_varindex0000_57_253 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f5_254 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f51 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f510 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f511 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f512 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f513 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f514 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f515 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f52 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f53 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f54 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f55 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f56 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f57 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f58 : STD_LOGIC; 
  signal Mmux_varindex0000_5_f59 : STD_LOGIC; 
  signal Mmux_varindex0000_6_270 : STD_LOGIC; 
  signal Mmux_varindex0000_61_271 : STD_LOGIC; 
  signal Mmux_varindex0000_610_272 : STD_LOGIC; 
  signal Mmux_varindex0000_611_273 : STD_LOGIC; 
  signal Mmux_varindex0000_612_274 : STD_LOGIC; 
  signal Mmux_varindex0000_613_275 : STD_LOGIC; 
  signal Mmux_varindex0000_614_276 : STD_LOGIC; 
  signal Mmux_varindex0000_615_277 : STD_LOGIC; 
  signal Mmux_varindex0000_616_278 : STD_LOGIC; 
  signal Mmux_varindex0000_617_279 : STD_LOGIC; 
  signal Mmux_varindex0000_618_280 : STD_LOGIC; 
  signal Mmux_varindex0000_619_281 : STD_LOGIC; 
  signal Mmux_varindex0000_62_282 : STD_LOGIC; 
  signal Mmux_varindex0000_620_283 : STD_LOGIC; 
  signal Mmux_varindex0000_621_284 : STD_LOGIC; 
  signal Mmux_varindex0000_622_285 : STD_LOGIC; 
  signal Mmux_varindex0000_623_286 : STD_LOGIC; 
  signal Mmux_varindex0000_63_287 : STD_LOGIC; 
  signal Mmux_varindex0000_64_288 : STD_LOGIC; 
  signal Mmux_varindex0000_65_289 : STD_LOGIC; 
  signal Mmux_varindex0000_66_290 : STD_LOGIC; 
  signal Mmux_varindex0000_67_291 : STD_LOGIC; 
  signal Mmux_varindex0000_68_292 : STD_LOGIC; 
  signal Mmux_varindex0000_69_293 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f5_294 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f51 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f52 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f53 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f54 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f55 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f56 : STD_LOGIC; 
  signal Mmux_varindex0000_6_f57 : STD_LOGIC; 
  signal Mmux_varindex0000_7_302 : STD_LOGIC; 
  signal Mmux_varindex0000_71_303 : STD_LOGIC; 
  signal Mmux_varindex0000_710_304 : STD_LOGIC; 
  signal Mmux_varindex0000_711_305 : STD_LOGIC; 
  signal Mmux_varindex0000_712_306 : STD_LOGIC; 
  signal Mmux_varindex0000_713_307 : STD_LOGIC; 
  signal Mmux_varindex0000_714_308 : STD_LOGIC; 
  signal Mmux_varindex0000_715_309 : STD_LOGIC; 
  signal Mmux_varindex0000_716_310 : STD_LOGIC; 
  signal Mmux_varindex0000_717_311 : STD_LOGIC; 
  signal Mmux_varindex0000_718_312 : STD_LOGIC; 
  signal Mmux_varindex0000_719_313 : STD_LOGIC; 
  signal Mmux_varindex0000_72_314 : STD_LOGIC; 
  signal Mmux_varindex0000_720_315 : STD_LOGIC; 
  signal Mmux_varindex0000_721_316 : STD_LOGIC; 
  signal Mmux_varindex0000_722_317 : STD_LOGIC; 
  signal Mmux_varindex0000_723_318 : STD_LOGIC; 
  signal Mmux_varindex0000_73_319 : STD_LOGIC; 
  signal Mmux_varindex0000_74_320 : STD_LOGIC; 
  signal Mmux_varindex0000_75_321 : STD_LOGIC; 
  signal Mmux_varindex0000_76_322 : STD_LOGIC; 
  signal Mmux_varindex0000_77_323 : STD_LOGIC; 
  signal Mmux_varindex0000_78_324 : STD_LOGIC; 
  signal Mmux_varindex0000_79_325 : STD_LOGIC; 
  signal Mmux_varindex0000_8_326 : STD_LOGIC; 
  signal Mmux_varindex0000_81_327 : STD_LOGIC; 
  signal Mmux_varindex0000_82_328 : STD_LOGIC; 
  signal Mmux_varindex0000_83_329 : STD_LOGIC; 
  signal Mmux_varindex0000_84_330 : STD_LOGIC; 
  signal Mmux_varindex0000_85_331 : STD_LOGIC; 
  signal Mmux_varindex0000_86_332 : STD_LOGIC; 
  signal Mmux_varindex0000_87_333 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001 : STD_LOGIC; 
  signal Mmux_num_elem_mux00011_335 : STD_LOGIC; 
  signal Mmux_num_elem_mux000110 : STD_LOGIC; 
  signal Mmux_num_elem_mux000111 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001111_338 : STD_LOGIC; 
  signal Mmux_num_elem_mux000112 : STD_LOGIC; 
  signal Mmux_num_elem_mux000113 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001131_341 : STD_LOGIC; 
  signal Mmux_num_elem_mux000114 : STD_LOGIC; 
  signal Mmux_num_elem_mux000115 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001151_344 : STD_LOGIC; 
  signal Mmux_num_elem_mux000116 : STD_LOGIC; 
  signal Mmux_num_elem_mux000117 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001171_347 : STD_LOGIC; 
  signal Mmux_num_elem_mux000118 : STD_LOGIC; 
  signal Mmux_num_elem_mux000119 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001191_350 : STD_LOGIC; 
  signal Mmux_num_elem_mux00012 : STD_LOGIC; 
  signal Mmux_num_elem_mux000120 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001211_353 : STD_LOGIC; 
  signal Mmux_num_elem_mux000122 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001231_355 : STD_LOGIC; 
  signal Mmux_num_elem_mux000124 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001251_357 : STD_LOGIC; 
  signal Mmux_num_elem_mux000126 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001271_359 : STD_LOGIC; 
  signal Mmux_num_elem_mux000128 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001291_361 : STD_LOGIC; 
  signal Mmux_num_elem_mux00013 : STD_LOGIC; 
  signal Mmux_num_elem_mux000130 : STD_LOGIC; 
  signal Mmux_num_elem_mux000131_364 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001311_365 : STD_LOGIC; 
  signal Mmux_num_elem_mux000132 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001331_367 : STD_LOGIC; 
  signal Mmux_num_elem_mux000134 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001351_369 : STD_LOGIC; 
  signal Mmux_num_elem_mux000136 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001371_371 : STD_LOGIC; 
  signal Mmux_num_elem_mux000138 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001391_373 : STD_LOGIC; 
  signal Mmux_num_elem_mux00014 : STD_LOGIC; 
  signal Mmux_num_elem_mux000140 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001411_376 : STD_LOGIC; 
  signal Mmux_num_elem_mux000142 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001431_378 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001451_379 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001471_380 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001491_381 : STD_LOGIC; 
  signal Mmux_num_elem_mux00015 : STD_LOGIC; 
  signal Mmux_num_elem_mux000151_383 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001511_384 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001531_385 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001551_386 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001571_387 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001591_388 : STD_LOGIC; 
  signal Mmux_num_elem_mux00016 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001611_390 : STD_LOGIC; 
  signal Mmux_num_elem_mux0001631_391 : STD_LOGIC; 
  signal Mmux_num_elem_mux00017 : STD_LOGIC; 
  signal Mmux_num_elem_mux000171_393 : STD_LOGIC; 
  signal Mmux_num_elem_mux00018 : STD_LOGIC; 
  signal Mmux_num_elem_mux00019 : STD_LOGIC; 
  signal Mmux_num_elem_mux000191_396 : STD_LOGIC; 
  signal Msub_num_elem_sub0000_cy_0_rt_398 : STD_LOGIC; 
  signal N0 : STD_LOGIC; 
  signal N1 : STD_LOGIC; 
  signal N10 : STD_LOGIC; 
  signal N12 : STD_LOGIC; 
  signal N13 : STD_LOGIC; 
  signal N15 : STD_LOGIC; 
  signal N16 : STD_LOGIC; 
  signal N17 : STD_LOGIC; 
  signal N18 : STD_LOGIC; 
  signal N5 : STD_LOGIC; 
  signal N6 : STD_LOGIC; 
  signal N7 : STD_LOGIC; 
  signal N8 : STD_LOGIC; 
  signal N9 : STD_LOGIC; 
  signal Result_0_1 : STD_LOGIC; 
  signal Result_10_1 : STD_LOGIC; 
  signal Result_11_1 : STD_LOGIC; 
  signal Result_12_1 : STD_LOGIC; 
  signal Result_13_1 : STD_LOGIC; 
  signal Result_14_1 : STD_LOGIC; 
  signal Result_15_1 : STD_LOGIC; 
  signal Result_16_1 : STD_LOGIC; 
  signal Result_17_1 : STD_LOGIC; 
  signal Result_18_1 : STD_LOGIC; 
  signal Result_19_1 : STD_LOGIC; 
  signal Result_1_1 : STD_LOGIC; 
  signal Result_20_1 : STD_LOGIC; 
  signal Result_21_1 : STD_LOGIC; 
  signal Result_22_1 : STD_LOGIC; 
  signal Result_23_1 : STD_LOGIC; 
  signal Result_24_1 : STD_LOGIC; 
  signal Result_25_1 : STD_LOGIC; 
  signal Result_26_1 : STD_LOGIC; 
  signal Result_27_1 : STD_LOGIC; 
  signal Result_28_1 : STD_LOGIC; 
  signal Result_29_1 : STD_LOGIC; 
  signal Result_2_1 : STD_LOGIC; 
  signal Result_30_1 : STD_LOGIC; 
  signal Result_31_1 : STD_LOGIC; 
  signal Result_3_1 : STD_LOGIC; 
  signal Result_4_1 : STD_LOGIC; 
  signal Result_5_1 : STD_LOGIC; 
  signal Result_6_1 : STD_LOGIC; 
  signal Result_7_1 : STD_LOGIC; 
  signal Result_8_1 : STD_LOGIC; 
  signal Result_9_1 : STD_LOGIC; 
  signal clk_BUFGP_547 : STD_LOGIC; 
  signal data_in_0_IBUF_556 : STD_LOGIC; 
  signal data_in_1_IBUF_557 : STD_LOGIC; 
  signal data_in_2_IBUF_558 : STD_LOGIC; 
  signal data_in_3_IBUF_559 : STD_LOGIC; 
  signal data_in_4_IBUF_560 : STD_LOGIC; 
  signal data_in_5_IBUF_561 : STD_LOGIC; 
  signal data_in_6_IBUF_562 : STD_LOGIC; 
  signal data_in_7_IBUF_563 : STD_LOGIC; 
  signal data_out_0_572 : STD_LOGIC; 
  signal data_out_1_573 : STD_LOGIC; 
  signal data_out_2_574 : STD_LOGIC; 
  signal data_out_3_575 : STD_LOGIC; 
  signal data_out_4_576 : STD_LOGIC; 
  signal data_out_5_577 : STD_LOGIC; 
  signal data_out_6_578 : STD_LOGIC; 
  signal data_out_7_579 : STD_LOGIC; 
  signal data_out_and0000 : STD_LOGIC; 
  signal empty_581 : STD_LOGIC; 
  signal empty_cmp_eq0000 : STD_LOGIC; 
  signal enr_IBUF_600 : STD_LOGIC; 
  signal enw_IBUF_602 : STD_LOGIC; 
  signal full_605 : STD_LOGIC; 
  signal full_cmp_eq0000 : STD_LOGIC; 
  signal memory_0_0_607 : STD_LOGIC; 
  signal memory_0_1_608 : STD_LOGIC; 
  signal memory_0_2_609 : STD_LOGIC; 
  signal memory_0_3_610 : STD_LOGIC; 
  signal memory_0_4_611 : STD_LOGIC; 
  signal memory_0_5_612 : STD_LOGIC; 
  signal memory_0_6_613 : STD_LOGIC; 
  signal memory_0_7_614 : STD_LOGIC; 
  signal memory_0_and0000 : STD_LOGIC; 
  signal memory_10_0_616 : STD_LOGIC; 
  signal memory_10_1_617 : STD_LOGIC; 
  signal memory_10_2_618 : STD_LOGIC; 
  signal memory_10_3_619 : STD_LOGIC; 
  signal memory_10_4_620 : STD_LOGIC; 
  signal memory_10_5_621 : STD_LOGIC; 
  signal memory_10_6_622 : STD_LOGIC; 
  signal memory_10_7_623 : STD_LOGIC; 
  signal memory_10_and0000 : STD_LOGIC; 
  signal memory_11_0_625 : STD_LOGIC; 
  signal memory_11_1_626 : STD_LOGIC; 
  signal memory_11_2_627 : STD_LOGIC; 
  signal memory_11_3_628 : STD_LOGIC; 
  signal memory_11_4_629 : STD_LOGIC; 
  signal memory_11_5_630 : STD_LOGIC; 
  signal memory_11_6_631 : STD_LOGIC; 
  signal memory_11_7_632 : STD_LOGIC; 
  signal memory_11_and0000 : STD_LOGIC; 
  signal memory_12_0_634 : STD_LOGIC; 
  signal memory_12_1_635 : STD_LOGIC; 
  signal memory_12_2_636 : STD_LOGIC; 
  signal memory_12_3_637 : STD_LOGIC; 
  signal memory_12_4_638 : STD_LOGIC; 
  signal memory_12_5_639 : STD_LOGIC; 
  signal memory_12_6_640 : STD_LOGIC; 
  signal memory_12_7_641 : STD_LOGIC; 
  signal memory_12_and0000 : STD_LOGIC; 
  signal memory_13_0_643 : STD_LOGIC; 
  signal memory_13_1_644 : STD_LOGIC; 
  signal memory_13_2_645 : STD_LOGIC; 
  signal memory_13_3_646 : STD_LOGIC; 
  signal memory_13_4_647 : STD_LOGIC; 
  signal memory_13_5_648 : STD_LOGIC; 
  signal memory_13_6_649 : STD_LOGIC; 
  signal memory_13_7_650 : STD_LOGIC; 
  signal memory_13_and0000 : STD_LOGIC; 
  signal memory_14_0_652 : STD_LOGIC; 
  signal memory_14_1_653 : STD_LOGIC; 
  signal memory_14_2_654 : STD_LOGIC; 
  signal memory_14_3_655 : STD_LOGIC; 
  signal memory_14_4_656 : STD_LOGIC; 
  signal memory_14_5_657 : STD_LOGIC; 
  signal memory_14_6_658 : STD_LOGIC; 
  signal memory_14_7_659 : STD_LOGIC; 
  signal memory_14_and0000 : STD_LOGIC; 
  signal memory_15_0_661 : STD_LOGIC; 
  signal memory_15_1_662 : STD_LOGIC; 
  signal memory_15_2_663 : STD_LOGIC; 
  signal memory_15_3_664 : STD_LOGIC; 
  signal memory_15_4_665 : STD_LOGIC; 
  signal memory_15_5_666 : STD_LOGIC; 
  signal memory_15_6_667 : STD_LOGIC; 
  signal memory_15_7_668 : STD_LOGIC; 
  signal memory_15_and0000 : STD_LOGIC; 
  signal memory_1_0_670 : STD_LOGIC; 
  signal memory_1_1_671 : STD_LOGIC; 
  signal memory_1_2_672 : STD_LOGIC; 
  signal memory_1_3_673 : STD_LOGIC; 
  signal memory_1_4_674 : STD_LOGIC; 
  signal memory_1_5_675 : STD_LOGIC; 
  signal memory_1_6_676 : STD_LOGIC; 
  signal memory_1_7_677 : STD_LOGIC; 
  signal memory_1_and0000 : STD_LOGIC; 
  signal memory_2_0_679 : STD_LOGIC; 
  signal memory_2_1_680 : STD_LOGIC; 
  signal memory_2_2_681 : STD_LOGIC; 
  signal memory_2_3_682 : STD_LOGIC; 
  signal memory_2_4_683 : STD_LOGIC; 
  signal memory_2_5_684 : STD_LOGIC; 
  signal memory_2_6_685 : STD_LOGIC; 
  signal memory_2_7_686 : STD_LOGIC; 
  signal memory_2_and0000 : STD_LOGIC; 
  signal memory_3_0_688 : STD_LOGIC; 
  signal memory_3_1_689 : STD_LOGIC; 
  signal memory_3_2_690 : STD_LOGIC; 
  signal memory_3_3_691 : STD_LOGIC; 
  signal memory_3_4_692 : STD_LOGIC; 
  signal memory_3_5_693 : STD_LOGIC; 
  signal memory_3_6_694 : STD_LOGIC; 
  signal memory_3_7_695 : STD_LOGIC; 
  signal memory_3_and0000 : STD_LOGIC; 
  signal memory_4_0_697 : STD_LOGIC; 
  signal memory_4_1_698 : STD_LOGIC; 
  signal memory_4_2_699 : STD_LOGIC; 
  signal memory_4_3_700 : STD_LOGIC; 
  signal memory_4_4_701 : STD_LOGIC; 
  signal memory_4_5_702 : STD_LOGIC; 
  signal memory_4_6_703 : STD_LOGIC; 
  signal memory_4_7_704 : STD_LOGIC; 
  signal memory_4_and0000 : STD_LOGIC; 
  signal memory_5_0_706 : STD_LOGIC; 
  signal memory_5_1_707 : STD_LOGIC; 
  signal memory_5_2_708 : STD_LOGIC; 
  signal memory_5_3_709 : STD_LOGIC; 
  signal memory_5_4_710 : STD_LOGIC; 
  signal memory_5_5_711 : STD_LOGIC; 
  signal memory_5_6_712 : STD_LOGIC; 
  signal memory_5_7_713 : STD_LOGIC; 
  signal memory_5_and0000 : STD_LOGIC; 
  signal memory_6_0_715 : STD_LOGIC; 
  signal memory_6_1_716 : STD_LOGIC; 
  signal memory_6_2_717 : STD_LOGIC; 
  signal memory_6_3_718 : STD_LOGIC; 
  signal memory_6_4_719 : STD_LOGIC; 
  signal memory_6_5_720 : STD_LOGIC; 
  signal memory_6_6_721 : STD_LOGIC; 
  signal memory_6_7_722 : STD_LOGIC; 
  signal memory_6_and0000 : STD_LOGIC; 
  signal memory_7_0_724 : STD_LOGIC; 
  signal memory_7_1_725 : STD_LOGIC; 
  signal memory_7_2_726 : STD_LOGIC; 
  signal memory_7_3_727 : STD_LOGIC; 
  signal memory_7_4_728 : STD_LOGIC; 
  signal memory_7_5_729 : STD_LOGIC; 
  signal memory_7_6_730 : STD_LOGIC; 
  signal memory_7_7_731 : STD_LOGIC; 
  signal memory_7_and0000 : STD_LOGIC; 
  signal memory_8_0_733 : STD_LOGIC; 
  signal memory_8_1_734 : STD_LOGIC; 
  signal memory_8_2_735 : STD_LOGIC; 
  signal memory_8_3_736 : STD_LOGIC; 
  signal memory_8_4_737 : STD_LOGIC; 
  signal memory_8_5_738 : STD_LOGIC; 
  signal memory_8_6_739 : STD_LOGIC; 
  signal memory_8_7_740 : STD_LOGIC; 
  signal memory_8_and0000 : STD_LOGIC; 
  signal memory_9_0_742 : STD_LOGIC; 
  signal memory_9_1_743 : STD_LOGIC; 
  signal memory_9_2_744 : STD_LOGIC; 
  signal memory_9_3_745 : STD_LOGIC; 
  signal memory_9_4_746 : STD_LOGIC; 
  signal memory_9_5_747 : STD_LOGIC; 
  signal memory_9_6_748 : STD_LOGIC; 
  signal memory_9_7_749 : STD_LOGIC; 
  signal memory_9_and0000 : STD_LOGIC; 
  signal num_elem_and0000 : STD_LOGIC; 
  signal readptr_cmp_eq0000 : STD_LOGIC; 
  signal readptr_not0001 : STD_LOGIC; 
  signal reset_IBUF_930 : STD_LOGIC; 
  signal writeptr_cmp_eq0000 : STD_LOGIC; 
  signal writeptr_not0001 : STD_LOGIC; 
  signal Madd_num_elem_addsub0000_cy : STD_LOGIC_VECTOR ( 30 downto 0 ); 
  signal Madd_num_elem_addsub0000_lut : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal Mcount_readptr_cy : STD_LOGIC_VECTOR ( 30 downto 0 ); 
  signal Mcount_readptr_lut : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal Mcount_writeptr_cy : STD_LOGIC_VECTOR ( 30 downto 0 ); 
  signal Mcount_writeptr_lut : STD_LOGIC_VECTOR ( 0 downto 0 ); 
  signal Msub_num_elem_sub0000_cy : STD_LOGIC_VECTOR ( 30 downto 0 ); 
  signal Msub_num_elem_sub0000_lut : STD_LOGIC_VECTOR ( 31 downto 1 ); 
  signal Result : STD_LOGIC_VECTOR ( 31 downto 0 ); 
  signal Q_varindex0000 : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal empty_cmp_eq00001_wg_cy : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal empty_cmp_eq00001_wg_lut : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal num_elem : STD_LOGIC_VECTOR ( 31 downto 0 ); 
  signal num_elem_addsub0000 : STD_LOGIC_VECTOR ( 31 downto 0 ); 
  signal num_elem_mux0001 : STD_LOGIC_VECTOR ( 31 downto 0 ); 
  signal num_elem_sub0000 : STD_LOGIC_VECTOR ( 31 downto 0 ); 
  signal readptr : STD_LOGIC_VECTOR ( 31 downto 0 ); 
  signal readptr_cmp_eq0000_wg_cy : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal readptr_cmp_eq0000_wg_lut : STD_LOGIC_VECTOR ( 7 downto 0 ); 
  signal writeptr : STD_LOGIC_VECTOR ( 31 downto 0 ); 
  signal writeptr_cmp_eq0000_wg_cy : STD_LOGIC_VECTOR ( 6 downto 0 ); 
  signal writeptr_cmp_eq0000_wg_lut : STD_LOGIC_VECTOR ( 7 downto 0 ); 
begin
  XST_GND : GND
    port map (
      G => N0
    );
  XST_VCC : VCC
    port map (
      P => N1
    );
  full : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => full_cmp_eq0000,
      Q => full_605
    );
  memory_2_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_2_0_679
    );
  memory_2_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_2_1_680
    );
  memory_2_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_2_2_681
    );
  memory_2_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_2_3_682
    );
  memory_2_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_2_4_683
    );
  memory_2_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_2_5_684
    );
  memory_2_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_2_6_685
    );
  memory_2_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_2_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_2_7_686
    );
  memory_0_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_0_0_607
    );
  memory_0_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_0_1_608
    );
  memory_0_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_0_2_609
    );
  memory_0_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_0_3_610
    );
  memory_0_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_0_4_611
    );
  memory_0_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_0_5_612
    );
  memory_0_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_0_6_613
    );
  memory_0_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_0_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_0_7_614
    );
  memory_1_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_1_0_670
    );
  memory_1_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_1_1_671
    );
  memory_1_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_1_2_672
    );
  memory_1_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_1_3_673
    );
  memory_1_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_1_4_674
    );
  memory_1_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_1_5_675
    );
  memory_1_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_1_6_676
    );
  memory_1_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_1_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_1_7_677
    );
  memory_10_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_10_0_616
    );
  memory_10_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_10_1_617
    );
  memory_10_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_10_2_618
    );
  memory_10_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_10_3_619
    );
  memory_10_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_10_4_620
    );
  memory_10_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_10_5_621
    );
  memory_10_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_10_6_622
    );
  memory_10_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_10_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_10_7_623
    );
  empty : FDP
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      D => empty_cmp_eq0000,
      PRE => reset_IBUF_930,
      Q => empty_581
    );
  memory_3_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_3_0_688
    );
  memory_3_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_3_1_689
    );
  memory_3_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_3_2_690
    );
  memory_3_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_3_3_691
    );
  memory_3_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_3_4_692
    );
  memory_3_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_3_5_693
    );
  memory_3_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_3_6_694
    );
  memory_3_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_3_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_3_7_695
    );
  memory_5_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_5_0_706
    );
  memory_5_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_5_1_707
    );
  memory_5_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_5_2_708
    );
  memory_5_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_5_3_709
    );
  memory_5_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_5_4_710
    );
  memory_5_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_5_5_711
    );
  memory_5_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_5_6_712
    );
  memory_5_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_5_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_5_7_713
    );
  memory_4_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_4_0_697
    );
  memory_4_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_4_1_698
    );
  memory_4_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_4_2_699
    );
  memory_4_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_4_3_700
    );
  memory_4_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_4_4_701
    );
  memory_4_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_4_5_702
    );
  memory_4_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_4_6_703
    );
  memory_4_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_4_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_4_7_704
    );
  memory_11_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_11_0_625
    );
  memory_11_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_11_1_626
    );
  memory_11_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_11_2_627
    );
  memory_11_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_11_3_628
    );
  memory_11_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_11_4_629
    );
  memory_11_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_11_5_630
    );
  memory_11_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_11_6_631
    );
  memory_11_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_11_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_11_7_632
    );
  memory_12_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_12_0_634
    );
  memory_12_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_12_1_635
    );
  memory_12_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_12_2_636
    );
  memory_12_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_12_3_637
    );
  memory_12_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_12_4_638
    );
  memory_12_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_12_5_639
    );
  memory_12_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_12_6_640
    );
  memory_12_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_12_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_12_7_641
    );
  memory_6_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_6_0_715
    );
  memory_6_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_6_1_716
    );
  memory_6_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_6_2_717
    );
  memory_6_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_6_3_718
    );
  memory_6_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_6_4_719
    );
  memory_6_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_6_5_720
    );
  memory_6_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_6_6_721
    );
  memory_6_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_6_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_6_7_722
    );
  memory_13_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_13_0_643
    );
  memory_13_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_13_1_644
    );
  memory_13_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_13_2_645
    );
  memory_13_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_13_3_646
    );
  memory_13_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_13_4_647
    );
  memory_13_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_13_5_648
    );
  memory_13_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_13_6_649
    );
  memory_13_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_13_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_13_7_650
    );
  memory_8_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_8_0_733
    );
  memory_8_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_8_1_734
    );
  memory_8_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_8_2_735
    );
  memory_8_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_8_3_736
    );
  memory_8_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_8_4_737
    );
  memory_8_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_8_5_738
    );
  memory_8_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_8_6_739
    );
  memory_8_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_8_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_8_7_740
    );
  memory_7_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_7_0_724
    );
  memory_7_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_7_1_725
    );
  memory_7_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_7_2_726
    );
  memory_7_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_7_3_727
    );
  memory_7_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_7_4_728
    );
  memory_7_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_7_5_729
    );
  memory_7_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_7_6_730
    );
  memory_7_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_7_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_7_7_731
    );
  memory_14_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_14_0_652
    );
  memory_14_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_14_1_653
    );
  memory_14_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_14_2_654
    );
  memory_14_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_14_3_655
    );
  memory_14_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_14_4_656
    );
  memory_14_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_14_5_657
    );
  memory_14_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_14_6_658
    );
  memory_14_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_14_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_14_7_659
    );
  memory_15_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_15_0_661
    );
  memory_15_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_15_1_662
    );
  memory_15_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_15_2_663
    );
  memory_15_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_15_3_664
    );
  memory_15_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_15_4_665
    );
  memory_15_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_15_5_666
    );
  memory_15_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_15_6_667
    );
  memory_15_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_15_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_15_7_668
    );
  memory_9_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_0_IBUF_556,
      Q => memory_9_0_742
    );
  memory_9_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_1_IBUF_557,
      Q => memory_9_1_743
    );
  memory_9_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_2_IBUF_558,
      Q => memory_9_2_744
    );
  memory_9_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_3_IBUF_559,
      Q => memory_9_3_745
    );
  memory_9_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_4_IBUF_560,
      Q => memory_9_4_746
    );
  memory_9_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_5_IBUF_561,
      Q => memory_9_5_747
    );
  memory_9_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_6_IBUF_562,
      Q => memory_9_6_748
    );
  memory_9_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => memory_9_and0000,
      CLR => reset_IBUF_930,
      D => data_in_7_IBUF_563,
      Q => memory_9_7_749
    );
  data_out_0 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(0),
      Q => data_out_0_572
    );
  data_out_1 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(1),
      Q => data_out_1_573
    );
  data_out_2 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(2),
      Q => data_out_2_574
    );
  data_out_3 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(3),
      Q => data_out_3_575
    );
  data_out_4 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(4),
      Q => data_out_4_576
    );
  data_out_5 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(5),
      Q => data_out_5_577
    );
  data_out_6 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(6),
      Q => data_out_6_578
    );
  data_out_7 : FDCE
    port map (
      C => clk_BUFGP_547,
      CE => data_out_and0000,
      CLR => reset_IBUF_930,
      D => Q_varindex0000(7),
      Q => data_out_7_579
    );
  num_elem_0 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(0),
      Q => num_elem(0)
    );
  num_elem_1 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(1),
      Q => num_elem(1)
    );
  num_elem_2 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(2),
      Q => num_elem(2)
    );
  num_elem_3 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(3),
      Q => num_elem(3)
    );
  num_elem_4 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(4),
      Q => num_elem(4)
    );
  num_elem_5 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(5),
      Q => num_elem(5)
    );
  num_elem_6 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(6),
      Q => num_elem(6)
    );
  num_elem_7 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(7),
      Q => num_elem(7)
    );
  num_elem_8 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(8),
      Q => num_elem(8)
    );
  num_elem_9 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(9),
      Q => num_elem(9)
    );
  num_elem_10 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(10),
      Q => num_elem(10)
    );
  num_elem_11 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(11),
      Q => num_elem(11)
    );
  num_elem_12 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(12),
      Q => num_elem(12)
    );
  num_elem_13 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(13),
      Q => num_elem(13)
    );
  num_elem_14 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(14),
      Q => num_elem(14)
    );
  num_elem_15 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(15),
      Q => num_elem(15)
    );
  num_elem_16 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(16),
      Q => num_elem(16)
    );
  num_elem_17 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(17),
      Q => num_elem(17)
    );
  num_elem_18 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(18),
      Q => num_elem(18)
    );
  num_elem_19 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(19),
      Q => num_elem(19)
    );
  num_elem_20 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(20),
      Q => num_elem(20)
    );
  num_elem_21 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(21),
      Q => num_elem(21)
    );
  num_elem_22 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(22),
      Q => num_elem(22)
    );
  num_elem_23 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(23),
      Q => num_elem(23)
    );
  num_elem_24 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(24),
      Q => num_elem(24)
    );
  num_elem_25 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(25),
      Q => num_elem(25)
    );
  num_elem_26 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(26),
      Q => num_elem(26)
    );
  num_elem_27 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(27),
      Q => num_elem(27)
    );
  num_elem_28 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(28),
      Q => num_elem(28)
    );
  num_elem_29 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(29),
      Q => num_elem(29)
    );
  num_elem_30 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(30),
      Q => num_elem(30)
    );
  num_elem_31 : FDC
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CLR => reset_IBUF_930,
      D => num_elem_mux0001(31),
      Q => num_elem(31)
    );
  readptr_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_0,
      Q => readptr(0)
    );
  readptr_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_1,
      Q => readptr(1)
    );
  readptr_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_2,
      Q => readptr(2)
    );
  readptr_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_3,
      Q => readptr(3)
    );
  readptr_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_4,
      Q => readptr(4)
    );
  readptr_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_5,
      Q => readptr(5)
    );
  readptr_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_6,
      Q => readptr(6)
    );
  readptr_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_7,
      Q => readptr(7)
    );
  readptr_8 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_8,
      Q => readptr(8)
    );
  readptr_9 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_9,
      Q => readptr(9)
    );
  readptr_10 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_10,
      Q => readptr(10)
    );
  readptr_11 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_11,
      Q => readptr(11)
    );
  readptr_12 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_12,
      Q => readptr(12)
    );
  readptr_13 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_13,
      Q => readptr(13)
    );
  readptr_14 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_14,
      Q => readptr(14)
    );
  readptr_15 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_15,
      Q => readptr(15)
    );
  readptr_16 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_16,
      Q => readptr(16)
    );
  readptr_17 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_17,
      Q => readptr(17)
    );
  readptr_18 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_18,
      Q => readptr(18)
    );
  readptr_19 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_19,
      Q => readptr(19)
    );
  readptr_20 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_20,
      Q => readptr(20)
    );
  readptr_21 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_21,
      Q => readptr(21)
    );
  readptr_22 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_22,
      Q => readptr(22)
    );
  readptr_23 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_23,
      Q => readptr(23)
    );
  readptr_24 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_24,
      Q => readptr(24)
    );
  readptr_25 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_25,
      Q => readptr(25)
    );
  readptr_26 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_26,
      Q => readptr(26)
    );
  readptr_27 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_27,
      Q => readptr(27)
    );
  readptr_28 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_28,
      Q => readptr(28)
    );
  readptr_29 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_29,
      Q => readptr(29)
    );
  readptr_30 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_30,
      Q => readptr(30)
    );
  readptr_31 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => readptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_readptr_eqn_31,
      Q => readptr(31)
    );
  writeptr_0 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_0,
      Q => writeptr(0)
    );
  writeptr_1 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_1,
      Q => writeptr(1)
    );
  writeptr_2 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_2,
      Q => writeptr(2)
    );
  writeptr_3 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_3,
      Q => writeptr(3)
    );
  writeptr_4 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_4,
      Q => writeptr(4)
    );
  writeptr_5 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_5,
      Q => writeptr(5)
    );
  writeptr_6 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_6,
      Q => writeptr(6)
    );
  writeptr_7 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_7,
      Q => writeptr(7)
    );
  writeptr_8 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_8,
      Q => writeptr(8)
    );
  writeptr_9 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_9,
      Q => writeptr(9)
    );
  writeptr_10 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_10,
      Q => writeptr(10)
    );
  writeptr_11 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_11_191,
      Q => writeptr(11)
    );
  writeptr_12 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_12,
      Q => writeptr(12)
    );
  writeptr_13 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_13,
      Q => writeptr(13)
    );
  writeptr_14 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_14,
      Q => writeptr(14)
    );
  writeptr_15 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_15,
      Q => writeptr(15)
    );
  writeptr_16 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_16,
      Q => writeptr(16)
    );
  writeptr_17 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_17,
      Q => writeptr(17)
    );
  writeptr_18 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_18,
      Q => writeptr(18)
    );
  writeptr_19 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_19,
      Q => writeptr(19)
    );
  writeptr_20 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_20,
      Q => writeptr(20)
    );
  writeptr_21 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_21,
      Q => writeptr(21)
    );
  writeptr_22 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_22,
      Q => writeptr(22)
    );
  writeptr_23 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_23,
      Q => writeptr(23)
    );
  writeptr_24 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_24,
      Q => writeptr(24)
    );
  writeptr_25 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_25,
      Q => writeptr(25)
    );
  writeptr_26 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_26,
      Q => writeptr(26)
    );
  writeptr_27 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_27,
      Q => writeptr(27)
    );
  writeptr_28 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_28,
      Q => writeptr(28)
    );
  writeptr_29 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_29,
      Q => writeptr(29)
    );
  writeptr_30 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_30,
      Q => writeptr(30)
    );
  writeptr_31 : FDCE
    generic map(
      INIT => '0'
    )
    port map (
      C => clk_BUFGP_547,
      CE => writeptr_not0001,
      CLR => reset_IBUF_930,
      D => Mcount_writeptr_eqn_31,
      Q => writeptr(31)
    );
  Msub_num_elem_sub0000_cy_0_Q : MUXCY
    port map (
      CI => N1,
      DI => N0,
      S => Msub_num_elem_sub0000_cy_0_rt_398,
      O => Msub_num_elem_sub0000_cy(0)
    );
  Msub_num_elem_sub0000_xor_0_Q : XORCY
    port map (
      CI => N1,
      LI => Msub_num_elem_sub0000_cy_0_rt_398,
      O => num_elem_sub0000(0)
    );
  Msub_num_elem_sub0000_cy_1_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(0),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(1),
      O => Msub_num_elem_sub0000_cy(1)
    );
  Msub_num_elem_sub0000_xor_1_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(0),
      LI => Msub_num_elem_sub0000_lut(1),
      O => num_elem_sub0000(1)
    );
  Msub_num_elem_sub0000_cy_2_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(1),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(2),
      O => Msub_num_elem_sub0000_cy(2)
    );
  Msub_num_elem_sub0000_xor_2_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(1),
      LI => Msub_num_elem_sub0000_lut(2),
      O => num_elem_sub0000(2)
    );
  Msub_num_elem_sub0000_cy_3_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(2),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(3),
      O => Msub_num_elem_sub0000_cy(3)
    );
  Msub_num_elem_sub0000_xor_3_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(2),
      LI => Msub_num_elem_sub0000_lut(3),
      O => num_elem_sub0000(3)
    );
  Msub_num_elem_sub0000_cy_4_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(3),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(4),
      O => Msub_num_elem_sub0000_cy(4)
    );
  Msub_num_elem_sub0000_xor_4_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(3),
      LI => Msub_num_elem_sub0000_lut(4),
      O => num_elem_sub0000(4)
    );
  Msub_num_elem_sub0000_cy_5_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(4),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(5),
      O => Msub_num_elem_sub0000_cy(5)
    );
  Msub_num_elem_sub0000_xor_5_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(4),
      LI => Msub_num_elem_sub0000_lut(5),
      O => num_elem_sub0000(5)
    );
  Msub_num_elem_sub0000_cy_6_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(5),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(6),
      O => Msub_num_elem_sub0000_cy(6)
    );
  Msub_num_elem_sub0000_xor_6_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(5),
      LI => Msub_num_elem_sub0000_lut(6),
      O => num_elem_sub0000(6)
    );
  Msub_num_elem_sub0000_cy_7_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(6),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(7),
      O => Msub_num_elem_sub0000_cy(7)
    );
  Msub_num_elem_sub0000_xor_7_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(6),
      LI => Msub_num_elem_sub0000_lut(7),
      O => num_elem_sub0000(7)
    );
  Msub_num_elem_sub0000_cy_8_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(7),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(8),
      O => Msub_num_elem_sub0000_cy(8)
    );
  Msub_num_elem_sub0000_xor_8_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(7),
      LI => Msub_num_elem_sub0000_lut(8),
      O => num_elem_sub0000(8)
    );
  Msub_num_elem_sub0000_cy_9_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(8),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(9),
      O => Msub_num_elem_sub0000_cy(9)
    );
  Msub_num_elem_sub0000_xor_9_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(8),
      LI => Msub_num_elem_sub0000_lut(9),
      O => num_elem_sub0000(9)
    );
  Msub_num_elem_sub0000_cy_10_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(9),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(10),
      O => Msub_num_elem_sub0000_cy(10)
    );
  Msub_num_elem_sub0000_xor_10_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(9),
      LI => Msub_num_elem_sub0000_lut(10),
      O => num_elem_sub0000(10)
    );
  Msub_num_elem_sub0000_cy_11_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(10),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(11),
      O => Msub_num_elem_sub0000_cy(11)
    );
  Msub_num_elem_sub0000_xor_11_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(10),
      LI => Msub_num_elem_sub0000_lut(11),
      O => num_elem_sub0000(11)
    );
  Msub_num_elem_sub0000_cy_12_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(11),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(12),
      O => Msub_num_elem_sub0000_cy(12)
    );
  Msub_num_elem_sub0000_xor_12_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(11),
      LI => Msub_num_elem_sub0000_lut(12),
      O => num_elem_sub0000(12)
    );
  Msub_num_elem_sub0000_cy_13_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(12),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(13),
      O => Msub_num_elem_sub0000_cy(13)
    );
  Msub_num_elem_sub0000_xor_13_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(12),
      LI => Msub_num_elem_sub0000_lut(13),
      O => num_elem_sub0000(13)
    );
  Msub_num_elem_sub0000_cy_14_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(13),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(14),
      O => Msub_num_elem_sub0000_cy(14)
    );
  Msub_num_elem_sub0000_xor_14_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(13),
      LI => Msub_num_elem_sub0000_lut(14),
      O => num_elem_sub0000(14)
    );
  Msub_num_elem_sub0000_cy_15_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(14),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(15),
      O => Msub_num_elem_sub0000_cy(15)
    );
  Msub_num_elem_sub0000_xor_15_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(14),
      LI => Msub_num_elem_sub0000_lut(15),
      O => num_elem_sub0000(15)
    );
  Msub_num_elem_sub0000_cy_16_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(15),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(16),
      O => Msub_num_elem_sub0000_cy(16)
    );
  Msub_num_elem_sub0000_xor_16_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(15),
      LI => Msub_num_elem_sub0000_lut(16),
      O => num_elem_sub0000(16)
    );
  Msub_num_elem_sub0000_cy_17_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(16),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(17),
      O => Msub_num_elem_sub0000_cy(17)
    );
  Msub_num_elem_sub0000_xor_17_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(16),
      LI => Msub_num_elem_sub0000_lut(17),
      O => num_elem_sub0000(17)
    );
  Msub_num_elem_sub0000_cy_18_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(17),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(18),
      O => Msub_num_elem_sub0000_cy(18)
    );
  Msub_num_elem_sub0000_xor_18_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(17),
      LI => Msub_num_elem_sub0000_lut(18),
      O => num_elem_sub0000(18)
    );
  Msub_num_elem_sub0000_cy_19_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(18),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(19),
      O => Msub_num_elem_sub0000_cy(19)
    );
  Msub_num_elem_sub0000_xor_19_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(18),
      LI => Msub_num_elem_sub0000_lut(19),
      O => num_elem_sub0000(19)
    );
  Msub_num_elem_sub0000_cy_20_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(19),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(20),
      O => Msub_num_elem_sub0000_cy(20)
    );
  Msub_num_elem_sub0000_xor_20_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(19),
      LI => Msub_num_elem_sub0000_lut(20),
      O => num_elem_sub0000(20)
    );
  Msub_num_elem_sub0000_cy_21_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(20),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(21),
      O => Msub_num_elem_sub0000_cy(21)
    );
  Msub_num_elem_sub0000_xor_21_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(20),
      LI => Msub_num_elem_sub0000_lut(21),
      O => num_elem_sub0000(21)
    );
  Msub_num_elem_sub0000_cy_22_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(21),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(22),
      O => Msub_num_elem_sub0000_cy(22)
    );
  Msub_num_elem_sub0000_xor_22_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(21),
      LI => Msub_num_elem_sub0000_lut(22),
      O => num_elem_sub0000(22)
    );
  Msub_num_elem_sub0000_cy_23_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(22),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(23),
      O => Msub_num_elem_sub0000_cy(23)
    );
  Msub_num_elem_sub0000_xor_23_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(22),
      LI => Msub_num_elem_sub0000_lut(23),
      O => num_elem_sub0000(23)
    );
  Msub_num_elem_sub0000_cy_24_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(23),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(24),
      O => Msub_num_elem_sub0000_cy(24)
    );
  Msub_num_elem_sub0000_xor_24_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(23),
      LI => Msub_num_elem_sub0000_lut(24),
      O => num_elem_sub0000(24)
    );
  Msub_num_elem_sub0000_cy_25_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(24),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(25),
      O => Msub_num_elem_sub0000_cy(25)
    );
  Msub_num_elem_sub0000_xor_25_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(24),
      LI => Msub_num_elem_sub0000_lut(25),
      O => num_elem_sub0000(25)
    );
  Msub_num_elem_sub0000_cy_26_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(25),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(26),
      O => Msub_num_elem_sub0000_cy(26)
    );
  Msub_num_elem_sub0000_xor_26_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(25),
      LI => Msub_num_elem_sub0000_lut(26),
      O => num_elem_sub0000(26)
    );
  Msub_num_elem_sub0000_cy_27_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(26),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(27),
      O => Msub_num_elem_sub0000_cy(27)
    );
  Msub_num_elem_sub0000_xor_27_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(26),
      LI => Msub_num_elem_sub0000_lut(27),
      O => num_elem_sub0000(27)
    );
  Msub_num_elem_sub0000_cy_28_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(27),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(28),
      O => Msub_num_elem_sub0000_cy(28)
    );
  Msub_num_elem_sub0000_xor_28_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(27),
      LI => Msub_num_elem_sub0000_lut(28),
      O => num_elem_sub0000(28)
    );
  Msub_num_elem_sub0000_cy_29_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(28),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(29),
      O => Msub_num_elem_sub0000_cy(29)
    );
  Msub_num_elem_sub0000_xor_29_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(28),
      LI => Msub_num_elem_sub0000_lut(29),
      O => num_elem_sub0000(29)
    );
  Msub_num_elem_sub0000_cy_30_Q : MUXCY
    port map (
      CI => Msub_num_elem_sub0000_cy(29),
      DI => N1,
      S => Msub_num_elem_sub0000_lut(30),
      O => Msub_num_elem_sub0000_cy(30)
    );
  Msub_num_elem_sub0000_xor_30_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(29),
      LI => Msub_num_elem_sub0000_lut(30),
      O => num_elem_sub0000(30)
    );
  Msub_num_elem_sub0000_xor_31_Q : XORCY
    port map (
      CI => Msub_num_elem_sub0000_cy(30),
      LI => Msub_num_elem_sub0000_lut(31),
      O => num_elem_sub0000(31)
    );
  Madd_num_elem_addsub0000_cy_0_Q : MUXCY
    port map (
      CI => N0,
      DI => N1,
      S => Madd_num_elem_addsub0000_lut(0),
      O => Madd_num_elem_addsub0000_cy(0)
    );
  Madd_num_elem_addsub0000_xor_0_Q : XORCY
    port map (
      CI => N0,
      LI => Madd_num_elem_addsub0000_lut(0),
      O => num_elem_addsub0000(0)
    );
  Madd_num_elem_addsub0000_cy_1_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(0),
      DI => N0,
      S => Mmux_num_elem_mux0001231_355,
      O => Madd_num_elem_addsub0000_cy(1)
    );
  Madd_num_elem_addsub0000_xor_1_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(0),
      LI => Mmux_num_elem_mux0001231_355,
      O => num_elem_addsub0000(1)
    );
  Madd_num_elem_addsub0000_cy_2_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(1),
      DI => N0,
      S => Mmux_num_elem_mux0001451_379,
      O => Madd_num_elem_addsub0000_cy(2)
    );
  Madd_num_elem_addsub0000_xor_2_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(1),
      LI => Mmux_num_elem_mux0001451_379,
      O => num_elem_addsub0000(2)
    );
  Madd_num_elem_addsub0000_cy_3_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(2),
      DI => N0,
      S => Mmux_num_elem_mux0001511_384,
      O => Madd_num_elem_addsub0000_cy(3)
    );
  Madd_num_elem_addsub0000_xor_3_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(2),
      LI => Mmux_num_elem_mux0001511_384,
      O => num_elem_addsub0000(3)
    );
  Madd_num_elem_addsub0000_cy_4_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(3),
      DI => N0,
      S => Mmux_num_elem_mux0001531_385,
      O => Madd_num_elem_addsub0000_cy(4)
    );
  Madd_num_elem_addsub0000_xor_4_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(3),
      LI => Mmux_num_elem_mux0001531_385,
      O => num_elem_addsub0000(4)
    );
  Madd_num_elem_addsub0000_cy_5_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(4),
      DI => N0,
      S => Mmux_num_elem_mux0001551_386,
      O => Madd_num_elem_addsub0000_cy(5)
    );
  Madd_num_elem_addsub0000_xor_5_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(4),
      LI => Mmux_num_elem_mux0001551_386,
      O => num_elem_addsub0000(5)
    );
  Madd_num_elem_addsub0000_cy_6_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(5),
      DI => N0,
      S => Mmux_num_elem_mux0001571_387,
      O => Madd_num_elem_addsub0000_cy(6)
    );
  Madd_num_elem_addsub0000_xor_6_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(5),
      LI => Mmux_num_elem_mux0001571_387,
      O => num_elem_addsub0000(6)
    );
  Madd_num_elem_addsub0000_cy_7_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(6),
      DI => N0,
      S => Mmux_num_elem_mux0001591_388,
      O => Madd_num_elem_addsub0000_cy(7)
    );
  Madd_num_elem_addsub0000_xor_7_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(6),
      LI => Mmux_num_elem_mux0001591_388,
      O => num_elem_addsub0000(7)
    );
  Madd_num_elem_addsub0000_cy_8_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(7),
      DI => N0,
      S => Mmux_num_elem_mux0001611_390,
      O => Madd_num_elem_addsub0000_cy(8)
    );
  Madd_num_elem_addsub0000_xor_8_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(7),
      LI => Mmux_num_elem_mux0001611_390,
      O => num_elem_addsub0000(8)
    );
  Madd_num_elem_addsub0000_cy_9_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(8),
      DI => N0,
      S => Mmux_num_elem_mux0001631_391,
      O => Madd_num_elem_addsub0000_cy(9)
    );
  Madd_num_elem_addsub0000_xor_9_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(8),
      LI => Mmux_num_elem_mux0001631_391,
      O => num_elem_addsub0000(9)
    );
  Madd_num_elem_addsub0000_cy_10_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(9),
      DI => N0,
      S => Mmux_num_elem_mux000131_364,
      O => Madd_num_elem_addsub0000_cy(10)
    );
  Madd_num_elem_addsub0000_xor_10_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(9),
      LI => Mmux_num_elem_mux000131_364,
      O => num_elem_addsub0000(10)
    );
  Madd_num_elem_addsub0000_cy_11_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(10),
      DI => N0,
      S => Mmux_num_elem_mux000151_383,
      O => Madd_num_elem_addsub0000_cy(11)
    );
  Madd_num_elem_addsub0000_xor_11_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(10),
      LI => Mmux_num_elem_mux000151_383,
      O => num_elem_addsub0000(11)
    );
  Madd_num_elem_addsub0000_cy_12_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(11),
      DI => N0,
      S => Mmux_num_elem_mux000171_393,
      O => Madd_num_elem_addsub0000_cy(12)
    );
  Madd_num_elem_addsub0000_xor_12_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(11),
      LI => Mmux_num_elem_mux000171_393,
      O => num_elem_addsub0000(12)
    );
  Madd_num_elem_addsub0000_cy_13_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(12),
      DI => N0,
      S => Mmux_num_elem_mux000191_396,
      O => Madd_num_elem_addsub0000_cy(13)
    );
  Madd_num_elem_addsub0000_xor_13_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(12),
      LI => Mmux_num_elem_mux000191_396,
      O => num_elem_addsub0000(13)
    );
  Madd_num_elem_addsub0000_cy_14_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(13),
      DI => N0,
      S => Mmux_num_elem_mux0001111_338,
      O => Madd_num_elem_addsub0000_cy(14)
    );
  Madd_num_elem_addsub0000_xor_14_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(13),
      LI => Mmux_num_elem_mux0001111_338,
      O => num_elem_addsub0000(14)
    );
  Madd_num_elem_addsub0000_cy_15_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(14),
      DI => N0,
      S => Mmux_num_elem_mux0001131_341,
      O => Madd_num_elem_addsub0000_cy(15)
    );
  Madd_num_elem_addsub0000_xor_15_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(14),
      LI => Mmux_num_elem_mux0001131_341,
      O => num_elem_addsub0000(15)
    );
  Madd_num_elem_addsub0000_cy_16_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(15),
      DI => N0,
      S => Mmux_num_elem_mux0001151_344,
      O => Madd_num_elem_addsub0000_cy(16)
    );
  Madd_num_elem_addsub0000_xor_16_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(15),
      LI => Mmux_num_elem_mux0001151_344,
      O => num_elem_addsub0000(16)
    );
  Madd_num_elem_addsub0000_cy_17_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(16),
      DI => N0,
      S => Mmux_num_elem_mux0001171_347,
      O => Madd_num_elem_addsub0000_cy(17)
    );
  Madd_num_elem_addsub0000_xor_17_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(16),
      LI => Mmux_num_elem_mux0001171_347,
      O => num_elem_addsub0000(17)
    );
  Madd_num_elem_addsub0000_cy_18_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(17),
      DI => N0,
      S => Mmux_num_elem_mux0001191_350,
      O => Madd_num_elem_addsub0000_cy(18)
    );
  Madd_num_elem_addsub0000_xor_18_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(17),
      LI => Mmux_num_elem_mux0001191_350,
      O => num_elem_addsub0000(18)
    );
  Madd_num_elem_addsub0000_cy_19_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(18),
      DI => N0,
      S => Mmux_num_elem_mux0001211_353,
      O => Madd_num_elem_addsub0000_cy(19)
    );
  Madd_num_elem_addsub0000_xor_19_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(18),
      LI => Mmux_num_elem_mux0001211_353,
      O => num_elem_addsub0000(19)
    );
  Madd_num_elem_addsub0000_cy_20_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(19),
      DI => N0,
      S => Mmux_num_elem_mux0001251_357,
      O => Madd_num_elem_addsub0000_cy(20)
    );
  Madd_num_elem_addsub0000_xor_20_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(19),
      LI => Mmux_num_elem_mux0001251_357,
      O => num_elem_addsub0000(20)
    );
  Madd_num_elem_addsub0000_cy_21_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(20),
      DI => N0,
      S => Mmux_num_elem_mux0001271_359,
      O => Madd_num_elem_addsub0000_cy(21)
    );
  Madd_num_elem_addsub0000_xor_21_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(20),
      LI => Mmux_num_elem_mux0001271_359,
      O => num_elem_addsub0000(21)
    );
  Madd_num_elem_addsub0000_cy_22_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(21),
      DI => N0,
      S => Mmux_num_elem_mux0001291_361,
      O => Madd_num_elem_addsub0000_cy(22)
    );
  Madd_num_elem_addsub0000_xor_22_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(21),
      LI => Mmux_num_elem_mux0001291_361,
      O => num_elem_addsub0000(22)
    );
  Madd_num_elem_addsub0000_cy_23_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(22),
      DI => N0,
      S => Mmux_num_elem_mux0001311_365,
      O => Madd_num_elem_addsub0000_cy(23)
    );
  Madd_num_elem_addsub0000_xor_23_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(22),
      LI => Mmux_num_elem_mux0001311_365,
      O => num_elem_addsub0000(23)
    );
  Madd_num_elem_addsub0000_cy_24_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(23),
      DI => N0,
      S => Mmux_num_elem_mux0001331_367,
      O => Madd_num_elem_addsub0000_cy(24)
    );
  Madd_num_elem_addsub0000_xor_24_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(23),
      LI => Mmux_num_elem_mux0001331_367,
      O => num_elem_addsub0000(24)
    );
  Madd_num_elem_addsub0000_cy_25_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(24),
      DI => N0,
      S => Mmux_num_elem_mux0001351_369,
      O => Madd_num_elem_addsub0000_cy(25)
    );
  Madd_num_elem_addsub0000_xor_25_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(24),
      LI => Mmux_num_elem_mux0001351_369,
      O => num_elem_addsub0000(25)
    );
  Madd_num_elem_addsub0000_cy_26_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(25),
      DI => N0,
      S => Mmux_num_elem_mux0001371_371,
      O => Madd_num_elem_addsub0000_cy(26)
    );
  Madd_num_elem_addsub0000_xor_26_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(25),
      LI => Mmux_num_elem_mux0001371_371,
      O => num_elem_addsub0000(26)
    );
  Madd_num_elem_addsub0000_cy_27_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(26),
      DI => N0,
      S => Mmux_num_elem_mux0001391_373,
      O => Madd_num_elem_addsub0000_cy(27)
    );
  Madd_num_elem_addsub0000_xor_27_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(26),
      LI => Mmux_num_elem_mux0001391_373,
      O => num_elem_addsub0000(27)
    );
  Madd_num_elem_addsub0000_cy_28_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(27),
      DI => N0,
      S => Mmux_num_elem_mux0001411_376,
      O => Madd_num_elem_addsub0000_cy(28)
    );
  Madd_num_elem_addsub0000_xor_28_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(27),
      LI => Mmux_num_elem_mux0001411_376,
      O => num_elem_addsub0000(28)
    );
  Madd_num_elem_addsub0000_cy_29_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(28),
      DI => N0,
      S => Mmux_num_elem_mux0001431_378,
      O => Madd_num_elem_addsub0000_cy(29)
    );
  Madd_num_elem_addsub0000_xor_29_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(28),
      LI => Mmux_num_elem_mux0001431_378,
      O => num_elem_addsub0000(29)
    );
  Madd_num_elem_addsub0000_cy_30_Q : MUXCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(29),
      DI => N0,
      S => Mmux_num_elem_mux0001471_380,
      O => Madd_num_elem_addsub0000_cy(30)
    );
  Madd_num_elem_addsub0000_xor_30_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(29),
      LI => Mmux_num_elem_mux0001471_380,
      O => num_elem_addsub0000(30)
    );
  Madd_num_elem_addsub0000_xor_31_Q : XORCY
    port map (
      CI => Madd_num_elem_addsub0000_cy(30),
      LI => Mmux_num_elem_mux0001491_381,
      O => num_elem_addsub0000(31)
    );
  Mcount_writeptr_cy_0_Q : MUXCY
    port map (
      CI => N0,
      DI => N1,
      S => Mcount_writeptr_lut(0),
      O => Mcount_writeptr_cy(0)
    );
  Mcount_writeptr_xor_0_Q : XORCY
    port map (
      CI => N0,
      LI => Mcount_writeptr_lut(0),
      O => Result_0_1
    );
  Mcount_writeptr_cy_1_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(0),
      DI => N0,
      S => Mcount_writeptr_cy_1_rt_149,
      O => Mcount_writeptr_cy(1)
    );
  Mcount_writeptr_xor_1_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(0),
      LI => Mcount_writeptr_cy_1_rt_149,
      O => Result_1_1
    );
  Mcount_writeptr_cy_2_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(1),
      DI => N0,
      S => Mcount_writeptr_cy_2_rt_171,
      O => Mcount_writeptr_cy(2)
    );
  Mcount_writeptr_xor_2_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(1),
      LI => Mcount_writeptr_cy_2_rt_171,
      O => Result_2_1
    );
  Mcount_writeptr_cy_3_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(2),
      DI => N0,
      S => Mcount_writeptr_cy_3_rt_175,
      O => Mcount_writeptr_cy(3)
    );
  Mcount_writeptr_xor_3_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(2),
      LI => Mcount_writeptr_cy_3_rt_175,
      O => Result_3_1
    );
  Mcount_writeptr_cy_4_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(3),
      DI => N0,
      S => Mcount_writeptr_cy_4_rt_177,
      O => Mcount_writeptr_cy(4)
    );
  Mcount_writeptr_xor_4_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(3),
      LI => Mcount_writeptr_cy_4_rt_177,
      O => Result_4_1
    );
  Mcount_writeptr_cy_5_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(4),
      DI => N0,
      S => Mcount_writeptr_cy_5_rt_179,
      O => Mcount_writeptr_cy(5)
    );
  Mcount_writeptr_xor_5_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(4),
      LI => Mcount_writeptr_cy_5_rt_179,
      O => Result_5_1
    );
  Mcount_writeptr_cy_6_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(5),
      DI => N0,
      S => Mcount_writeptr_cy_6_rt_181,
      O => Mcount_writeptr_cy(6)
    );
  Mcount_writeptr_xor_6_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(5),
      LI => Mcount_writeptr_cy_6_rt_181,
      O => Result_6_1
    );
  Mcount_writeptr_cy_7_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(6),
      DI => N0,
      S => Mcount_writeptr_cy_7_rt_183,
      O => Mcount_writeptr_cy(7)
    );
  Mcount_writeptr_xor_7_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(6),
      LI => Mcount_writeptr_cy_7_rt_183,
      O => Result_7_1
    );
  Mcount_writeptr_cy_8_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(7),
      DI => N0,
      S => Mcount_writeptr_cy_8_rt_185,
      O => Mcount_writeptr_cy(8)
    );
  Mcount_writeptr_xor_8_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(7),
      LI => Mcount_writeptr_cy_8_rt_185,
      O => Result_8_1
    );
  Mcount_writeptr_cy_9_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(8),
      DI => N0,
      S => Mcount_writeptr_cy_9_rt_187,
      O => Mcount_writeptr_cy(9)
    );
  Mcount_writeptr_xor_9_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(8),
      LI => Mcount_writeptr_cy_9_rt_187,
      O => Result_9_1
    );
  Mcount_writeptr_cy_10_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(9),
      DI => N0,
      S => Mcount_writeptr_cy_10_rt_129,
      O => Mcount_writeptr_cy(10)
    );
  Mcount_writeptr_xor_10_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(9),
      LI => Mcount_writeptr_cy_10_rt_129,
      O => Result_10_1
    );
  Mcount_writeptr_cy_11_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(10),
      DI => N0,
      S => Mcount_writeptr_cy_11_rt_131,
      O => Mcount_writeptr_cy(11)
    );
  Mcount_writeptr_xor_11_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(10),
      LI => Mcount_writeptr_cy_11_rt_131,
      O => Result_11_1
    );
  Mcount_writeptr_cy_12_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(11),
      DI => N0,
      S => Mcount_writeptr_cy_12_rt_133,
      O => Mcount_writeptr_cy(12)
    );
  Mcount_writeptr_xor_12_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(11),
      LI => Mcount_writeptr_cy_12_rt_133,
      O => Result_12_1
    );
  Mcount_writeptr_cy_13_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(12),
      DI => N0,
      S => Mcount_writeptr_cy_13_rt_135,
      O => Mcount_writeptr_cy(13)
    );
  Mcount_writeptr_xor_13_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(12),
      LI => Mcount_writeptr_cy_13_rt_135,
      O => Result_13_1
    );
  Mcount_writeptr_cy_14_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(13),
      DI => N0,
      S => Mcount_writeptr_cy_14_rt_137,
      O => Mcount_writeptr_cy(14)
    );
  Mcount_writeptr_xor_14_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(13),
      LI => Mcount_writeptr_cy_14_rt_137,
      O => Result_14_1
    );
  Mcount_writeptr_cy_15_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(14),
      DI => N0,
      S => Mcount_writeptr_cy_15_rt_139,
      O => Mcount_writeptr_cy(15)
    );
  Mcount_writeptr_xor_15_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(14),
      LI => Mcount_writeptr_cy_15_rt_139,
      O => Result_15_1
    );
  Mcount_writeptr_cy_16_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(15),
      DI => N0,
      S => Mcount_writeptr_cy_16_rt_141,
      O => Mcount_writeptr_cy(16)
    );
  Mcount_writeptr_xor_16_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(15),
      LI => Mcount_writeptr_cy_16_rt_141,
      O => Result_16_1
    );
  Mcount_writeptr_cy_17_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(16),
      DI => N0,
      S => Mcount_writeptr_cy_17_rt_143,
      O => Mcount_writeptr_cy(17)
    );
  Mcount_writeptr_xor_17_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(16),
      LI => Mcount_writeptr_cy_17_rt_143,
      O => Result_17_1
    );
  Mcount_writeptr_cy_18_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(17),
      DI => N0,
      S => Mcount_writeptr_cy_18_rt_145,
      O => Mcount_writeptr_cy(18)
    );
  Mcount_writeptr_xor_18_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(17),
      LI => Mcount_writeptr_cy_18_rt_145,
      O => Result_18_1
    );
  Mcount_writeptr_cy_19_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(18),
      DI => N0,
      S => Mcount_writeptr_cy_19_rt_147,
      O => Mcount_writeptr_cy(19)
    );
  Mcount_writeptr_xor_19_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(18),
      LI => Mcount_writeptr_cy_19_rt_147,
      O => Result_19_1
    );
  Mcount_writeptr_cy_20_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(19),
      DI => N0,
      S => Mcount_writeptr_cy_20_rt_151,
      O => Mcount_writeptr_cy(20)
    );
  Mcount_writeptr_xor_20_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(19),
      LI => Mcount_writeptr_cy_20_rt_151,
      O => Result_20_1
    );
  Mcount_writeptr_cy_21_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(20),
      DI => N0,
      S => Mcount_writeptr_cy_21_rt_153,
      O => Mcount_writeptr_cy(21)
    );
  Mcount_writeptr_xor_21_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(20),
      LI => Mcount_writeptr_cy_21_rt_153,
      O => Result_21_1
    );
  Mcount_writeptr_cy_22_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(21),
      DI => N0,
      S => Mcount_writeptr_cy_22_rt_155,
      O => Mcount_writeptr_cy(22)
    );
  Mcount_writeptr_xor_22_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(21),
      LI => Mcount_writeptr_cy_22_rt_155,
      O => Result_22_1
    );
  Mcount_writeptr_cy_23_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(22),
      DI => N0,
      S => Mcount_writeptr_cy_23_rt_157,
      O => Mcount_writeptr_cy(23)
    );
  Mcount_writeptr_xor_23_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(22),
      LI => Mcount_writeptr_cy_23_rt_157,
      O => Result_23_1
    );
  Mcount_writeptr_cy_24_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(23),
      DI => N0,
      S => Mcount_writeptr_cy_24_rt_159,
      O => Mcount_writeptr_cy(24)
    );
  Mcount_writeptr_xor_24_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(23),
      LI => Mcount_writeptr_cy_24_rt_159,
      O => Result_24_1
    );
  Mcount_writeptr_cy_25_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(24),
      DI => N0,
      S => Mcount_writeptr_cy_25_rt_161,
      O => Mcount_writeptr_cy(25)
    );
  Mcount_writeptr_xor_25_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(24),
      LI => Mcount_writeptr_cy_25_rt_161,
      O => Result_25_1
    );
  Mcount_writeptr_cy_26_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(25),
      DI => N0,
      S => Mcount_writeptr_cy_26_rt_163,
      O => Mcount_writeptr_cy(26)
    );
  Mcount_writeptr_xor_26_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(25),
      LI => Mcount_writeptr_cy_26_rt_163,
      O => Result_26_1
    );
  Mcount_writeptr_cy_27_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(26),
      DI => N0,
      S => Mcount_writeptr_cy_27_rt_165,
      O => Mcount_writeptr_cy(27)
    );
  Mcount_writeptr_xor_27_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(26),
      LI => Mcount_writeptr_cy_27_rt_165,
      O => Result_27_1
    );
  Mcount_writeptr_cy_28_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(27),
      DI => N0,
      S => Mcount_writeptr_cy_28_rt_167,
      O => Mcount_writeptr_cy(28)
    );
  Mcount_writeptr_xor_28_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(27),
      LI => Mcount_writeptr_cy_28_rt_167,
      O => Result_28_1
    );
  Mcount_writeptr_cy_29_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(28),
      DI => N0,
      S => Mcount_writeptr_cy_29_rt_169,
      O => Mcount_writeptr_cy(29)
    );
  Mcount_writeptr_xor_29_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(28),
      LI => Mcount_writeptr_cy_29_rt_169,
      O => Result_29_1
    );
  Mcount_writeptr_cy_30_Q : MUXCY
    port map (
      CI => Mcount_writeptr_cy(29),
      DI => N0,
      S => Mcount_writeptr_cy_30_rt_173,
      O => Mcount_writeptr_cy(30)
    );
  Mcount_writeptr_xor_30_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(29),
      LI => Mcount_writeptr_cy_30_rt_173,
      O => Result_30_1
    );
  Mcount_writeptr_xor_31_Q : XORCY
    port map (
      CI => Mcount_writeptr_cy(30),
      LI => Mcount_writeptr_xor_31_rt_221,
      O => Result_31_1
    );
  Mmux_varindex0000_2_f7_6 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f67,
      I1 => Mmux_varindex0000_3_f67,
      S => readptr(3),
      O => Q_varindex0000(7)
    );
  Mmux_varindex0000_4_f6_6 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f57,
      I1 => Mmux_varindex0000_5_f515,
      S => readptr(2),
      O => Mmux_varindex0000_4_f67
    );
  Mmux_varindex0000_6_f5_6 : MUXF5
    port map (
      I0 => Mmux_varindex0000_87_333,
      I1 => Mmux_varindex0000_723_318,
      S => readptr(1),
      O => Mmux_varindex0000_6_f57
    );
  Mmux_varindex0000_87 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_7_614,
      I2 => memory_1_7_677,
      O => Mmux_varindex0000_87_333
    );
  Mmux_varindex0000_723 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_7_686,
      I2 => memory_3_7_695,
      O => Mmux_varindex0000_723_318
    );
  Mmux_varindex0000_5_f5_14 : MUXF5
    port map (
      I0 => Mmux_varindex0000_722_317,
      I1 => Mmux_varindex0000_623_286,
      S => readptr(1),
      O => Mmux_varindex0000_5_f515
    );
  Mmux_varindex0000_722 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_7_704,
      I2 => memory_5_7_713,
      O => Mmux_varindex0000_722_317
    );
  Mmux_varindex0000_623 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_7_722,
      I2 => memory_7_7_731,
      O => Mmux_varindex0000_623_286
    );
  Mmux_varindex0000_3_f6_6 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f514,
      I1 => Mmux_varindex0000_4_f57,
      S => readptr(2),
      O => Mmux_varindex0000_3_f67
    );
  Mmux_varindex0000_5_f5_13 : MUXF5
    port map (
      I0 => Mmux_varindex0000_721_316,
      I1 => Mmux_varindex0000_622_285,
      S => readptr(1),
      O => Mmux_varindex0000_5_f514
    );
  Mmux_varindex0000_721 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_7_740,
      I2 => memory_9_7_749,
      O => Mmux_varindex0000_721_316
    );
  Mmux_varindex0000_622 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_7_623,
      I2 => memory_11_7_632,
      O => Mmux_varindex0000_622_285
    );
  Mmux_varindex0000_4_f5_6 : MUXF5
    port map (
      I0 => Mmux_varindex0000_621_284,
      I1 => Mmux_varindex0000_57_253,
      S => readptr(1),
      O => Mmux_varindex0000_4_f57
    );
  Mmux_varindex0000_621 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_7_641,
      I2 => memory_13_7_650,
      O => Mmux_varindex0000_621_284
    );
  Mmux_varindex0000_57 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_7_659,
      I2 => memory_15_7_668,
      O => Mmux_varindex0000_57_253
    );
  Mmux_varindex0000_2_f7_5 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f66,
      I1 => Mmux_varindex0000_3_f66,
      S => readptr(3),
      O => Q_varindex0000(6)
    );
  Mmux_varindex0000_4_f6_5 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f56,
      I1 => Mmux_varindex0000_5_f513,
      S => readptr(2),
      O => Mmux_varindex0000_4_f66
    );
  Mmux_varindex0000_6_f5_5 : MUXF5
    port map (
      I0 => Mmux_varindex0000_86_332,
      I1 => Mmux_varindex0000_720_315,
      S => readptr(1),
      O => Mmux_varindex0000_6_f56
    );
  Mmux_varindex0000_86 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_6_613,
      I2 => memory_1_6_676,
      O => Mmux_varindex0000_86_332
    );
  Mmux_varindex0000_720 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_6_685,
      I2 => memory_3_6_694,
      O => Mmux_varindex0000_720_315
    );
  Mmux_varindex0000_5_f5_12 : MUXF5
    port map (
      I0 => Mmux_varindex0000_719_313,
      I1 => Mmux_varindex0000_620_283,
      S => readptr(1),
      O => Mmux_varindex0000_5_f513
    );
  Mmux_varindex0000_719 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_6_703,
      I2 => memory_5_6_712,
      O => Mmux_varindex0000_719_313
    );
  Mmux_varindex0000_620 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_6_721,
      I2 => memory_7_6_730,
      O => Mmux_varindex0000_620_283
    );
  Mmux_varindex0000_3_f6_5 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f512,
      I1 => Mmux_varindex0000_4_f56,
      S => readptr(2),
      O => Mmux_varindex0000_3_f66
    );
  Mmux_varindex0000_5_f5_11 : MUXF5
    port map (
      I0 => Mmux_varindex0000_718_312,
      I1 => Mmux_varindex0000_619_281,
      S => readptr(1),
      O => Mmux_varindex0000_5_f512
    );
  Mmux_varindex0000_718 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_6_739,
      I2 => memory_9_6_748,
      O => Mmux_varindex0000_718_312
    );
  Mmux_varindex0000_619 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_6_622,
      I2 => memory_11_6_631,
      O => Mmux_varindex0000_619_281
    );
  Mmux_varindex0000_4_f5_5 : MUXF5
    port map (
      I0 => Mmux_varindex0000_618_280,
      I1 => Mmux_varindex0000_56_252,
      S => readptr(1),
      O => Mmux_varindex0000_4_f56
    );
  Mmux_varindex0000_618 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_6_640,
      I2 => memory_13_6_649,
      O => Mmux_varindex0000_618_280
    );
  Mmux_varindex0000_56 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_6_658,
      I2 => memory_15_6_667,
      O => Mmux_varindex0000_56_252
    );
  Mmux_varindex0000_2_f7_4 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f65,
      I1 => Mmux_varindex0000_3_f65,
      S => readptr(3),
      O => Q_varindex0000(5)
    );
  Mmux_varindex0000_4_f6_4 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f55,
      I1 => Mmux_varindex0000_5_f511,
      S => readptr(2),
      O => Mmux_varindex0000_4_f65
    );
  Mmux_varindex0000_6_f5_4 : MUXF5
    port map (
      I0 => Mmux_varindex0000_85_331,
      I1 => Mmux_varindex0000_717_311,
      S => readptr(1),
      O => Mmux_varindex0000_6_f55
    );
  Mmux_varindex0000_85 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_5_612,
      I2 => memory_1_5_675,
      O => Mmux_varindex0000_85_331
    );
  Mmux_varindex0000_717 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_5_684,
      I2 => memory_3_5_693,
      O => Mmux_varindex0000_717_311
    );
  Mmux_varindex0000_5_f5_10 : MUXF5
    port map (
      I0 => Mmux_varindex0000_716_310,
      I1 => Mmux_varindex0000_617_279,
      S => readptr(1),
      O => Mmux_varindex0000_5_f511
    );
  Mmux_varindex0000_716 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_5_702,
      I2 => memory_5_5_711,
      O => Mmux_varindex0000_716_310
    );
  Mmux_varindex0000_617 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_5_720,
      I2 => memory_7_5_729,
      O => Mmux_varindex0000_617_279
    );
  Mmux_varindex0000_3_f6_4 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f510,
      I1 => Mmux_varindex0000_4_f55,
      S => readptr(2),
      O => Mmux_varindex0000_3_f65
    );
  Mmux_varindex0000_5_f5_9 : MUXF5
    port map (
      I0 => Mmux_varindex0000_715_309,
      I1 => Mmux_varindex0000_616_278,
      S => readptr(1),
      O => Mmux_varindex0000_5_f510
    );
  Mmux_varindex0000_715 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_5_738,
      I2 => memory_9_5_747,
      O => Mmux_varindex0000_715_309
    );
  Mmux_varindex0000_616 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_5_621,
      I2 => memory_11_5_630,
      O => Mmux_varindex0000_616_278
    );
  Mmux_varindex0000_4_f5_4 : MUXF5
    port map (
      I0 => Mmux_varindex0000_615_277,
      I1 => Mmux_varindex0000_55_251,
      S => readptr(1),
      O => Mmux_varindex0000_4_f55
    );
  Mmux_varindex0000_615 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_5_639,
      I2 => memory_13_5_648,
      O => Mmux_varindex0000_615_277
    );
  Mmux_varindex0000_55 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_5_657,
      I2 => memory_15_5_666,
      O => Mmux_varindex0000_55_251
    );
  Mmux_varindex0000_2_f7_3 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f64,
      I1 => Mmux_varindex0000_3_f64,
      S => readptr(3),
      O => Q_varindex0000(4)
    );
  Mmux_varindex0000_4_f6_3 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f54,
      I1 => Mmux_varindex0000_5_f59,
      S => readptr(2),
      O => Mmux_varindex0000_4_f64
    );
  Mmux_varindex0000_6_f5_3 : MUXF5
    port map (
      I0 => Mmux_varindex0000_84_330,
      I1 => Mmux_varindex0000_714_308,
      S => readptr(1),
      O => Mmux_varindex0000_6_f54
    );
  Mmux_varindex0000_84 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_4_611,
      I2 => memory_1_4_674,
      O => Mmux_varindex0000_84_330
    );
  Mmux_varindex0000_714 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_4_683,
      I2 => memory_3_4_692,
      O => Mmux_varindex0000_714_308
    );
  Mmux_varindex0000_5_f5_8 : MUXF5
    port map (
      I0 => Mmux_varindex0000_713_307,
      I1 => Mmux_varindex0000_614_276,
      S => readptr(1),
      O => Mmux_varindex0000_5_f59
    );
  Mmux_varindex0000_713 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_4_701,
      I2 => memory_5_4_710,
      O => Mmux_varindex0000_713_307
    );
  Mmux_varindex0000_614 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_4_719,
      I2 => memory_7_4_728,
      O => Mmux_varindex0000_614_276
    );
  Mmux_varindex0000_3_f6_3 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f58,
      I1 => Mmux_varindex0000_4_f54,
      S => readptr(2),
      O => Mmux_varindex0000_3_f64
    );
  Mmux_varindex0000_5_f5_7 : MUXF5
    port map (
      I0 => Mmux_varindex0000_712_306,
      I1 => Mmux_varindex0000_613_275,
      S => readptr(1),
      O => Mmux_varindex0000_5_f58
    );
  Mmux_varindex0000_712 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_4_737,
      I2 => memory_9_4_746,
      O => Mmux_varindex0000_712_306
    );
  Mmux_varindex0000_613 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_4_620,
      I2 => memory_11_4_629,
      O => Mmux_varindex0000_613_275
    );
  Mmux_varindex0000_4_f5_3 : MUXF5
    port map (
      I0 => Mmux_varindex0000_612_274,
      I1 => Mmux_varindex0000_54_250,
      S => readptr(1),
      O => Mmux_varindex0000_4_f54
    );
  Mmux_varindex0000_612 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_4_638,
      I2 => memory_13_4_647,
      O => Mmux_varindex0000_612_274
    );
  Mmux_varindex0000_54 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_4_656,
      I2 => memory_15_4_665,
      O => Mmux_varindex0000_54_250
    );
  Mmux_varindex0000_2_f7_2 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f63,
      I1 => Mmux_varindex0000_3_f63,
      S => readptr(3),
      O => Q_varindex0000(3)
    );
  Mmux_varindex0000_4_f6_2 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f53,
      I1 => Mmux_varindex0000_5_f57,
      S => readptr(2),
      O => Mmux_varindex0000_4_f63
    );
  Mmux_varindex0000_6_f5_2 : MUXF5
    port map (
      I0 => Mmux_varindex0000_83_329,
      I1 => Mmux_varindex0000_711_305,
      S => readptr(1),
      O => Mmux_varindex0000_6_f53
    );
  Mmux_varindex0000_83 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_3_610,
      I2 => memory_1_3_673,
      O => Mmux_varindex0000_83_329
    );
  Mmux_varindex0000_711 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_3_682,
      I2 => memory_3_3_691,
      O => Mmux_varindex0000_711_305
    );
  Mmux_varindex0000_5_f5_6 : MUXF5
    port map (
      I0 => Mmux_varindex0000_710_304,
      I1 => Mmux_varindex0000_611_273,
      S => readptr(1),
      O => Mmux_varindex0000_5_f57
    );
  Mmux_varindex0000_710 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_3_700,
      I2 => memory_5_3_709,
      O => Mmux_varindex0000_710_304
    );
  Mmux_varindex0000_611 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_3_718,
      I2 => memory_7_3_727,
      O => Mmux_varindex0000_611_273
    );
  Mmux_varindex0000_3_f6_2 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f56,
      I1 => Mmux_varindex0000_4_f53,
      S => readptr(2),
      O => Mmux_varindex0000_3_f63
    );
  Mmux_varindex0000_5_f5_5 : MUXF5
    port map (
      I0 => Mmux_varindex0000_79_325,
      I1 => Mmux_varindex0000_610_272,
      S => readptr(1),
      O => Mmux_varindex0000_5_f56
    );
  Mmux_varindex0000_79 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_3_736,
      I2 => memory_9_3_745,
      O => Mmux_varindex0000_79_325
    );
  Mmux_varindex0000_610 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_3_619,
      I2 => memory_11_3_628,
      O => Mmux_varindex0000_610_272
    );
  Mmux_varindex0000_4_f5_2 : MUXF5
    port map (
      I0 => Mmux_varindex0000_69_293,
      I1 => Mmux_varindex0000_53_249,
      S => readptr(1),
      O => Mmux_varindex0000_4_f53
    );
  Mmux_varindex0000_69 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_3_637,
      I2 => memory_13_3_646,
      O => Mmux_varindex0000_69_293
    );
  Mmux_varindex0000_53 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_3_655,
      I2 => memory_15_3_664,
      O => Mmux_varindex0000_53_249
    );
  Mmux_varindex0000_2_f7_1 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f62,
      I1 => Mmux_varindex0000_3_f62,
      S => readptr(3),
      O => Q_varindex0000(2)
    );
  Mmux_varindex0000_4_f6_1 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f52,
      I1 => Mmux_varindex0000_5_f55,
      S => readptr(2),
      O => Mmux_varindex0000_4_f62
    );
  Mmux_varindex0000_6_f5_1 : MUXF5
    port map (
      I0 => Mmux_varindex0000_82_328,
      I1 => Mmux_varindex0000_78_324,
      S => readptr(1),
      O => Mmux_varindex0000_6_f52
    );
  Mmux_varindex0000_82 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_2_609,
      I2 => memory_1_2_672,
      O => Mmux_varindex0000_82_328
    );
  Mmux_varindex0000_78 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_2_681,
      I2 => memory_3_2_690,
      O => Mmux_varindex0000_78_324
    );
  Mmux_varindex0000_5_f5_4 : MUXF5
    port map (
      I0 => Mmux_varindex0000_77_323,
      I1 => Mmux_varindex0000_68_292,
      S => readptr(1),
      O => Mmux_varindex0000_5_f55
    );
  Mmux_varindex0000_77 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_2_699,
      I2 => memory_5_2_708,
      O => Mmux_varindex0000_77_323
    );
  Mmux_varindex0000_68 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_2_717,
      I2 => memory_7_2_726,
      O => Mmux_varindex0000_68_292
    );
  Mmux_varindex0000_3_f6_1 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f54,
      I1 => Mmux_varindex0000_4_f52,
      S => readptr(2),
      O => Mmux_varindex0000_3_f62
    );
  Mmux_varindex0000_5_f5_3 : MUXF5
    port map (
      I0 => Mmux_varindex0000_76_322,
      I1 => Mmux_varindex0000_67_291,
      S => readptr(1),
      O => Mmux_varindex0000_5_f54
    );
  Mmux_varindex0000_76 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_2_735,
      I2 => memory_9_2_744,
      O => Mmux_varindex0000_76_322
    );
  Mmux_varindex0000_67 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_2_618,
      I2 => memory_11_2_627,
      O => Mmux_varindex0000_67_291
    );
  Mmux_varindex0000_4_f5_1 : MUXF5
    port map (
      I0 => Mmux_varindex0000_66_290,
      I1 => Mmux_varindex0000_52_248,
      S => readptr(1),
      O => Mmux_varindex0000_4_f52
    );
  Mmux_varindex0000_66 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_2_636,
      I2 => memory_13_2_645,
      O => Mmux_varindex0000_66_290
    );
  Mmux_varindex0000_52 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_2_654,
      I2 => memory_15_2_663,
      O => Mmux_varindex0000_52_248
    );
  Mmux_varindex0000_2_f7_0 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f61,
      I1 => Mmux_varindex0000_3_f61,
      S => readptr(3),
      O => Q_varindex0000(1)
    );
  Mmux_varindex0000_4_f6_0 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f51,
      I1 => Mmux_varindex0000_5_f53,
      S => readptr(2),
      O => Mmux_varindex0000_4_f61
    );
  Mmux_varindex0000_6_f5_0 : MUXF5
    port map (
      I0 => Mmux_varindex0000_81_327,
      I1 => Mmux_varindex0000_75_321,
      S => readptr(1),
      O => Mmux_varindex0000_6_f51
    );
  Mmux_varindex0000_81 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_1_608,
      I2 => memory_1_1_671,
      O => Mmux_varindex0000_81_327
    );
  Mmux_varindex0000_75 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_1_680,
      I2 => memory_3_1_689,
      O => Mmux_varindex0000_75_321
    );
  Mmux_varindex0000_5_f5_2 : MUXF5
    port map (
      I0 => Mmux_varindex0000_74_320,
      I1 => Mmux_varindex0000_65_289,
      S => readptr(1),
      O => Mmux_varindex0000_5_f53
    );
  Mmux_varindex0000_74 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_1_698,
      I2 => memory_5_1_707,
      O => Mmux_varindex0000_74_320
    );
  Mmux_varindex0000_65 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_1_716,
      I2 => memory_7_1_725,
      O => Mmux_varindex0000_65_289
    );
  Mmux_varindex0000_3_f6_0 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f52,
      I1 => Mmux_varindex0000_4_f51,
      S => readptr(2),
      O => Mmux_varindex0000_3_f61
    );
  Mmux_varindex0000_5_f5_1 : MUXF5
    port map (
      I0 => Mmux_varindex0000_73_319,
      I1 => Mmux_varindex0000_64_288,
      S => readptr(1),
      O => Mmux_varindex0000_5_f52
    );
  Mmux_varindex0000_73 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_1_734,
      I2 => memory_9_1_743,
      O => Mmux_varindex0000_73_319
    );
  Mmux_varindex0000_64 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_1_617,
      I2 => memory_11_1_626,
      O => Mmux_varindex0000_64_288
    );
  Mmux_varindex0000_4_f5_0 : MUXF5
    port map (
      I0 => Mmux_varindex0000_63_287,
      I1 => Mmux_varindex0000_51_247,
      S => readptr(1),
      O => Mmux_varindex0000_4_f51
    );
  Mmux_varindex0000_63 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_1_635,
      I2 => memory_13_1_644,
      O => Mmux_varindex0000_63_287
    );
  Mmux_varindex0000_51 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_1_653,
      I2 => memory_15_1_662,
      O => Mmux_varindex0000_51_247
    );
  Mmux_varindex0000_2_f7 : MUXF7
    port map (
      I0 => Mmux_varindex0000_4_f6_238,
      I1 => Mmux_varindex0000_3_f6_222,
      S => readptr(3),
      O => Q_varindex0000(0)
    );
  Mmux_varindex0000_4_f6 : MUXF6
    port map (
      I0 => Mmux_varindex0000_6_f5_294,
      I1 => Mmux_varindex0000_5_f51,
      S => readptr(2),
      O => Mmux_varindex0000_4_f6_238
    );
  Mmux_varindex0000_6_f5 : MUXF5
    port map (
      I0 => Mmux_varindex0000_8_326,
      I1 => Mmux_varindex0000_72_314,
      S => readptr(1),
      O => Mmux_varindex0000_6_f5_294
    );
  Mmux_varindex0000_8 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_0_0_607,
      I2 => memory_1_0_670,
      O => Mmux_varindex0000_8_326
    );
  Mmux_varindex0000_72 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_2_0_679,
      I2 => memory_3_0_688,
      O => Mmux_varindex0000_72_314
    );
  Mmux_varindex0000_5_f5_0 : MUXF5
    port map (
      I0 => Mmux_varindex0000_71_303,
      I1 => Mmux_varindex0000_62_282,
      S => readptr(1),
      O => Mmux_varindex0000_5_f51
    );
  Mmux_varindex0000_71 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_4_0_697,
      I2 => memory_5_0_706,
      O => Mmux_varindex0000_71_303
    );
  Mmux_varindex0000_62 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_6_0_715,
      I2 => memory_7_0_724,
      O => Mmux_varindex0000_62_282
    );
  Mmux_varindex0000_3_f6 : MUXF6
    port map (
      I0 => Mmux_varindex0000_5_f5_254,
      I1 => Mmux_varindex0000_4_f5_230,
      S => readptr(2),
      O => Mmux_varindex0000_3_f6_222
    );
  Mmux_varindex0000_5_f5 : MUXF5
    port map (
      I0 => Mmux_varindex0000_7_302,
      I1 => Mmux_varindex0000_61_271,
      S => readptr(1),
      O => Mmux_varindex0000_5_f5_254
    );
  Mmux_varindex0000_7 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_8_0_733,
      I2 => memory_9_0_742,
      O => Mmux_varindex0000_7_302
    );
  Mmux_varindex0000_61 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_10_0_616,
      I2 => memory_11_0_625,
      O => Mmux_varindex0000_61_271
    );
  Mmux_varindex0000_4_f5 : MUXF5
    port map (
      I0 => Mmux_varindex0000_6_270,
      I1 => Mmux_varindex0000_5_246,
      S => readptr(1),
      O => Mmux_varindex0000_4_f5_230
    );
  Mmux_varindex0000_6 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_12_0_634,
      I2 => memory_13_0_643,
      O => Mmux_varindex0000_6_270
    );
  Mmux_varindex0000_5 : LUT3
    generic map(
      INIT => X"E4"
    )
    port map (
      I0 => readptr(0),
      I1 => memory_14_0_652,
      I2 => memory_15_0_661,
      O => Mmux_varindex0000_5_246
    );
  Mcount_readptr_cy_0_Q : MUXCY
    port map (
      CI => N0,
      DI => N1,
      S => Mcount_readptr_lut(0),
      O => Mcount_readptr_cy(0)
    );
  Mcount_readptr_xor_0_Q : XORCY
    port map (
      CI => N0,
      LI => Mcount_readptr_lut(0),
      O => Result(0)
    );
  Mcount_readptr_cy_1_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(0),
      DI => N0,
      S => Mcount_readptr_cy_1_rt_54,
      O => Mcount_readptr_cy(1)
    );
  Mcount_readptr_xor_1_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(0),
      LI => Mcount_readptr_cy_1_rt_54,
      O => Result(1)
    );
  Mcount_readptr_cy_2_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(1),
      DI => N0,
      S => Mcount_readptr_cy_2_rt_76,
      O => Mcount_readptr_cy(2)
    );
  Mcount_readptr_xor_2_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(1),
      LI => Mcount_readptr_cy_2_rt_76,
      O => Result(2)
    );
  Mcount_readptr_cy_3_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(2),
      DI => N0,
      S => Mcount_readptr_cy_3_rt_80,
      O => Mcount_readptr_cy(3)
    );
  Mcount_readptr_xor_3_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(2),
      LI => Mcount_readptr_cy_3_rt_80,
      O => Result(3)
    );
  Mcount_readptr_cy_4_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(3),
      DI => N0,
      S => Mcount_readptr_cy_4_rt_82,
      O => Mcount_readptr_cy(4)
    );
  Mcount_readptr_xor_4_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(3),
      LI => Mcount_readptr_cy_4_rt_82,
      O => Result(4)
    );
  Mcount_readptr_cy_5_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(4),
      DI => N0,
      S => Mcount_readptr_cy_5_rt_84,
      O => Mcount_readptr_cy(5)
    );
  Mcount_readptr_xor_5_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(4),
      LI => Mcount_readptr_cy_5_rt_84,
      O => Result(5)
    );
  Mcount_readptr_cy_6_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(5),
      DI => N0,
      S => Mcount_readptr_cy_6_rt_86,
      O => Mcount_readptr_cy(6)
    );
  Mcount_readptr_xor_6_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(5),
      LI => Mcount_readptr_cy_6_rt_86,
      O => Result(6)
    );
  Mcount_readptr_cy_7_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(6),
      DI => N0,
      S => Mcount_readptr_cy_7_rt_88,
      O => Mcount_readptr_cy(7)
    );
  Mcount_readptr_xor_7_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(6),
      LI => Mcount_readptr_cy_7_rt_88,
      O => Result(7)
    );
  Mcount_readptr_cy_8_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(7),
      DI => N0,
      S => Mcount_readptr_cy_8_rt_90,
      O => Mcount_readptr_cy(8)
    );
  Mcount_readptr_xor_8_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(7),
      LI => Mcount_readptr_cy_8_rt_90,
      O => Result(8)
    );
  Mcount_readptr_cy_9_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(8),
      DI => N0,
      S => Mcount_readptr_cy_9_rt_92,
      O => Mcount_readptr_cy(9)
    );
  Mcount_readptr_xor_9_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(8),
      LI => Mcount_readptr_cy_9_rt_92,
      O => Result(9)
    );
  Mcount_readptr_cy_10_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(9),
      DI => N0,
      S => Mcount_readptr_cy_10_rt_34,
      O => Mcount_readptr_cy(10)
    );
  Mcount_readptr_xor_10_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(9),
      LI => Mcount_readptr_cy_10_rt_34,
      O => Result(10)
    );
  Mcount_readptr_cy_11_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(10),
      DI => N0,
      S => Mcount_readptr_cy_11_rt_36,
      O => Mcount_readptr_cy(11)
    );
  Mcount_readptr_xor_11_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(10),
      LI => Mcount_readptr_cy_11_rt_36,
      O => Result(11)
    );
  Mcount_readptr_cy_12_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(11),
      DI => N0,
      S => Mcount_readptr_cy_12_rt_38,
      O => Mcount_readptr_cy(12)
    );
  Mcount_readptr_xor_12_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(11),
      LI => Mcount_readptr_cy_12_rt_38,
      O => Result(12)
    );
  Mcount_readptr_cy_13_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(12),
      DI => N0,
      S => Mcount_readptr_cy_13_rt_40,
      O => Mcount_readptr_cy(13)
    );
  Mcount_readptr_xor_13_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(12),
      LI => Mcount_readptr_cy_13_rt_40,
      O => Result(13)
    );
  Mcount_readptr_cy_14_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(13),
      DI => N0,
      S => Mcount_readptr_cy_14_rt_42,
      O => Mcount_readptr_cy(14)
    );
  Mcount_readptr_xor_14_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(13),
      LI => Mcount_readptr_cy_14_rt_42,
      O => Result(14)
    );
  Mcount_readptr_cy_15_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(14),
      DI => N0,
      S => Mcount_readptr_cy_15_rt_44,
      O => Mcount_readptr_cy(15)
    );
  Mcount_readptr_xor_15_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(14),
      LI => Mcount_readptr_cy_15_rt_44,
      O => Result(15)
    );
  Mcount_readptr_cy_16_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(15),
      DI => N0,
      S => Mcount_readptr_cy_16_rt_46,
      O => Mcount_readptr_cy(16)
    );
  Mcount_readptr_xor_16_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(15),
      LI => Mcount_readptr_cy_16_rt_46,
      O => Result(16)
    );
  Mcount_readptr_cy_17_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(16),
      DI => N0,
      S => Mcount_readptr_cy_17_rt_48,
      O => Mcount_readptr_cy(17)
    );
  Mcount_readptr_xor_17_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(16),
      LI => Mcount_readptr_cy_17_rt_48,
      O => Result(17)
    );
  Mcount_readptr_cy_18_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(17),
      DI => N0,
      S => Mcount_readptr_cy_18_rt_50,
      O => Mcount_readptr_cy(18)
    );
  Mcount_readptr_xor_18_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(17),
      LI => Mcount_readptr_cy_18_rt_50,
      O => Result(18)
    );
  Mcount_readptr_cy_19_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(18),
      DI => N0,
      S => Mcount_readptr_cy_19_rt_52,
      O => Mcount_readptr_cy(19)
    );
  Mcount_readptr_xor_19_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(18),
      LI => Mcount_readptr_cy_19_rt_52,
      O => Result(19)
    );
  Mcount_readptr_cy_20_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(19),
      DI => N0,
      S => Mcount_readptr_cy_20_rt_56,
      O => Mcount_readptr_cy(20)
    );
  Mcount_readptr_xor_20_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(19),
      LI => Mcount_readptr_cy_20_rt_56,
      O => Result(20)
    );
  Mcount_readptr_cy_21_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(20),
      DI => N0,
      S => Mcount_readptr_cy_21_rt_58,
      O => Mcount_readptr_cy(21)
    );
  Mcount_readptr_xor_21_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(20),
      LI => Mcount_readptr_cy_21_rt_58,
      O => Result(21)
    );
  Mcount_readptr_cy_22_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(21),
      DI => N0,
      S => Mcount_readptr_cy_22_rt_60,
      O => Mcount_readptr_cy(22)
    );
  Mcount_readptr_xor_22_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(21),
      LI => Mcount_readptr_cy_22_rt_60,
      O => Result(22)
    );
  Mcount_readptr_cy_23_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(22),
      DI => N0,
      S => Mcount_readptr_cy_23_rt_62,
      O => Mcount_readptr_cy(23)
    );
  Mcount_readptr_xor_23_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(22),
      LI => Mcount_readptr_cy_23_rt_62,
      O => Result(23)
    );
  Mcount_readptr_cy_24_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(23),
      DI => N0,
      S => Mcount_readptr_cy_24_rt_64,
      O => Mcount_readptr_cy(24)
    );
  Mcount_readptr_xor_24_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(23),
      LI => Mcount_readptr_cy_24_rt_64,
      O => Result(24)
    );
  Mcount_readptr_cy_25_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(24),
      DI => N0,
      S => Mcount_readptr_cy_25_rt_66,
      O => Mcount_readptr_cy(25)
    );
  Mcount_readptr_xor_25_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(24),
      LI => Mcount_readptr_cy_25_rt_66,
      O => Result(25)
    );
  Mcount_readptr_cy_26_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(25),
      DI => N0,
      S => Mcount_readptr_cy_26_rt_68,
      O => Mcount_readptr_cy(26)
    );
  Mcount_readptr_xor_26_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(25),
      LI => Mcount_readptr_cy_26_rt_68,
      O => Result(26)
    );
  Mcount_readptr_cy_27_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(26),
      DI => N0,
      S => Mcount_readptr_cy_27_rt_70,
      O => Mcount_readptr_cy(27)
    );
  Mcount_readptr_xor_27_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(26),
      LI => Mcount_readptr_cy_27_rt_70,
      O => Result(27)
    );
  Mcount_readptr_cy_28_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(27),
      DI => N0,
      S => Mcount_readptr_cy_28_rt_72,
      O => Mcount_readptr_cy(28)
    );
  Mcount_readptr_xor_28_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(27),
      LI => Mcount_readptr_cy_28_rt_72,
      O => Result(28)
    );
  Mcount_readptr_cy_29_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(28),
      DI => N0,
      S => Mcount_readptr_cy_29_rt_74,
      O => Mcount_readptr_cy(29)
    );
  Mcount_readptr_xor_29_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(28),
      LI => Mcount_readptr_cy_29_rt_74,
      O => Result(29)
    );
  Mcount_readptr_cy_30_Q : MUXCY
    port map (
      CI => Mcount_readptr_cy(29),
      DI => N0,
      S => Mcount_readptr_cy_30_rt_78,
      O => Mcount_readptr_cy(30)
    );
  Mcount_readptr_xor_30_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(29),
      LI => Mcount_readptr_cy_30_rt_78,
      O => Result(30)
    );
  Mcount_readptr_xor_31_Q : XORCY
    port map (
      CI => Mcount_readptr_cy(30),
      LI => Mcount_readptr_xor_31_rt_126,
      O => Result(31)
    );
  readptr_cmp_eq0000_wg_lut_0_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => readptr(8),
      I1 => readptr(9),
      I2 => readptr(7),
      I3 => readptr(10),
      O => readptr_cmp_eq0000_wg_lut(0)
    );
  readptr_cmp_eq0000_wg_cy_0_Q : MUXCY
    port map (
      CI => N1,
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(0),
      O => readptr_cmp_eq0000_wg_cy(0)
    );
  readptr_cmp_eq0000_wg_lut_1_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => readptr(11),
      I1 => readptr(12),
      I2 => readptr(6),
      I3 => readptr(13),
      O => readptr_cmp_eq0000_wg_lut(1)
    );
  readptr_cmp_eq0000_wg_cy_1_Q : MUXCY
    port map (
      CI => readptr_cmp_eq0000_wg_cy(0),
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(1),
      O => readptr_cmp_eq0000_wg_cy(1)
    );
  readptr_cmp_eq0000_wg_lut_2_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => readptr(14),
      I1 => readptr(15),
      I2 => readptr(5),
      I3 => readptr(16),
      O => readptr_cmp_eq0000_wg_lut(2)
    );
  readptr_cmp_eq0000_wg_cy_2_Q : MUXCY
    port map (
      CI => readptr_cmp_eq0000_wg_cy(1),
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(2),
      O => readptr_cmp_eq0000_wg_cy(2)
    );
  readptr_cmp_eq0000_wg_lut_3_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => readptr(17),
      I1 => readptr(18),
      I2 => readptr(4),
      I3 => readptr(19),
      O => readptr_cmp_eq0000_wg_lut(3)
    );
  readptr_cmp_eq0000_wg_cy_3_Q : MUXCY
    port map (
      CI => readptr_cmp_eq0000_wg_cy(2),
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(3),
      O => readptr_cmp_eq0000_wg_cy(3)
    );
  readptr_cmp_eq0000_wg_lut_4_Q : LUT4
    generic map(
      INIT => X"0010"
    )
    port map (
      I0 => readptr(20),
      I1 => readptr(21),
      I2 => readptr(3),
      I3 => readptr(22),
      O => readptr_cmp_eq0000_wg_lut(4)
    );
  readptr_cmp_eq0000_wg_cy_4_Q : MUXCY
    port map (
      CI => readptr_cmp_eq0000_wg_cy(3),
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(4),
      O => readptr_cmp_eq0000_wg_cy(4)
    );
  readptr_cmp_eq0000_wg_lut_5_Q : LUT4
    generic map(
      INIT => X"0010"
    )
    port map (
      I0 => readptr(23),
      I1 => readptr(24),
      I2 => readptr(2),
      I3 => readptr(25),
      O => readptr_cmp_eq0000_wg_lut(5)
    );
  readptr_cmp_eq0000_wg_cy_5_Q : MUXCY
    port map (
      CI => readptr_cmp_eq0000_wg_cy(4),
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(5),
      O => readptr_cmp_eq0000_wg_cy(5)
    );
  readptr_cmp_eq0000_wg_lut_6_Q : LUT4
    generic map(
      INIT => X"0010"
    )
    port map (
      I0 => readptr(26),
      I1 => readptr(27),
      I2 => readptr(1),
      I3 => readptr(28),
      O => readptr_cmp_eq0000_wg_lut(6)
    );
  readptr_cmp_eq0000_wg_cy_6_Q : MUXCY
    port map (
      CI => readptr_cmp_eq0000_wg_cy(5),
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(6),
      O => readptr_cmp_eq0000_wg_cy(6)
    );
  readptr_cmp_eq0000_wg_lut_7_Q : LUT4
    generic map(
      INIT => X"0010"
    )
    port map (
      I0 => readptr(29),
      I1 => readptr(30),
      I2 => readptr(0),
      I3 => readptr(31),
      O => readptr_cmp_eq0000_wg_lut(7)
    );
  readptr_cmp_eq0000_wg_cy_7_Q : MUXCY
    port map (
      CI => readptr_cmp_eq0000_wg_cy(6),
      DI => N0,
      S => readptr_cmp_eq0000_wg_lut(7),
      O => readptr_cmp_eq0000
    );
  empty_cmp_eq00001_wg_lut_0_Q : LUT3
    generic map(
      INIT => X"01"
    )
    port map (
      I0 => num_elem_mux0001(22),
      I1 => num_elem_mux0001(23),
      I2 => num_elem_mux0001(24),
      O => empty_cmp_eq00001_wg_lut(0)
    );
  empty_cmp_eq00001_wg_cy_0_Q : MUXCY
    port map (
      CI => N1,
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(0),
      O => empty_cmp_eq00001_wg_cy(0)
    );
  empty_cmp_eq00001_wg_lut_1_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => num_elem_mux0001(19),
      I1 => num_elem_mux0001(20),
      I2 => num_elem_mux0001(21),
      I3 => num_elem_mux0001(25),
      O => empty_cmp_eq00001_wg_lut(1)
    );
  empty_cmp_eq00001_wg_cy_1_Q : MUXCY
    port map (
      CI => empty_cmp_eq00001_wg_cy(0),
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(1),
      O => empty_cmp_eq00001_wg_cy(1)
    );
  empty_cmp_eq00001_wg_lut_2_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => num_elem_mux0001(16),
      I1 => num_elem_mux0001(17),
      I2 => num_elem_mux0001(18),
      I3 => num_elem_mux0001(26),
      O => empty_cmp_eq00001_wg_lut(2)
    );
  empty_cmp_eq00001_wg_cy_2_Q : MUXCY
    port map (
      CI => empty_cmp_eq00001_wg_cy(1),
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(2),
      O => empty_cmp_eq00001_wg_cy(2)
    );
  empty_cmp_eq00001_wg_lut_3_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => num_elem_mux0001(13),
      I1 => num_elem_mux0001(14),
      I2 => num_elem_mux0001(15),
      I3 => num_elem_mux0001(27),
      O => empty_cmp_eq00001_wg_lut(3)
    );
  empty_cmp_eq00001_wg_cy_3_Q : MUXCY
    port map (
      CI => empty_cmp_eq00001_wg_cy(2),
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(3),
      O => empty_cmp_eq00001_wg_cy(3)
    );
  empty_cmp_eq00001_wg_lut_4_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => num_elem_mux0001(10),
      I1 => num_elem_mux0001(11),
      I2 => num_elem_mux0001(12),
      I3 => num_elem_mux0001(28),
      O => empty_cmp_eq00001_wg_lut(4)
    );
  empty_cmp_eq00001_wg_cy_4_Q : MUXCY
    port map (
      CI => empty_cmp_eq00001_wg_cy(3),
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(4),
      O => empty_cmp_eq00001_wg_cy(4)
    );
  empty_cmp_eq00001_wg_lut_5_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => num_elem_mux0001(7),
      I1 => num_elem_mux0001(8),
      I2 => num_elem_mux0001(9),
      I3 => num_elem_mux0001(29),
      O => empty_cmp_eq00001_wg_lut(5)
    );
  empty_cmp_eq00001_wg_cy_5_Q : MUXCY
    port map (
      CI => empty_cmp_eq00001_wg_cy(4),
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(5),
      O => empty_cmp_eq00001_wg_cy(5)
    );
  empty_cmp_eq00001_wg_cy_6_Q : MUXCY
    port map (
      CI => empty_cmp_eq00001_wg_cy(5),
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(6),
      O => empty_cmp_eq00001_wg_cy(6)
    );
  empty_cmp_eq00001_wg_cy_7_Q : MUXCY
    port map (
      CI => empty_cmp_eq00001_wg_cy(6),
      DI => N0,
      S => empty_cmp_eq00001_wg_lut(7),
      O => empty_cmp_eq00001_wg_cy(7)
    );
  writeptr_cmp_eq0000_wg_lut_0_Q : LUT3
    generic map(
      INIT => X"01"
    )
    port map (
      I0 => writeptr(17),
      I1 => writeptr(16),
      I2 => writeptr(18),
      O => writeptr_cmp_eq0000_wg_lut(0)
    );
  writeptr_cmp_eq0000_wg_cy_0_Q : MUXCY
    port map (
      CI => N1,
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(0),
      O => writeptr_cmp_eq0000_wg_cy(0)
    );
  writeptr_cmp_eq0000_wg_lut_1_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => writeptr(19),
      I1 => writeptr(20),
      I2 => writeptr(15),
      I3 => writeptr(21),
      O => writeptr_cmp_eq0000_wg_lut(1)
    );
  writeptr_cmp_eq0000_wg_cy_1_Q : MUXCY
    port map (
      CI => writeptr_cmp_eq0000_wg_cy(0),
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(1),
      O => writeptr_cmp_eq0000_wg_cy(1)
    );
  writeptr_cmp_eq0000_wg_lut_2_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => writeptr(22),
      I1 => writeptr(23),
      I2 => writeptr(14),
      I3 => writeptr(24),
      O => writeptr_cmp_eq0000_wg_lut(2)
    );
  writeptr_cmp_eq0000_wg_cy_2_Q : MUXCY
    port map (
      CI => writeptr_cmp_eq0000_wg_cy(1),
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(2),
      O => writeptr_cmp_eq0000_wg_cy(2)
    );
  writeptr_cmp_eq0000_wg_lut_3_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => writeptr(25),
      I1 => writeptr(26),
      I2 => writeptr(13),
      I3 => writeptr(27),
      O => writeptr_cmp_eq0000_wg_lut(3)
    );
  writeptr_cmp_eq0000_wg_cy_3_Q : MUXCY
    port map (
      CI => writeptr_cmp_eq0000_wg_cy(2),
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(3),
      O => writeptr_cmp_eq0000_wg_cy(3)
    );
  writeptr_cmp_eq0000_wg_lut_4_Q : LUT4
    generic map(
      INIT => X"0010"
    )
    port map (
      I0 => writeptr(28),
      I1 => writeptr(29),
      I2 => writeptr(2),
      I3 => writeptr(12),
      O => writeptr_cmp_eq0000_wg_lut(4)
    );
  writeptr_cmp_eq0000_wg_cy_4_Q : MUXCY
    port map (
      CI => writeptr_cmp_eq0000_wg_cy(3),
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(4),
      O => writeptr_cmp_eq0000_wg_cy(4)
    );
  writeptr_cmp_eq0000_wg_lut_5_Q : LUT4
    generic map(
      INIT => X"0010"
    )
    port map (
      I0 => writeptr(30),
      I1 => writeptr(31),
      I2 => writeptr(3),
      I3 => writeptr(11),
      O => writeptr_cmp_eq0000_wg_lut(5)
    );
  writeptr_cmp_eq0000_wg_cy_5_Q : MUXCY
    port map (
      CI => writeptr_cmp_eq0000_wg_cy(4),
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(5),
      O => writeptr_cmp_eq0000_wg_cy(5)
    );
  writeptr_cmp_eq0000_wg_lut_6_Q : LUT4
    generic map(
      INIT => X"0001"
    )
    port map (
      I0 => writeptr(4),
      I1 => writeptr(5),
      I2 => writeptr(10),
      I3 => writeptr(6),
      O => writeptr_cmp_eq0000_wg_lut(6)
    );
  writeptr_cmp_eq0000_wg_cy_6_Q : MUXCY
    port map (
      CI => writeptr_cmp_eq0000_wg_cy(5),
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(6),
      O => writeptr_cmp_eq0000_wg_cy(6)
    );
  writeptr_cmp_eq0000_wg_lut_7_Q : LUT4
    generic map(
      INIT => X"0010"
    )
    port map (
      I0 => writeptr(7),
      I1 => writeptr(8),
      I2 => N5,
      I3 => writeptr(9),
      O => writeptr_cmp_eq0000_wg_lut(7)
    );
  writeptr_cmp_eq0000_wg_cy_7_Q : MUXCY
    port map (
      CI => writeptr_cmp_eq0000_wg_cy(6),
      DI => N0,
      S => writeptr_cmp_eq0000_wg_lut(7),
      O => writeptr_cmp_eq0000
    );
  memory_13_and000011 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr(1),
      I1 => writeptr(0),
      O => N7
    );
  memory_10_and000021 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr(0),
      I1 => writeptr(1),
      O => N6
    );
  memory_0_and000021 : LUT2
    generic map(
      INIT => X"1"
    )
    port map (
      I0 => writeptr(1),
      I1 => writeptr(0),
      O => N8
    );
  memory_9_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N7,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_9_and0000
    );
  memory_8_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => N16,
      I1 => N8,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_8_and0000
    );
  memory_7_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => writeptr(2),
      I1 => N15,
      I2 => writeptr(3),
      I3 => num_elem_and0000,
      O => memory_7_and0000
    );
  memory_6_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => writeptr(2),
      I1 => N6,
      I2 => writeptr(3),
      I3 => num_elem_and0000,
      O => memory_6_and0000
    );
  memory_5_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => writeptr(2),
      I1 => N7,
      I2 => writeptr(3),
      I3 => num_elem_and0000,
      O => memory_5_and0000
    );
  memory_4_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => writeptr(2),
      I1 => N8,
      I2 => writeptr(3),
      I3 => num_elem_and0000,
      O => memory_4_and0000
    );
  memory_3_and00001 : LUT4
    generic map(
      INIT => X"0008"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N5,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_3_and0000
    );
  memory_2_and00001 : LUT4
    generic map(
      INIT => X"0008"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N6,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_2_and0000
    );
  memory_1_and00001 : LUT4
    generic map(
      INIT => X"0008"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N7,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_1_and0000
    );
  memory_15_and00001 : LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N5,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_15_and0000
    );
  memory_14_and00001 : LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N6,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_14_and0000
    );
  memory_13_and00001 : LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N7,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_13_and0000
    );
  memory_12_and00001 : LUT4
    generic map(
      INIT => X"8000"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N8,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_12_and0000
    );
  memory_11_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N5,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_11_and0000
    );
  memory_10_and00001 : LUT4
    generic map(
      INIT => X"0800"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N6,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_10_and0000
    );
  memory_0_and00001 : LUT4
    generic map(
      INIT => X"0008"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => N8,
      I2 => writeptr(2),
      I3 => writeptr(3),
      O => memory_0_and0000
    );
  Mcount_readptr_eqn_91 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(9),
      O => Mcount_readptr_eqn_9
    );
  Mcount_readptr_eqn_81 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(8),
      O => Mcount_readptr_eqn_8
    );
  Mcount_readptr_eqn_71 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(7),
      O => Mcount_readptr_eqn_7
    );
  Mcount_readptr_eqn_61 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(6),
      O => Mcount_readptr_eqn_6
    );
  Mcount_readptr_eqn_51 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(5),
      O => Mcount_readptr_eqn_5
    );
  Mcount_readptr_eqn_41 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(4),
      O => Mcount_readptr_eqn_4
    );
  Mcount_readptr_eqn_32 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(3),
      O => Mcount_readptr_eqn_3
    );
  Mcount_readptr_eqn_210 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(2),
      O => Mcount_readptr_eqn_2
    );
  Mcount_readptr_eqn_110 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(1),
      O => Mcount_readptr_eqn_1
    );
  Mcount_readptr_eqn_01 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(0),
      O => Mcount_readptr_eqn_0
    );
  Mcount_readptr_eqn_101 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(10),
      O => Mcount_readptr_eqn_10
    );
  Mcount_readptr_eqn_111 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(11),
      O => Mcount_readptr_eqn_11
    );
  Mcount_readptr_eqn_121 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(12),
      O => Mcount_readptr_eqn_12
    );
  Mcount_readptr_eqn_131 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(13),
      O => Mcount_readptr_eqn_13
    );
  Mcount_readptr_eqn_141 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(14),
      O => Mcount_readptr_eqn_14
    );
  Mcount_writeptr_eqn_91 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_9_1,
      O => Mcount_writeptr_eqn_9
    );
  Mcount_writeptr_eqn_81 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_8_1,
      O => Mcount_writeptr_eqn_8
    );
  Mcount_writeptr_eqn_71 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_7_1,
      O => Mcount_writeptr_eqn_7
    );
  Mcount_writeptr_eqn_61 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_6_1,
      O => Mcount_writeptr_eqn_6
    );
  Mcount_writeptr_eqn_51 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_5_1,
      O => Mcount_writeptr_eqn_5
    );
  Mcount_writeptr_eqn_41 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_4_1,
      O => Mcount_writeptr_eqn_4
    );
  Mcount_writeptr_eqn_32 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_3_1,
      O => Mcount_writeptr_eqn_3
    );
  Mcount_writeptr_eqn_210 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_2_1,
      O => Mcount_writeptr_eqn_2
    );
  Mcount_writeptr_eqn_141 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_14_1,
      O => Mcount_writeptr_eqn_14
    );
  Mcount_writeptr_eqn_131 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_13_1,
      O => Mcount_writeptr_eqn_13
    );
  Mcount_writeptr_eqn_121 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_12_1,
      O => Mcount_writeptr_eqn_12
    );
  Mcount_writeptr_eqn_111 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_11_1,
      O => Mcount_writeptr_eqn_11_191
    );
  Mcount_writeptr_eqn_101 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_10_1,
      O => Mcount_writeptr_eqn_10
    );
  Mcount_writeptr_eqn_11 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_1_1,
      O => Mcount_writeptr_eqn_1
    );
  Mcount_writeptr_eqn_01 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_0_1,
      O => Mcount_writeptr_eqn_0
    );
  Mcount_writeptr_eqn_151 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_15_1,
      O => Mcount_writeptr_eqn_15
    );
  Mcount_readptr_eqn_151 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(15),
      O => Mcount_readptr_eqn_15
    );
  Mcount_writeptr_eqn_161 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_16_1,
      O => Mcount_writeptr_eqn_16
    );
  Mcount_readptr_eqn_161 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(16),
      O => Mcount_readptr_eqn_16
    );
  Mcount_writeptr_eqn_171 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_17_1,
      O => Mcount_writeptr_eqn_17
    );
  Mcount_readptr_eqn_171 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(17),
      O => Mcount_readptr_eqn_17
    );
  Mcount_writeptr_eqn_181 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_18_1,
      O => Mcount_writeptr_eqn_18
    );
  Mcount_readptr_eqn_181 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(18),
      O => Mcount_readptr_eqn_18
    );
  Mcount_writeptr_eqn_191 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_19_1,
      O => Mcount_writeptr_eqn_19
    );
  Mcount_readptr_eqn_191 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(19),
      O => Mcount_readptr_eqn_19
    );
  Mcount_writeptr_eqn_201 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_20_1,
      O => Mcount_writeptr_eqn_20
    );
  Mcount_readptr_eqn_201 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(20),
      O => Mcount_readptr_eqn_20
    );
  Mcount_writeptr_eqn_211 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_21_1,
      O => Mcount_writeptr_eqn_21
    );
  Mcount_readptr_eqn_211 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(21),
      O => Mcount_readptr_eqn_21
    );
  Mcount_writeptr_eqn_221 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_22_1,
      O => Mcount_writeptr_eqn_22
    );
  Mcount_readptr_eqn_221 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(22),
      O => Mcount_readptr_eqn_22
    );
  Mcount_writeptr_eqn_231 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_23_1,
      O => Mcount_writeptr_eqn_23
    );
  Mcount_readptr_eqn_231 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(23),
      O => Mcount_readptr_eqn_23
    );
  Mcount_writeptr_eqn_241 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_24_1,
      O => Mcount_writeptr_eqn_24
    );
  Mcount_readptr_eqn_241 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(24),
      O => Mcount_readptr_eqn_24
    );
  Mcount_writeptr_eqn_251 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_25_1,
      O => Mcount_writeptr_eqn_25
    );
  Mcount_readptr_eqn_251 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(25),
      O => Mcount_readptr_eqn_25
    );
  Mcount_writeptr_eqn_261 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_26_1,
      O => Mcount_writeptr_eqn_26
    );
  Mcount_readptr_eqn_261 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(26),
      O => Mcount_readptr_eqn_26
    );
  Mcount_writeptr_eqn_271 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_27_1,
      O => Mcount_writeptr_eqn_27
    );
  Mcount_readptr_eqn_271 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(27),
      O => Mcount_readptr_eqn_27
    );
  Mcount_writeptr_eqn_281 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_28_1,
      O => Mcount_writeptr_eqn_28
    );
  Mcount_readptr_eqn_281 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(28),
      O => Mcount_readptr_eqn_28
    );
  Mcount_writeptr_eqn_291 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_29_1,
      O => Mcount_writeptr_eqn_29
    );
  Mcount_readptr_eqn_291 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(29),
      O => Mcount_readptr_eqn_29
    );
  Mcount_writeptr_eqn_301 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_30_1,
      O => Mcount_writeptr_eqn_30
    );
  Mcount_readptr_eqn_301 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(30),
      O => Mcount_readptr_eqn_30
    );
  Mcount_writeptr_eqn_311 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => Result_31_1,
      O => Mcount_writeptr_eqn_31
    );
  Mcount_readptr_eqn_311 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => Result(31),
      O => Mcount_readptr_eqn_31
    );
  data_out_and00001 : LUT2
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => empty_581,
      I1 => enr_IBUF_600,
      O => data_out_and0000
    );
  reset_IBUF : IBUF
    port map (
      I => reset,
      O => reset_IBUF_930
    );
  enr_IBUF : IBUF
    port map (
      I => enr,
      O => enr_IBUF_600
    );
  enw_IBUF : IBUF
    port map (
      I => enw,
      O => enw_IBUF_602
    );
  data_in_7_IBUF : IBUF
    port map (
      I => data_in(7),
      O => data_in_7_IBUF_563
    );
  data_in_6_IBUF : IBUF
    port map (
      I => data_in(6),
      O => data_in_6_IBUF_562
    );
  data_in_5_IBUF : IBUF
    port map (
      I => data_in(5),
      O => data_in_5_IBUF_561
    );
  data_in_4_IBUF : IBUF
    port map (
      I => data_in(4),
      O => data_in_4_IBUF_560
    );
  data_in_3_IBUF : IBUF
    port map (
      I => data_in(3),
      O => data_in_3_IBUF_559
    );
  data_in_2_IBUF : IBUF
    port map (
      I => data_in(2),
      O => data_in_2_IBUF_558
    );
  data_in_1_IBUF : IBUF
    port map (
      I => data_in(1),
      O => data_in_1_IBUF_557
    );
  data_in_0_IBUF : IBUF
    port map (
      I => data_in(0),
      O => data_in_0_IBUF_556
    );
  fifo_empty_OBUF : OBUF
    port map (
      I => empty_581,
      O => fifo_empty
    );
  fifo_full_OBUF : OBUF
    port map (
      I => full_605,
      O => fifo_full
    );
  data_out_7_OBUF : OBUF
    port map (
      I => data_out_7_579,
      O => data_out(7)
    );
  data_out_6_OBUF : OBUF
    port map (
      I => data_out_6_578,
      O => data_out(6)
    );
  data_out_5_OBUF : OBUF
    port map (
      I => data_out_5_577,
      O => data_out(5)
    );
  data_out_4_OBUF : OBUF
    port map (
      I => data_out_4_576,
      O => data_out(4)
    );
  data_out_3_OBUF : OBUF
    port map (
      I => data_out_3_575,
      O => data_out(3)
    );
  data_out_2_OBUF : OBUF
    port map (
      I => data_out_2_574,
      O => data_out(2)
    );
  data_out_1_OBUF : OBUF
    port map (
      I => data_out_1_573,
      O => data_out(1)
    );
  data_out_0_OBUF : OBUF
    port map (
      I => data_out_0_572,
      O => data_out(0)
    );
  Msub_num_elem_sub0000_cy_0_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => num_elem(0),
      O => Msub_num_elem_sub0000_cy_0_rt_398
    );
  Mcount_writeptr_cy_1_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(1),
      O => Mcount_writeptr_cy_1_rt_149
    );
  Mcount_writeptr_cy_2_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(2),
      O => Mcount_writeptr_cy_2_rt_171
    );
  Mcount_writeptr_cy_3_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(3),
      O => Mcount_writeptr_cy_3_rt_175
    );
  Mcount_writeptr_cy_4_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(4),
      O => Mcount_writeptr_cy_4_rt_177
    );
  Mcount_writeptr_cy_5_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(5),
      O => Mcount_writeptr_cy_5_rt_179
    );
  Mcount_writeptr_cy_6_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(6),
      O => Mcount_writeptr_cy_6_rt_181
    );
  Mcount_writeptr_cy_7_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(7),
      O => Mcount_writeptr_cy_7_rt_183
    );
  Mcount_writeptr_cy_8_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(8),
      O => Mcount_writeptr_cy_8_rt_185
    );
  Mcount_writeptr_cy_9_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(9),
      O => Mcount_writeptr_cy_9_rt_187
    );
  Mcount_writeptr_cy_10_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(10),
      O => Mcount_writeptr_cy_10_rt_129
    );
  Mcount_writeptr_cy_11_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(11),
      O => Mcount_writeptr_cy_11_rt_131
    );
  Mcount_writeptr_cy_12_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(12),
      O => Mcount_writeptr_cy_12_rt_133
    );
  Mcount_writeptr_cy_13_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(13),
      O => Mcount_writeptr_cy_13_rt_135
    );
  Mcount_writeptr_cy_14_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(14),
      O => Mcount_writeptr_cy_14_rt_137
    );
  Mcount_writeptr_cy_15_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(15),
      O => Mcount_writeptr_cy_15_rt_139
    );
  Mcount_writeptr_cy_16_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(16),
      O => Mcount_writeptr_cy_16_rt_141
    );
  Mcount_writeptr_cy_17_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(17),
      O => Mcount_writeptr_cy_17_rt_143
    );
  Mcount_writeptr_cy_18_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(18),
      O => Mcount_writeptr_cy_18_rt_145
    );
  Mcount_writeptr_cy_19_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(19),
      O => Mcount_writeptr_cy_19_rt_147
    );
  Mcount_writeptr_cy_20_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(20),
      O => Mcount_writeptr_cy_20_rt_151
    );
  Mcount_writeptr_cy_21_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(21),
      O => Mcount_writeptr_cy_21_rt_153
    );
  Mcount_writeptr_cy_22_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(22),
      O => Mcount_writeptr_cy_22_rt_155
    );
  Mcount_writeptr_cy_23_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(23),
      O => Mcount_writeptr_cy_23_rt_157
    );
  Mcount_writeptr_cy_24_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(24),
      O => Mcount_writeptr_cy_24_rt_159
    );
  Mcount_writeptr_cy_25_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(25),
      O => Mcount_writeptr_cy_25_rt_161
    );
  Mcount_writeptr_cy_26_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(26),
      O => Mcount_writeptr_cy_26_rt_163
    );
  Mcount_writeptr_cy_27_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(27),
      O => Mcount_writeptr_cy_27_rt_165
    );
  Mcount_writeptr_cy_28_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(28),
      O => Mcount_writeptr_cy_28_rt_167
    );
  Mcount_writeptr_cy_29_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(29),
      O => Mcount_writeptr_cy_29_rt_169
    );
  Mcount_writeptr_cy_30_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(30),
      O => Mcount_writeptr_cy_30_rt_173
    );
  Mcount_readptr_cy_1_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(1),
      O => Mcount_readptr_cy_1_rt_54
    );
  Mcount_readptr_cy_2_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(2),
      O => Mcount_readptr_cy_2_rt_76
    );
  Mcount_readptr_cy_3_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(3),
      O => Mcount_readptr_cy_3_rt_80
    );
  Mcount_readptr_cy_4_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(4),
      O => Mcount_readptr_cy_4_rt_82
    );
  Mcount_readptr_cy_5_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(5),
      O => Mcount_readptr_cy_5_rt_84
    );
  Mcount_readptr_cy_6_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(6),
      O => Mcount_readptr_cy_6_rt_86
    );
  Mcount_readptr_cy_7_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(7),
      O => Mcount_readptr_cy_7_rt_88
    );
  Mcount_readptr_cy_8_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(8),
      O => Mcount_readptr_cy_8_rt_90
    );
  Mcount_readptr_cy_9_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(9),
      O => Mcount_readptr_cy_9_rt_92
    );
  Mcount_readptr_cy_10_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(10),
      O => Mcount_readptr_cy_10_rt_34
    );
  Mcount_readptr_cy_11_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(11),
      O => Mcount_readptr_cy_11_rt_36
    );
  Mcount_readptr_cy_12_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(12),
      O => Mcount_readptr_cy_12_rt_38
    );
  Mcount_readptr_cy_13_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(13),
      O => Mcount_readptr_cy_13_rt_40
    );
  Mcount_readptr_cy_14_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(14),
      O => Mcount_readptr_cy_14_rt_42
    );
  Mcount_readptr_cy_15_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(15),
      O => Mcount_readptr_cy_15_rt_44
    );
  Mcount_readptr_cy_16_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(16),
      O => Mcount_readptr_cy_16_rt_46
    );
  Mcount_readptr_cy_17_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(17),
      O => Mcount_readptr_cy_17_rt_48
    );
  Mcount_readptr_cy_18_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(18),
      O => Mcount_readptr_cy_18_rt_50
    );
  Mcount_readptr_cy_19_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(19),
      O => Mcount_readptr_cy_19_rt_52
    );
  Mcount_readptr_cy_20_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(20),
      O => Mcount_readptr_cy_20_rt_56
    );
  Mcount_readptr_cy_21_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(21),
      O => Mcount_readptr_cy_21_rt_58
    );
  Mcount_readptr_cy_22_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(22),
      O => Mcount_readptr_cy_22_rt_60
    );
  Mcount_readptr_cy_23_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(23),
      O => Mcount_readptr_cy_23_rt_62
    );
  Mcount_readptr_cy_24_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(24),
      O => Mcount_readptr_cy_24_rt_64
    );
  Mcount_readptr_cy_25_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(25),
      O => Mcount_readptr_cy_25_rt_66
    );
  Mcount_readptr_cy_26_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(26),
      O => Mcount_readptr_cy_26_rt_68
    );
  Mcount_readptr_cy_27_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(27),
      O => Mcount_readptr_cy_27_rt_70
    );
  Mcount_readptr_cy_28_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(28),
      O => Mcount_readptr_cy_28_rt_72
    );
  Mcount_readptr_cy_29_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(29),
      O => Mcount_readptr_cy_29_rt_74
    );
  Mcount_readptr_cy_30_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(30),
      O => Mcount_readptr_cy_30_rt_78
    );
  Mcount_writeptr_xor_31_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => writeptr(31),
      O => Mcount_writeptr_xor_31_rt_221
    );
  Mcount_readptr_xor_31_rt : LUT1
    generic map(
      INIT => X"2"
    )
    port map (
      I0 => readptr(31),
      O => Mcount_readptr_xor_31_rt_126
    );
  Mmux_num_elem_mux0001501_SW0 : LUT4
    generic map(
      INIT => X"FDFC"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => num_elem_mux0001(0),
      I2 => num_elem_mux0001(1),
      I3 => N18,
      O => N9
    );
  Mmux_num_elem_mux0001501_SW1 : LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => num_elem_mux0001(0),
      I2 => num_elem_mux0001(1),
      I3 => Mmux_num_elem_mux000128,
      O => N10
    );
  empty_cmp_eq00001_wg_lut_7_Q : LUT4
    generic map(
      INIT => X"0145"
    )
    port map (
      I0 => num_elem_mux0001(2),
      I1 => num_elem_addsub0000(31),
      I2 => N9,
      I3 => N10,
      O => empty_cmp_eq00001_wg_lut(7)
    );
  Mmux_num_elem_mux0001481_SW0 : LUT4
    generic map(
      INIT => X"FFF4"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => Mmux_num_elem_mux000126,
      I2 => num_elem_mux0001(3),
      I3 => num_elem_mux0001(5),
      O => N12
    );
  empty_cmp_eq00001_wg_lut_6_Q : LUT4
    generic map(
      INIT => X"0213"
    )
    port map (
      I0 => num_elem_addsub0000(30),
      I1 => num_elem_mux0001(6),
      I2 => N13,
      I3 => N12,
      O => empty_cmp_eq00001_wg_lut(6)
    );
  Mmux_num_elem_mux00012311 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(1),
      I2 => empty_581,
      I3 => num_elem_sub0000(1),
      O => Mmux_num_elem_mux0001231_355
    );
  Mmux_num_elem_mux00014511 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(2),
      I2 => empty_581,
      I3 => num_elem_sub0000(2),
      O => Mmux_num_elem_mux0001451_379
    );
  Mmux_num_elem_mux00015111 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(3),
      I2 => empty_581,
      I3 => num_elem_sub0000(3),
      O => Mmux_num_elem_mux0001511_384
    );
  Mmux_num_elem_mux00015311 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(4),
      I2 => empty_581,
      I3 => num_elem_sub0000(4),
      O => Mmux_num_elem_mux0001531_385
    );
  Mmux_num_elem_mux00015511 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(5),
      I2 => empty_581,
      I3 => num_elem_sub0000(5),
      O => Mmux_num_elem_mux0001551_386
    );
  Mmux_num_elem_mux00015711 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(6),
      I2 => empty_581,
      I3 => num_elem_sub0000(6),
      O => Mmux_num_elem_mux0001571_387
    );
  Mmux_num_elem_mux00015911 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(7),
      I2 => empty_581,
      I3 => num_elem_sub0000(7),
      O => Mmux_num_elem_mux0001591_388
    );
  Mmux_num_elem_mux00016111 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(8),
      I2 => empty_581,
      I3 => num_elem_sub0000(8),
      O => Mmux_num_elem_mux0001611_390
    );
  Mmux_num_elem_mux00016311 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(9),
      I2 => empty_581,
      I3 => num_elem_sub0000(9),
      O => Mmux_num_elem_mux0001631_391
    );
  Mmux_num_elem_mux0001312 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(10),
      I2 => empty_581,
      I3 => num_elem_sub0000(10),
      O => Mmux_num_elem_mux000131_364
    );
  Mmux_num_elem_mux0001512 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(11),
      I2 => empty_581,
      I3 => num_elem_sub0000(11),
      O => Mmux_num_elem_mux000151_383
    );
  Mmux_num_elem_mux0001711 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(12),
      I2 => empty_581,
      I3 => num_elem_sub0000(12),
      O => Mmux_num_elem_mux000171_393
    );
  Mmux_num_elem_mux0001911 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(13),
      I2 => empty_581,
      I3 => num_elem_sub0000(13),
      O => Mmux_num_elem_mux000191_396
    );
  Mmux_num_elem_mux00011111 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(14),
      I2 => empty_581,
      I3 => num_elem_sub0000(14),
      O => Mmux_num_elem_mux0001111_338
    );
  Mmux_num_elem_mux00011311 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(15),
      I2 => empty_581,
      I3 => num_elem_sub0000(15),
      O => Mmux_num_elem_mux0001131_341
    );
  Mmux_num_elem_mux00011511 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(16),
      I2 => empty_581,
      I3 => num_elem_sub0000(16),
      O => Mmux_num_elem_mux0001151_344
    );
  Mmux_num_elem_mux00011711 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(17),
      I2 => empty_581,
      I3 => num_elem_sub0000(17),
      O => Mmux_num_elem_mux0001171_347
    );
  Mmux_num_elem_mux00011911 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(18),
      I2 => empty_581,
      I3 => num_elem_sub0000(18),
      O => Mmux_num_elem_mux0001191_350
    );
  Mmux_num_elem_mux00012111 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(19),
      I2 => empty_581,
      I3 => num_elem_sub0000(19),
      O => Mmux_num_elem_mux0001211_353
    );
  Mmux_num_elem_mux00012511 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(20),
      I2 => empty_581,
      I3 => num_elem_sub0000(20),
      O => Mmux_num_elem_mux0001251_357
    );
  Mmux_num_elem_mux00012711 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(21),
      I2 => empty_581,
      I3 => num_elem_sub0000(21),
      O => Mmux_num_elem_mux0001271_359
    );
  Mmux_num_elem_mux00012911 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(22),
      I2 => empty_581,
      I3 => num_elem_sub0000(22),
      O => Mmux_num_elem_mux0001291_361
    );
  Mmux_num_elem_mux00013111 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(23),
      I2 => empty_581,
      I3 => num_elem_sub0000(23),
      O => Mmux_num_elem_mux0001311_365
    );
  Mmux_num_elem_mux00013311 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(24),
      I2 => empty_581,
      I3 => num_elem_sub0000(24),
      O => Mmux_num_elem_mux0001331_367
    );
  Mmux_num_elem_mux00013511 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(25),
      I2 => empty_581,
      I3 => num_elem_sub0000(25),
      O => Mmux_num_elem_mux0001351_369
    );
  Mmux_num_elem_mux00013711 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(26),
      I2 => empty_581,
      I3 => num_elem_sub0000(26),
      O => Mmux_num_elem_mux0001371_371
    );
  Mmux_num_elem_mux00013911 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(27),
      I2 => empty_581,
      I3 => num_elem_sub0000(27),
      O => Mmux_num_elem_mux0001391_373
    );
  Mmux_num_elem_mux00014111 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(28),
      I2 => empty_581,
      I3 => num_elem_sub0000(28),
      O => Mmux_num_elem_mux0001411_376
    );
  Mmux_num_elem_mux00014311 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(29),
      I2 => empty_581,
      I3 => num_elem_sub0000(29),
      O => Mmux_num_elem_mux0001431_378
    );
  Mmux_num_elem_mux00014711 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(30),
      I2 => empty_581,
      I3 => num_elem_sub0000(30),
      O => Mmux_num_elem_mux0001471_380
    );
  Mmux_num_elem_mux00014911 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(31),
      I2 => empty_581,
      I3 => num_elem_sub0000(31),
      O => Mmux_num_elem_mux0001491_381
    );
  Mmux_num_elem_mux0001341 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000116,
      I2 => full_605,
      I3 => num_elem_addsub0000(24),
      O => num_elem_mux0001(24)
    );
  Mmux_num_elem_mux0001321 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000115,
      I2 => full_605,
      I3 => num_elem_addsub0000(23),
      O => num_elem_mux0001(23)
    );
  Mmux_num_elem_mux0001301 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000114,
      I2 => full_605,
      I3 => num_elem_addsub0000(22),
      O => num_elem_mux0001(22)
    );
  Mmux_num_elem_mux0001361 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000117,
      I2 => full_605,
      I3 => num_elem_addsub0000(25),
      O => num_elem_mux0001(25)
    );
  Mmux_num_elem_mux0001381 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000118,
      I2 => full_605,
      I3 => num_elem_addsub0000(26),
      O => num_elem_mux0001(26)
    );
  Mmux_num_elem_mux0001281 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000113,
      I2 => full_605,
      I3 => num_elem_addsub0000(21),
      O => num_elem_mux0001(21)
    );
  Mmux_num_elem_mux0001261 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000112,
      I2 => full_605,
      I3 => num_elem_addsub0000(20),
      O => num_elem_mux0001(20)
    );
  Mmux_num_elem_mux0001221 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000110,
      I2 => full_605,
      I3 => num_elem_addsub0000(19),
      O => num_elem_mux0001(19)
    );
  Mmux_num_elem_mux0001401 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000119,
      I2 => full_605,
      I3 => num_elem_addsub0000(27),
      O => num_elem_mux0001(27)
    );
  Mmux_num_elem_mux0001421 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000120,
      I2 => full_605,
      I3 => num_elem_addsub0000(28),
      O => num_elem_mux0001(28)
    );
  Mmux_num_elem_mux0001201 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00019,
      I2 => full_605,
      I3 => num_elem_addsub0000(18),
      O => num_elem_mux0001(18)
    );
  Mmux_num_elem_mux0001181 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00018,
      I2 => full_605,
      I3 => num_elem_addsub0000(17),
      O => num_elem_mux0001(17)
    );
  Mmux_num_elem_mux0001161 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00017,
      I2 => full_605,
      I3 => num_elem_addsub0000(16),
      O => num_elem_mux0001(16)
    );
  Mmux_num_elem_mux0001441 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000122,
      I2 => full_605,
      I3 => num_elem_addsub0000(29),
      O => num_elem_mux0001(29)
    );
  Mmux_num_elem_mux0001141 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00016,
      I2 => full_605,
      I3 => num_elem_addsub0000(15),
      O => num_elem_mux0001(15)
    );
  Mmux_num_elem_mux0001121 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00015,
      I2 => full_605,
      I3 => num_elem_addsub0000(14),
      O => num_elem_mux0001(14)
    );
  Mmux_num_elem_mux0001101 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00014,
      I2 => full_605,
      I3 => num_elem_addsub0000(13),
      O => num_elem_mux0001(13)
    );
  Mmux_num_elem_mux000181 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00013,
      I2 => full_605,
      I3 => num_elem_addsub0000(12),
      O => num_elem_mux0001(12)
    );
  Mmux_num_elem_mux000162 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00012,
      I2 => full_605,
      I3 => num_elem_addsub0000(11),
      O => num_elem_mux0001(11)
    );
  Mmux_num_elem_mux000146 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux00011_335,
      I2 => full_605,
      I3 => num_elem_addsub0000(10),
      O => num_elem_mux0001(10)
    );
  empty_cmp_eq00001 : LUT4
    generic map(
      INIT => X"1B00"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => Mmux_num_elem_mux000132,
      I2 => num_elem_addsub0000(4),
      I3 => empty_cmp_eq00001_wg_cy(7),
      O => empty_cmp_eq0000
    );
  full_cmp_eq00001 : LUT4
    generic map(
      INIT => X"E400"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => Mmux_num_elem_mux000132,
      I2 => num_elem_addsub0000(4),
      I3 => empty_cmp_eq00001_wg_cy(7),
      O => full_cmp_eq0000
    );
  Mmux_num_elem_mux0001481_SW1 : LUT4
    generic map(
      INIT => X"FFFE"
    )
    port map (
      I0 => num_elem_and0000,
      I1 => Mmux_num_elem_mux000134,
      I2 => Mmux_num_elem_mux000126,
      I3 => num_elem_mux0001(3),
      O => N13
    );
  Madd_num_elem_addsub0000_lut_0_Q : LUT4
    generic map(
      INIT => X"313B"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(0),
      I2 => empty_581,
      I3 => num_elem_sub0000(0),
      O => Madd_num_elem_addsub0000_lut(0)
    );
  Mmux_num_elem_mux0001521 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000130,
      I2 => full_605,
      I3 => num_elem_addsub0000(3),
      O => num_elem_mux0001(3)
    );
  Mmux_num_elem_mux0001561 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000134,
      I2 => full_605,
      I3 => num_elem_addsub0000(5),
      O => num_elem_mux0001(5)
    );
  Mmux_num_elem_mux0001551 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(5),
      I2 => empty_581,
      I3 => num_elem_sub0000(5),
      O => Mmux_num_elem_mux000134
    );
  Mmux_num_elem_mux0001511 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(3),
      I2 => empty_581,
      I3 => num_elem_sub0000(3),
      O => Mmux_num_elem_mux000130
    );
  Mmux_num_elem_mux0001231 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(1),
      I2 => empty_581,
      I3 => num_elem_sub0000(1),
      O => Mmux_num_elem_mux000111
    );
  Mmux_num_elem_mux0001241 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000111,
      I2 => full_605,
      I3 => num_elem_addsub0000(1),
      O => num_elem_mux0001(1)
    );
  Mmux_num_elem_mux0001641 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000142,
      I2 => full_605,
      I3 => num_elem_addsub0000(9),
      O => num_elem_mux0001(9)
    );
  Mmux_num_elem_mux0001621 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000140,
      I2 => full_605,
      I3 => num_elem_addsub0000(8),
      O => num_elem_mux0001(8)
    );
  Mmux_num_elem_mux0001601 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000138,
      I2 => full_605,
      I3 => num_elem_addsub0000(7),
      O => num_elem_mux0001(7)
    );
  Mmux_num_elem_mux0001581 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000136,
      I2 => full_605,
      I3 => num_elem_addsub0000(6),
      O => num_elem_mux0001(6)
    );
  Mmux_num_elem_mux0001461 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000124,
      I2 => full_605,
      I3 => num_elem_addsub0000(2),
      O => num_elem_mux0001(2)
    );
  Mmux_num_elem_mux0001210 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux0001,
      I2 => full_605,
      I3 => num_elem_addsub0000(0),
      O => num_elem_mux0001(0)
    );
  Mmux_num_elem_mux0001501 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000128,
      I2 => full_605,
      I3 => num_elem_addsub0000(31),
      O => num_elem_mux0001(31)
    );
  Mmux_num_elem_mux0001481 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => N17,
      I2 => full_605,
      I3 => num_elem_addsub0000(30),
      O => num_elem_mux0001(30)
    );
  Mmux_num_elem_mux0001541 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enw_IBUF_602,
      I1 => Mmux_num_elem_mux000132,
      I2 => full_605,
      I3 => num_elem_addsub0000(4),
      O => num_elem_mux0001(4)
    );
  Mmux_num_elem_mux0001531 : LUT4
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(4),
      I2 => empty_581,
      I3 => num_elem_sub0000(4),
      O => Mmux_num_elem_mux000132
    );
  writeptr_not00011 : LUT3
    generic map(
      INIT => X"BA"
    )
    port map (
      I0 => writeptr_cmp_eq0000,
      I1 => full_605,
      I2 => enw_IBUF_602,
      O => writeptr_not0001
    );
  readptr_not00011 : LUT3
    generic map(
      INIT => X"BA"
    )
    port map (
      I0 => readptr_cmp_eq0000,
      I1 => empty_581,
      I2 => enr_IBUF_600,
      O => readptr_not0001
    );
  clk_BUFGP : BUFGP
    port map (
      I => clk,
      O => clk_BUFGP_547
    );
  Msub_num_elem_sub0000_lut_1_INV_0 : INV
    port map (
      I => num_elem(1),
      O => Msub_num_elem_sub0000_lut(1)
    );
  Msub_num_elem_sub0000_lut_2_INV_0 : INV
    port map (
      I => num_elem(2),
      O => Msub_num_elem_sub0000_lut(2)
    );
  Msub_num_elem_sub0000_lut_3_INV_0 : INV
    port map (
      I => num_elem(3),
      O => Msub_num_elem_sub0000_lut(3)
    );
  Msub_num_elem_sub0000_lut_4_INV_0 : INV
    port map (
      I => num_elem(4),
      O => Msub_num_elem_sub0000_lut(4)
    );
  Msub_num_elem_sub0000_lut_5_INV_0 : INV
    port map (
      I => num_elem(5),
      O => Msub_num_elem_sub0000_lut(5)
    );
  Msub_num_elem_sub0000_lut_6_INV_0 : INV
    port map (
      I => num_elem(6),
      O => Msub_num_elem_sub0000_lut(6)
    );
  Msub_num_elem_sub0000_lut_7_INV_0 : INV
    port map (
      I => num_elem(7),
      O => Msub_num_elem_sub0000_lut(7)
    );
  Msub_num_elem_sub0000_lut_8_INV_0 : INV
    port map (
      I => num_elem(8),
      O => Msub_num_elem_sub0000_lut(8)
    );
  Msub_num_elem_sub0000_lut_9_INV_0 : INV
    port map (
      I => num_elem(9),
      O => Msub_num_elem_sub0000_lut(9)
    );
  Msub_num_elem_sub0000_lut_10_INV_0 : INV
    port map (
      I => num_elem(10),
      O => Msub_num_elem_sub0000_lut(10)
    );
  Msub_num_elem_sub0000_lut_11_INV_0 : INV
    port map (
      I => num_elem(11),
      O => Msub_num_elem_sub0000_lut(11)
    );
  Msub_num_elem_sub0000_lut_12_INV_0 : INV
    port map (
      I => num_elem(12),
      O => Msub_num_elem_sub0000_lut(12)
    );
  Msub_num_elem_sub0000_lut_13_INV_0 : INV
    port map (
      I => num_elem(13),
      O => Msub_num_elem_sub0000_lut(13)
    );
  Msub_num_elem_sub0000_lut_14_INV_0 : INV
    port map (
      I => num_elem(14),
      O => Msub_num_elem_sub0000_lut(14)
    );
  Msub_num_elem_sub0000_lut_15_INV_0 : INV
    port map (
      I => num_elem(15),
      O => Msub_num_elem_sub0000_lut(15)
    );
  Msub_num_elem_sub0000_lut_16_INV_0 : INV
    port map (
      I => num_elem(16),
      O => Msub_num_elem_sub0000_lut(16)
    );
  Msub_num_elem_sub0000_lut_17_INV_0 : INV
    port map (
      I => num_elem(17),
      O => Msub_num_elem_sub0000_lut(17)
    );
  Msub_num_elem_sub0000_lut_18_INV_0 : INV
    port map (
      I => num_elem(18),
      O => Msub_num_elem_sub0000_lut(18)
    );
  Msub_num_elem_sub0000_lut_19_INV_0 : INV
    port map (
      I => num_elem(19),
      O => Msub_num_elem_sub0000_lut(19)
    );
  Msub_num_elem_sub0000_lut_20_INV_0 : INV
    port map (
      I => num_elem(20),
      O => Msub_num_elem_sub0000_lut(20)
    );
  Msub_num_elem_sub0000_lut_21_INV_0 : INV
    port map (
      I => num_elem(21),
      O => Msub_num_elem_sub0000_lut(21)
    );
  Msub_num_elem_sub0000_lut_22_INV_0 : INV
    port map (
      I => num_elem(22),
      O => Msub_num_elem_sub0000_lut(22)
    );
  Msub_num_elem_sub0000_lut_23_INV_0 : INV
    port map (
      I => num_elem(23),
      O => Msub_num_elem_sub0000_lut(23)
    );
  Msub_num_elem_sub0000_lut_24_INV_0 : INV
    port map (
      I => num_elem(24),
      O => Msub_num_elem_sub0000_lut(24)
    );
  Msub_num_elem_sub0000_lut_25_INV_0 : INV
    port map (
      I => num_elem(25),
      O => Msub_num_elem_sub0000_lut(25)
    );
  Msub_num_elem_sub0000_lut_26_INV_0 : INV
    port map (
      I => num_elem(26),
      O => Msub_num_elem_sub0000_lut(26)
    );
  Msub_num_elem_sub0000_lut_27_INV_0 : INV
    port map (
      I => num_elem(27),
      O => Msub_num_elem_sub0000_lut(27)
    );
  Msub_num_elem_sub0000_lut_28_INV_0 : INV
    port map (
      I => num_elem(28),
      O => Msub_num_elem_sub0000_lut(28)
    );
  Msub_num_elem_sub0000_lut_29_INV_0 : INV
    port map (
      I => num_elem(29),
      O => Msub_num_elem_sub0000_lut(29)
    );
  Msub_num_elem_sub0000_lut_30_INV_0 : INV
    port map (
      I => num_elem(30),
      O => Msub_num_elem_sub0000_lut(30)
    );
  Msub_num_elem_sub0000_lut_31_INV_0 : INV
    port map (
      I => num_elem(31),
      O => Msub_num_elem_sub0000_lut(31)
    );
  Mcount_writeptr_lut_0_INV_0 : INV
    port map (
      I => writeptr(0),
      O => Mcount_writeptr_lut(0)
    );
  Mcount_readptr_lut_0_INV_0 : INV
    port map (
      I => readptr(0),
      O => Mcount_readptr_lut(0)
    );
  writeptr_cmp_eq000011 : LUT2_D
    generic map(
      INIT => X"8"
    )
    port map (
      I0 => writeptr(1),
      I1 => writeptr(0),
      LO => N15,
      O => N5
    );
  num_elem_and00001 : LUT2_D
    generic map(
      INIT => X"4"
    )
    port map (
      I0 => full_605,
      I1 => enw_IBUF_602,
      LO => N16,
      O => num_elem_and0000
    );
  Mmux_num_elem_mux0001331 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(24),
      I2 => empty_581,
      I3 => num_elem_sub0000(24),
      LO => Mmux_num_elem_mux000116
    );
  Mmux_num_elem_mux0001311 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(23),
      I2 => empty_581,
      I3 => num_elem_sub0000(23),
      LO => Mmux_num_elem_mux000115
    );
  Mmux_num_elem_mux0001291 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(22),
      I2 => empty_581,
      I3 => num_elem_sub0000(22),
      LO => Mmux_num_elem_mux000114
    );
  Mmux_num_elem_mux0001351 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(25),
      I2 => empty_581,
      I3 => num_elem_sub0000(25),
      LO => Mmux_num_elem_mux000117
    );
  Mmux_num_elem_mux0001271 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(21),
      I2 => empty_581,
      I3 => num_elem_sub0000(21),
      LO => Mmux_num_elem_mux000113
    );
  Mmux_num_elem_mux0001251 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(20),
      I2 => empty_581,
      I3 => num_elem_sub0000(20),
      LO => Mmux_num_elem_mux000112
    );
  Mmux_num_elem_mux0001371 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(26),
      I2 => empty_581,
      I3 => num_elem_sub0000(26),
      LO => Mmux_num_elem_mux000118
    );
  Mmux_num_elem_mux0001211 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(19),
      I2 => empty_581,
      I3 => num_elem_sub0000(19),
      LO => Mmux_num_elem_mux000110
    );
  Mmux_num_elem_mux0001391 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(27),
      I2 => empty_581,
      I3 => num_elem_sub0000(27),
      LO => Mmux_num_elem_mux000119
    );
  Mmux_num_elem_mux0001191 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(18),
      I2 => empty_581,
      I3 => num_elem_sub0000(18),
      LO => Mmux_num_elem_mux00019
    );
  Mmux_num_elem_mux0001171 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(17),
      I2 => empty_581,
      I3 => num_elem_sub0000(17),
      LO => Mmux_num_elem_mux00018
    );
  Mmux_num_elem_mux0001151 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(16),
      I2 => empty_581,
      I3 => num_elem_sub0000(16),
      LO => Mmux_num_elem_mux00017
    );
  Mmux_num_elem_mux0001411 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(28),
      I2 => empty_581,
      I3 => num_elem_sub0000(28),
      LO => Mmux_num_elem_mux000120
    );
  Mmux_num_elem_mux0001131 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(15),
      I2 => empty_581,
      I3 => num_elem_sub0000(15),
      LO => Mmux_num_elem_mux00016
    );
  Mmux_num_elem_mux0001431 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(29),
      I2 => empty_581,
      I3 => num_elem_sub0000(29),
      LO => Mmux_num_elem_mux000122
    );
  Mmux_num_elem_mux0001111 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(14),
      I2 => empty_581,
      I3 => num_elem_sub0000(14),
      LO => Mmux_num_elem_mux00015
    );
  Mmux_num_elem_mux000191 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(13),
      I2 => empty_581,
      I3 => num_elem_sub0000(13),
      LO => Mmux_num_elem_mux00014
    );
  Mmux_num_elem_mux0001471 : LUT4_D
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(30),
      I2 => empty_581,
      I3 => num_elem_sub0000(30),
      LO => N17,
      O => Mmux_num_elem_mux000126
    );
  Mmux_num_elem_mux0001491 : LUT4_D
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(31),
      I2 => empty_581,
      I3 => num_elem_sub0000(31),
      LO => N18,
      O => Mmux_num_elem_mux000128
    );
  Mmux_num_elem_mux000171 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(12),
      I2 => empty_581,
      I3 => num_elem_sub0000(12),
      LO => Mmux_num_elem_mux00013
    );
  Mmux_num_elem_mux000151 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(11),
      I2 => empty_581,
      I3 => num_elem_sub0000(11),
      LO => Mmux_num_elem_mux00012
    );
  Mmux_num_elem_mux000131 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(10),
      I2 => empty_581,
      I3 => num_elem_sub0000(10),
      LO => Mmux_num_elem_mux00011_335
    );
  Mmux_num_elem_mux0001631 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(9),
      I2 => empty_581,
      I3 => num_elem_sub0000(9),
      LO => Mmux_num_elem_mux000142
    );
  Mmux_num_elem_mux0001611 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(8),
      I2 => empty_581,
      I3 => num_elem_sub0000(8),
      LO => Mmux_num_elem_mux000140
    );
  Mmux_num_elem_mux0001591 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(7),
      I2 => empty_581,
      I3 => num_elem_sub0000(7),
      LO => Mmux_num_elem_mux000138
    );
  Mmux_num_elem_mux0001571 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(6),
      I2 => empty_581,
      I3 => num_elem_sub0000(6),
      LO => Mmux_num_elem_mux000136
    );
  Mmux_num_elem_mux00011 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(0),
      I2 => empty_581,
      I3 => num_elem_sub0000(0),
      LO => Mmux_num_elem_mux0001
    );
  Mmux_num_elem_mux0001451 : LUT4_L
    generic map(
      INIT => X"CEC4"
    )
    port map (
      I0 => enr_IBUF_600,
      I1 => num_elem(2),
      I2 => empty_581,
      I3 => num_elem_sub0000(2),
      LO => Mmux_num_elem_mux000124
    );

end Structure;

